import { useEffect, useRef } from 'react';

/*
 * 自定义光标（只在有精确指针、可悬停的设备上启用；触屏、键盘操作不受影响）。
 * 一个跟手的小点 + 一个带阻尼的圆环，mix-blend-mode: difference 让它在纸面和深色首屏上都自动反色。
 * 悬停时按对象变形：
 *   链接 / 按钮 → 圆环放大、半透明填充
 *   解读卡片     → 大圆 + 「阅读」
 *   原文 / 引用  → 缩成小方框 + 「原文」
 *   图表         → 十字准星 + 「数据」
 *   输入框       → 隐藏，交还系统的文本光标
 * 同时把指针位置写进 --mx / --my，桌面玻璃卡片的反光跟着光标走（借鉴 Liquid Glass 的镜面高光）。
 * 首屏按钮和导航有轻微磁吸。
 */

type Mode = 'default' | 'link' | 'read' | 'cite' | 'data' | 'text' | 'hidden';

const LABEL: Partial<Record<Mode, string>> = { read: '阅读', cite: '原文', data: '数据' };

function modeOf(el: Element | null): Mode {
  if (!el) return 'default';
  if (el.closest('input, textarea, select, [contenteditable]')) return 'text';
  if (el.closest('.cite, .fig .link, .fig-row, .panel-back')) return 'cite';
  if (el.closest('.fig')) return 'data';
  if (el.closest('.dk-card a, .dk-lead-text, .lead-link, .row, .src-items button')) return 'read';
  if (el.closest('a, button, [role=switch], label.switch, label.demo-switch, summary, .pnode-card')) return 'link';
  return 'default';
}

export default function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const label = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const fine = window.matchMedia('(hover: hover) and (pointer: fine)');
    if (!fine.matches) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const root = document.documentElement;
    root.classList.add('has-cursor');

    let x = -100, y = -100, rx = -100, ry = -100;
    let mode: Mode = 'default';
    let raf = 0;
    let magnet: HTMLElement | null = null;

    const setMode = (m: Mode) => {
      if (m === mode) return;
      mode = m;
      ring.current!.dataset.mode = m;
      dot.current!.dataset.mode = m;
      label.current!.textContent = LABEL[m] ?? '';
    };

    const onMove = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse') return;
      x = e.clientX; y = e.clientY;
      root.style.setProperty('--mx', `${x}px`);
      root.style.setProperty('--my', `${y}px`);
      dot.current!.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      root.classList.remove('cursor-out');
      // 磁吸：首屏按钮与导航轻轻跟随指针
      const m = (e.target as Element).closest?.('.hero-btn, .hero-nav nav a, .tour-btn') as HTMLElement | null;
      if (magnet && magnet !== m) { magnet.style.transform = ''; magnet = null; }
      if (m && !reduce) {
        const r = m.getBoundingClientRect();
        const dx = (x - (r.left + r.width / 2)) * 0.18, dy = (y - (r.top + r.height / 2)) * 0.28;
        m.style.transform = `translate(${dx}px, ${dy}px)`;
        magnet = m;
      }
    };
    const onOver = (e: PointerEvent) => setMode(modeOf(e.target as Element));
    const onDown = () => ring.current!.classList.add('is-down');
    const onUp = () => ring.current!.classList.remove('is-down');
    const onLeave = () => root.classList.add('cursor-out');

    const loop = () => {
      raf = requestAnimationFrame(loop);
      const k = reduce ? 1 : 0.2;
      rx += (x - rx) * k; ry += (y - ry) * k;
      ring.current!.style.transform = `translate3d(${rx}px, ${ry}px, 0)`;
    };
    raf = requestAnimationFrame(loop);

    window.addEventListener('pointermove', onMove, { passive: true });
    document.addEventListener('pointerover', onOver, { passive: true });
    window.addEventListener('pointerdown', onDown, { passive: true });
    window.addEventListener('pointerup', onUp, { passive: true });
    document.documentElement.addEventListener('pointerleave', onLeave);
    return () => {
      cancelAnimationFrame(raf);
      root.classList.remove('has-cursor');
      window.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerover', onOver);
      window.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointerup', onUp);
      document.documentElement.removeEventListener('pointerleave', onLeave);
    };
  }, []);

  return (
    <>
      <div ref={ring} className="cursor-ring" data-mode="default" aria-hidden="true"><span ref={label} className="cursor-label" /></div>
      <div ref={dot} className="cursor-dot" data-mode="default" aria-hidden="true" />
    </>
  );
}
