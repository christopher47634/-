import { ArrowLeft, Check } from 'lucide-react';
import { useState } from 'react';
import { eventById } from '../data/content';
import type { WatchItem } from '../data/types';
import { back, go } from '../logic/router';
import { getState, saveWatch, storageOK, updateWatch } from '../logic/store';
import { makeWatch } from '../logic/watch';

/*
 * 关注已经一键完成；这里只是「加笔记 / 改观察项」的可选页。
 * 保存时版本（savedVersion）不随编辑改变；依据取当前有效版本（审阅 B）。
 */
export default function WatchEdit({ eventId, watchId }: { eventId: string; watchId?: string }) {
  const ev = eventById(eventId);
  const [form, setForm] = useState<WatchItem>(() => getState().watches.find((w) => w.watchId === watchId) ?? makeWatch(getState(), eventId));
  const [saved, setSaved] = useState(false);
  if (!ev) return null;

  const set = (k: keyof WatchItem) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const custom = !ev.watchSuggestions.includes(form.nextCheck);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    // 已有的卡原位更新，不改变「我的关注」里的顺序；新卡才放到最前
    if (getState().watches.some((w) => w.watchId === form.watchId)) updateWatch(form);
    else saveWatch(form);
    setSaved(true);
    setTimeout(() => go('#/watch'), 500);
  };

  return (
    <div className="page">
      <header className="topbar is-glass">
        <button className="icon-btn" onClick={() => back(`#/e/${eventId}`)} aria-label="返回"><ArrowLeft size={21} strokeWidth={1.7} /></button>
        <span className="topbar-title">加笔记</span>
        <span style={{ width: 44 }} />
      </header>

      <form className="card-form" onSubmit={save}>
        <h1 className="form-title">{ev.question}</h1>
        <p className="note">已经关注。下面都是可选项，只保存在这台设备上。</p>

        <label className="field">
          <span>我的笔记</span>
          <textarea rows={4} value={form.note} onChange={set('note')} placeholder="写下你想弄清楚的问题，只有你能看到" autoFocus />
        </label>
        <label className="field">
          <span>下次要看的材料</span>
          <select value={custom ? '__custom' : form.nextCheck} onChange={(e) => setForm((f) => ({ ...f, nextCheck: e.target.value === '__custom' ? '' : e.target.value }))}>
            {ev.watchSuggestions.map((w) => <option key={w} value={w}>{w}</option>)}
            <option value="__custom">自己写…</option>
          </select>
          {custom && <input value={form.nextCheck} onChange={set('nextCheck')} placeholder="例如「下一期经营现金流披露」；没有官方日期就写「尚未公布」" />}
        </label>

        <details className="field-more">
          <summary>关注的依据（已自动填好）</summary>
          <label className="field">
            <span>当前依据</span>
            <textarea rows={3} value={form.basis} onChange={set('basis')} />
          </label>
          <label className="field">
            <span>仍未明确的问题</span>
            <textarea rows={2} value={form.openQuestion} onChange={set('openQuestion')} />
          </label>
        </details>

        {!storageOK && <p className="small warn">本地存储不可用：本次保存只在当前打开期间有效。</p>}
        <button className="btn btn-primary btn-block" type="submit" disabled={saved || !form.nextCheck.trim()}>
          {saved ? <><Check size={18} aria-hidden="true" /> 已保存</> : '保存'}
        </button>
      </form>
    </div>
  );
}
