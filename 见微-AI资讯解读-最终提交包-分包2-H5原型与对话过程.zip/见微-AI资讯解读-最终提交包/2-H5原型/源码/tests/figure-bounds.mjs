// 图表越界检查：首页（手机 / 桌面）和每一篇详情里，所有图表的线条、柱、点都不能画到 SVG 外面。
// 用法：node tests/figure-bounds.mjs <地址>
import { launch, sleep } from './cdp.mjs';

const BASE = process.argv[2] ?? 'http://localhost:5188/';
const b = await launch();
const bad = [];
const scan = async (where) => {
  await sleep(2200); // 等入场动效结束
  const r = await b.ev(`[...document.querySelectorAll('svg.fig-svg')].flatMap((svg)=>{const s=svg.getBoundingClientRect();return [...svg.querySelectorAll('line,rect,circle')].filter((e)=>!e.closest('defs')).map((e)=>{const r=e.getBoundingClientRect();return (r.left<s.left-2||r.right>s.right+2)?(svg.getAttribute('aria-label')+' '+e.getAttribute('class')+' '+Math.round(r.left-s.left)+'..'+Math.round(r.right-s.right)):null}).filter(Boolean)})`);
  const n = await b.ev(`document.querySelectorAll('svg.fig-svg').length`);
  if (r.length) bad.push(`${where}: ${[...new Set(r)].join(' | ')}`);
  // 行标签不能和数值、柱子、点重叠（例如长标签「固定资产投资（1—8 月）」压住「−7.2%」）
  const ov = await b.ev(`[...document.querySelectorAll('svg.fig-svg')].flatMap((svg)=>[...svg.querySelectorAll('.fig-label')].map((l)=>{const a=l.getBoundingClientRect();const hit=[...(l.parentNode.querySelectorAll('.fig-value,.fig-bar,.fig-dot'))].find((v)=>{const c=v.getBoundingClientRect();return c.width>0&&a.right>c.left+1&&c.right>a.left+1&&a.bottom>c.top+1&&c.bottom>a.top+1});return hit?(svg.getAttribute('aria-label')+'：'+l.textContent):null}).filter(Boolean))`);
  if (ov.length) bad.push(`${where} 重叠: ${[...new Set(ov)].join(' | ')}`);
  return n;
};
const ids = await (async () => { await b.viewport(390, 844); await b.send('Page.navigate', { url: BASE }); await sleep(1500); return b.ev(`[...new Set([...document.querySelectorAll('a[href^="#/e/"]')].map(a=>a.getAttribute('href')))]`); })();
let figs = 0;
for (const [w, h] of [[390, 844], [1440, 900]]) {
  await b.viewport(w, h);
  await b.send('Page.navigate', { url: BASE.replace(/#.*$/, '') + '#/' });
  await sleep(800);
  await b.ev(`(async()=>{for(let y=0;y<document.documentElement.scrollHeight;y+=400){scrollTo(0,y);await new Promise(r=>setTimeout(r,120))}})()`);
  figs += await scan(`首页 ${w}`);
  for (const id of ids) {
    await b.go(id);
    await b.ev(`(async()=>{for(let y=0;y<document.documentElement.scrollHeight;y+=500){scrollTo(0,y);await new Promise(r=>setTimeout(r,80))}})()`);
    figs += await scan(`${id} ${w}`);
  }
}
b.close();
console.log(`检查了 ${ids.length} 篇详情 + 首页，两个宽度，共 ${figs} 张图`);
console.log(bad.length ? '越界：\n' + bad.join('\n') : '没有越界');
process.exit(bad.length ? 1 : 0);
