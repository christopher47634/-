import { offMetricIds } from '../logic/evidence';
import { getState } from '../logic/store';
import { ArrowDown, ArrowUpRight, Bookmark } from 'lucide-react';
import { type CSSProperties, useEffect, useMemo, useRef, useState } from 'react';
import { EVENTS, TOPICS } from '../data/content';
import { ScoreChips, SortBar } from '../components/RankBits';
import { type Ranked, rankEvents } from '../logic/rank';
import Figure from '../components/Figure';
import HeroInk from '../components/HeroInk';
import { KindBadge, Reveal, Seal, ThemeSelect, ThemeToggle, coverOf } from '../components/bits';
import { setDemoMode, useStore } from '../logic/store';
import { Watches } from './Home';
import type { HomeTab } from '../logic/router';
import { LiveList, LiveStrip } from '../components/LiveBits';
import { FinHome, FinTeaser } from './Fin';

/*
 * 桌面首页：参考 noomo「The Power of Storytelling」的叙事节奏——
 * 深色首屏里指针带出光流，大号衬线标题逐行升起；向下滚动时一张纸从下方盖上来，进入安静的阅读区。
 * 首屏只负责「开场」，正文区不放任何动态背景。
 */
export default function HomeDesktop({ tab }: { tab: HomeTab }) {
  const watches = useStore((s) => s.watches);
  const demo = useStore((s) => s.demoMode);
  const heroRef = useRef<HTMLElement>(null);

  // 滚动进度 → CSS 变量：首屏文字上移、变淡，画面轻微压暗
  useEffect(() => {
    const el = heroRef.current;
    if (!el || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let raf = 0;
    const on = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const p = Math.min(1, Math.max(0, window.scrollY / (el.offsetHeight * 0.85)));
        el.style.setProperty('--p', p.toFixed(3));
      });
    };
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => { window.removeEventListener('scroll', on); cancelAnimationFrame(raf); };
  }, [tab]);

  const lines = ['读懂变化，', '看清依据，', '知道接下来验证什么。'];

  return (
    <div className={`dk dk-${tab}`}>
      <section ref={heroRef} className={`hero${tab !== 'feed' ? ' hero-short' : ''}`}>
        <HeroInk />
        <header className="hero-nav">
          <a className="hero-brand" href="#/" aria-label="见微 首页"><Seal size={32} /><span>见微</span><em>AI 资讯解读</em></a>
          <div className="hero-right">
          <nav aria-label="首页入口">
            <a href="#/" className={tab === 'feed' ? 'on' : ''} aria-current={tab === 'feed' ? 'page' : undefined}>精选解读</a>
            <a href="#/live" className={tab === 'live' ? 'on' : ''} aria-current={tab === 'live' ? 'page' : undefined}>实时快讯</a>
            <a href="#/fin" className={tab === 'fin' ? 'on' : ''} aria-current={tab === 'fin' ? 'page' : undefined}>财报对比</a>
            <a href="#/watch" className={tab === 'watch' ? 'on' : ''} aria-current={tab === 'watch' ? 'page' : undefined}>
              <Bookmark size={15} strokeWidth={1.8} aria-hidden="true" /> 我的关注{watches.length > 0 && <span className="num"> {watches.length}</span>}
            </a>
          </nav>
          <ThemeToggle className="on-night" />
          </div>
        </header>

        {tab === 'feed' ? (
          <div className="hero-copy">
            <h1 className="hero-title" aria-label={lines.join('')}>
              {lines.map((l, i) => (
                <span key={l} className="line" aria-hidden="true"><span style={{ '--i': i } as CSSProperties}>{l}</span></span>
              ))}
            </h1>
            <p className="hero-lede">
              一条财经资讯，拆成已经披露的事实、有前提的解释，和还不能下结论的地方。每个数字都能点回原文。
            </p>
            <div className="hero-cta">
              <a className="hero-btn" href="#feed" onClick={(e) => { e.preventDefault(); document.getElementById('feed')?.scrollIntoView({ behavior: 'smooth' }); }}>
                开始阅读 <ArrowDown size={16} strokeWidth={2} aria-hidden="true" />
              </a>
              <span className="hero-note">实时快讯 · 4 家公司财报对比 · 10 条逐句核对的解读</span>
            </div>
          </div>
        ) : tab === 'live' ? (
          <div className="hero-copy">
            <h1 className="hero-title hero-title-sm"><span className="line"><span>实时快讯</span></span></h1>
            <p className="hero-lede">打开页面时从公开接口实时获取，每 60 秒刷新；按重要程度和关注度排序。快讯没有经过逐句核对。</p>
          </div>
        ) : tab === 'fin' ? (
          <div className="hero-copy">
            <h1 className="hero-title hero-title-sm"><span className="line"><span>财报对比</span></span></h1>
            <p className="hero-lede">这一期比上一期、比去年同期，变好了还是变差了？单季数由累计数推算，每一步都能对回原文。</p>
          </div>
        ) : (
          <div className="hero-copy">
            <h1 className="hero-title hero-title-sm"><span className="line"><span>我的关注</span></span></h1>
            <p className="hero-lede">原文被更正、解释有变化时，这里会提示。只保存在这台设备上。</p>
          </div>
        )}
        {tab === 'feed' && <div className="hero-scroll" aria-hidden="true"><span /></div>}
      </section>

      <section className="sheet-paper" id="feed">
        {tab === 'feed' && <DeskFeed demo={demo} />}
        {tab === 'live' && <div className="dk-narrow"><SortBar /><LiveList /></div>}
        {tab === 'fin' && <div className="dk-mid"><FinHome /></div>}
        {tab === 'watch' && <div className="dk-narrow"><Watches demo={demo} /></div>}
        <footer className="dk-foot">
          <details className="about">
            <summary>关于这些样本</summary>
            <p>三类内容，可信程度不同，页面上分别标注。<b>实时快讯</b>和<b>接口财报数据</b>在打开页面时从东方财富等公开接口实时获取，取不到时退回离线快照，并写明采集时间；这两类没有经过逐句核对。<b>精选解读</b>和<b>四家公司的财报对比</b>的每个数字都逐句核对过原文，包括 2026 年 8–9 月国家统计局、美联储的官方发布，2026 年半年报与一季报，以及 2025 年的历史案例。精选解读排序中的「大众热度」是演示用模拟值，快讯的热度来自来源网站的真实评论与分享。教学案例为假设情境。解读由 AI 辅助整理，审核标识为演示用的「模拟审核」。本页不构成投资建议。</p>
          </details>
          <label className="demo-switch">
            <input type="checkbox" role="switch" checked={demo} onChange={(e) => setDemoMode(e.target.checked)} />
            <span className="switch-track" aria-hidden="true"><span /></span>
            <span>演示模式<span className="dim">（评审用：内容工作台、异常场景）</span></span>
          </label>
          {demo && <a className="foot-link" href="#/studio">打开内容工作台 <ArrowUpRight size={14} aria-hidden="true" /></a>}
          <ThemeSelect />
        </footer>
      </section>
    </div>
  );
}

function DeskFeed({ demo }: { demo: boolean }) {
  const [topic, setTopic] = useState('全部');
  const s = useStore((x) => x);
  const list = useMemo(() => rankEvents(s, EVENTS.filter((e) => (demo || !e.demoOnly) && (topic === '全部' || e.topic === topic)), s.sort), [topic, demo, s]);
  const [lead, ...rest] = list;
  return (
    <>
      <div className="dk-filter">
        <h2 className="dk-h">精选解读 <span className="dk-h-sub">每个数字都核对过原文</span></h2>
        <div className="topics" role="group" aria-label="主题筛选">
          {TOPICS.map((t) => (
            <button key={t} className={`topic${topic === t ? ' on' : ''}`} aria-pressed={topic === t} onClick={() => setTopic(t)}>{t}</button>
          ))}
        </div>
      </div>
      <SortBar />
      {lead && <DeskLead key={lead.ev.id} r={lead} />}
      {topic === '全部' && (
        <div className="dk-live-fin">
          <LiveStrip />
          <FinTeaser />
        </div>
      )}
      <div className="dk-grid">
        {rest.map((r, i) => <DeskCard key={r.ev.id} r={r} i={i} />)}
      </div>
    </>
  );
}

function DeskLead({ r }: { r: Ranked }) {
  const ev = r.ev;
  const cover = coverOf(ev.id);
  return (
    <Reveal as="article" className="dk-lead">
      <a className="dk-lead-text" href={`#/e/${ev.id}`}>
        <div className="meta"><KindBadge ev={ev} /><span>{ev.topic}</span><span className="num">{ev.sourceDate}</span></div>
        <ScoreChips sc={r.sc} rank={r.rank} />
        <h3 className="dk-lead-title">{ev.question}</h3>
        <p className="dk-lead-answer">{ev.answer}</p>
        <p className="dk-lead-fact">{ev.title}</p>
        <span className="dk-more">读完整解读 · 约 {ev.readMins} 分钟 <ArrowUpRight size={16} aria-hidden="true" /></span>
      </a>
      <div className="dk-lead-fig">
        {cover ? <img className="cover" src={cover} alt="" /> : ev.figure && <Figure fig={ev.figure} off={offMetricIds(getState(), ev)} />}
      </div>
    </Reveal>
  );
}

function DeskCard({ r, i }: { r: Ranked; i: number }) {
  const ev = r.ev;
  const cover = coverOf(ev.id);
  return (
    <Reveal as="article" className="dk-card" delay={(i % 2) * 90}>
      <a href={`#/e/${ev.id}`}>
        {cover && <img className="cover" src={cover} alt="" loading="lazy" />}
        <div className="meta"><KindBadge ev={ev} /><span>{ev.topic}</span><span className="num">{ev.sourceDate}</span></div>
        <ScoreChips sc={r.sc} rank={r.rank} />
        <h3 className="dk-card-title">{ev.question}</h3>
        <p className="dk-card-answer">{ev.answer}</p>
        {!cover && ev.figure && <Figure fig={ev.figure} compact off={offMetricIds(getState(), ev)} />}
        <span className="dk-card-src">{ev.sourceLabel}<ArrowUpRight size={15} aria-hidden="true" /></span>
      </a>
    </Reveal>
  );
}
