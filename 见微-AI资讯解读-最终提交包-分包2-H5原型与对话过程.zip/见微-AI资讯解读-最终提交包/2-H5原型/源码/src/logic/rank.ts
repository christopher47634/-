import { EVENTS, FACTS, sourceById } from '../data/content';
import type { EventItem, RankScope } from '../data/types';
import type { State } from './store';
import { watchStatus } from './watch';

/*
 * 两套评分，决定首页展示顺序（v0.7）
 *
 * 重要程度（0–100）：这条消息本身有多重要，和谁在看无关。五个维度，全部可解释：
 *   影响范围 20 · 来源权威 15 · 变化幅度 20 · 政策关联 20 · 时效 25（资讯流里时效权重最高，历史案例自然排后）
 * 用户关注度（0–100）：这位读者可能有多在意。
 *   大众热度 × 0.6（演示模拟值，正式环境用站内阅读、搜索与关注数据）
 *   + 与我相关 × 0.4（只用本机行为：关心的主题、关注过的问题、读过的内容；不收集持仓与资产）
 * 综合分 = 重要程度 × 0.65 + 关注度 × 0.35
 *
 * 护栏：头条位只给重要程度 ≥ 70 的资讯——热度再高、重要程度不够，也不上头条，避免标题党靠热度占位。
 * 分数只决定顺序，不代表投资价值，也不代表「更值得买」。
 */

export const RANK_DATE = '2026-09-28'; // 资讯池更新日期；时效分按它计算，保证演示可复现
export const W = { scope: 20, authority: 15, magnitude: 20, policy: 20, recency: 25 } as const;
export const ATTN = { heat: 0.6, personal: 0.4 } as const;
export const MIX = { importance: 0.65, attention: 0.35 } as const;
export const LEAD_MIN = 70;

const SCOPE: Record<RankScope, [number, string]> = {
  global: [5, '全球性（主要央行、全球市场）'],
  macro: [5, '全国宏观'],
  sector: [4, '单一行业，影响面较广'],
  company: [3, '单一公司'],
  teaching: [0, '教学或虚构，不是新闻'],
};

export interface Dim { key: string; label: string; score: number; max: number; weight: number; points: number; why: string }
export interface Score { importance: number; attention: number; total: number; dims: Dim[]; attnDims: Dim[]; simulatedHeat: boolean }

const round = (x: number) => Math.round(x);
const days = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86400000);

/** 事件日期：取 sourceDate 开头的 YYYY-MM-DD；取不到（演示时钟）视为很久以前 */
export function eventDate(ev: EventItem): string | null {
  const m = /^(\d{4}-\d{2}-\d{2})/.exec(ev.sourceDate);
  return m ? m[1] : null;
}

export function recencyScore(ev: EventItem, today = RANK_DATE): [number, string] {
  const d = eventDate(ev);
  if (!d) return [0, '没有真实发布日期'];
  const n = days(d, today);
  if (n <= 3) return [5, `${n} 天内发布`];
  if (n <= 10) return [4, `${n} 天前发布`];
  if (n <= 31) return [3, `${n} 天前发布`];
  if (n <= 90) return [2, `${n} 天前发布`];
  if (n <= 180) return [1, `约 ${Math.round(n / 30)} 个月前`];
  return [0, `历史案例，约 ${Math.round(n / 30)} 个月前`];
}

/** 来源权威：看这条资讯事实用到的来源——一手官方 5，官方转述 3，虚构 0 */
export function authorityScore(ev: EventItem): [number, string] {
  const srcs = [...new Set(FACTS.filter((f) => f.eventId === ev.id).flatMap((f) => f.sourceIds))].map(sourceById).filter(Boolean);
  if (!srcs.length || srcs.every((s) => s!.kind === 'hypothetical')) return [0, '虚构或教学来源'];
  if (srcs.some((s) => s!.kind === 'real' && s!.status === 'original')) return [5, '有一手官方原文'];
  return [3, '只有转述来源'];
}

const dim = (key: string, label: string, [score, why]: [number, string], weight: number, max = 5): Dim => ({ key, label, score, max, weight, points: (score / max) * weight, why });

export function importance(ev: EventItem): { value: number; dims: Dim[] } {
  const sg = ev.signals ?? { scope: 'teaching' as RankScope, magnitude: [0, '未评估'] as [number, string], policy: [0, '未评估'] as [number, string], heat: 0 };
  const dims = [
    dim('scope', '影响范围', SCOPE[sg.scope], W.scope),
    dim('authority', '来源权威', authorityScore(ev), W.authority),
    dim('magnitude', '变化幅度', sg.magnitude, W.magnitude),
    dim('policy', '政策关联', sg.policy, W.policy),
    dim('recency', '时效', recencyScore(ev), W.recency),
  ];
  return { value: round(dims.reduce((a, d) => a + d.points, 0)), dims };
}

/** 与我相关（0–100）：只看本机行为 */
export function personal(s: State, ev: EventItem): [number, string] {
  let v = 0;
  const why: string[] = [];
  if (s.topics.includes(ev.topic)) { v += 35; why.push(`你关心「${ev.topic}」`); }
  const watchedIds = s.watches.map((w) => w.eventId);
  const watchedEvents = EVENTS.filter((e) => watchedIds.includes(e.id));
  if (watchedIds.includes(ev.id)) {
    const w = s.watches.find((x) => x.eventId === ev.id)!;
    if (watchStatus(s, w).tone !== 'ok') { v += 45; why.push('你关注的问题有变化'); }
    else { v += 10; why.push('你已关注'); }
  } else if (watchedEvents.some((e) => e.related?.includes(ev.id) || ev.related?.includes(e.id))) {
    v += 40; why.push('和你关注的问题相关');
  } else if (watchedEvents.some((e) => e.topic === ev.topic)) {
    v += 20; why.push('和你关注的内容同主题');
  }
  const read = new Set(s.track.filter((t) => t.name === 'article_open').map((t) => t.key));
  const sameTopicRead = EVENTS.filter((e) => e.id !== ev.id && e.topic === ev.topic && read.has(e.id)).length;
  if (sameTopicRead) { v += Math.min(20, sameTopicRead * 10); why.push(`读过 ${sameTopicRead} 篇同主题`); }
  if (read.has(ev.id) && !watchedIds.includes(ev.id)) { v -= 15; why.push('已读过（降低重复）'); }
  v = Math.max(0, Math.min(100, v));
  return [v, why.length ? why.join('；') : '还没有相关的阅读或关注记录'];
}

export function score(s: State, ev: EventItem): Score {
  const imp = importance(ev);
  const heat = ev.signals?.heat ?? 0;
  const [p, pWhy] = personal(s, ev);
  const attnDims: Dim[] = [
    { key: 'heat', label: '大众热度（模拟）', score: heat, max: 100, weight: ATTN.heat * 100, points: heat * ATTN.heat, why: '演示用模拟值；正式环境用站内阅读、搜索与关注数据' },
    { key: 'personal', label: '与我相关', score: p, max: 100, weight: ATTN.personal * 100, points: p * ATTN.personal, why: pWhy },
  ];
  const attention = round(attnDims.reduce((a, d) => a + d.points, 0));
  return { importance: imp.value, attention, total: round(imp.value * MIX.importance + attention * MIX.attention), dims: imp.dims, attnDims, simulatedHeat: true };
}

export type SortMode = 'mix' | 'importance' | 'attention';
export const SORT_LABEL: Record<SortMode, string> = { mix: '综合', importance: '重要程度', attention: '与我相关' };

export interface Ranked { ev: EventItem; sc: Score; rank: number }

/**
 * 排序：按所选分数降序，分数相同按时效。
 * 头条护栏：综合与关注度排序时，排第一的必须重要程度 ≥ LEAD_MIN；不满足就把第一条达标的提上来。
 */
export function rankEvents(s: State, list: EventItem[], mode: SortMode = 'mix'): Ranked[] {
  const key = (sc: Score) => (mode === 'importance' ? sc.importance : mode === 'attention' ? sc.attention : sc.total);
  const scored = list.map((ev) => ({ ev, sc: score(s, ev) }));
  scored.sort((a, b) => key(b.sc) - key(a.sc) || b.sc.importance - a.sc.importance || (eventDate(b.ev) ?? '').localeCompare(eventDate(a.ev) ?? ''));
  const i = scored.findIndex((x) => x.sc.importance >= LEAD_MIN);
  if (i > 0) scored.unshift(scored.splice(i, 1)[0]);
  return scored.map((x, k) => ({ ...x, rank: k + 1 }));
}

/** 一句话说明为什么排在这里（给卡片与详情用） */
export function rankReason(sc: Score): string {
  const top = [...sc.dims].sort((a, b) => b.points - a.points).slice(0, 2).map((d) => d.label);
  const p = sc.attnDims.find((d) => d.key === 'personal')!;
  return `重要程度主要来自${top.join('、')}${p.score > 0 ? `；${p.why}` : ''}`;
}
