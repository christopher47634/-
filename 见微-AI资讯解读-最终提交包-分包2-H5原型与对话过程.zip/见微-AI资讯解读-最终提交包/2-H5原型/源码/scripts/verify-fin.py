# 核对 src/data/earnings2026.ts 里每一行原文摘录：PDF 对应页（去掉空白后）必须包含摘录（去掉空白后），
# 且摘录里的两个数字换算后等于 cur / prev。PDF 放在 ../research/earnings-2026/（巨潮资讯网下载）。
# 用法：python scripts/verify-fin.py  → 结果写到 ../research/earnings-2026/verify-result.json
import json, re, sys, pathlib
from pypdf import PdfReader

ROOT = pathlib.Path(__file__).resolve().parent.parent
PDF_DIR = ROOT.parent / 'research' / 'earnings-2026'
src = (ROOT / 'src' / 'data' / 'earnings2026.ts').read_text(encoding='utf-8')

FILE = {'MT': '600519', 'BYD': '002594', 'CATL': '300750', 'SMIC': '688981'}
urls = dict(re.findall(r"id: '([A-Z]+-(?:H1|Q1))'.*?url: `\$\{CN\}([^`]+)`", src))
line_re = re.compile(r"L\('([A-Z]+-(?:H1|Q1))', '(元|千元)', '(\w+)', (\d+), '([^']+)', '([^']+)', '([^']+)'\)")
reason_re = re.compile(r"\{ reportId: '([A-Z]+-(?:H1|Q1))', page: (\d+), explains: '[^']*', quote: '([^']+)' \}")
norm = lambda s: re.sub(r'\s+', '', s)
cache = {}
def page_text(rid, page):
    co, kind = rid.split('-')
    f = PDF_DIR / f"{FILE[co]}-{kind}.pdf"
    if f not in cache: cache[f] = PdfReader(str(f))
    return norm(cache[f].pages[page - 1].extract_text() or '')

results, bad = [], 0
for rid, unit, metric, page, quote, cur, prev in line_re.findall(src):
    t = page_text(rid, int(page))
    ok_quote = norm(quote) in t
    ok_nums = cur in quote and prev in quote
    ok = ok_quote and ok_nums
    bad += not ok
    results.append({'kind': 'line', 'report': rid, 'page': int(page), 'metric': metric, 'quoteFound': ok_quote, 'numbersInQuote': ok_nums})
for rid, page, quote in reason_re.findall(src):
    ok = norm(quote) in page_text(rid, int(page))
    bad += not ok
    results.append({'kind': 'reason', 'report': rid, 'page': int(page), 'quoteFound': ok, 'quote': quote[:30]})
out = PDF_DIR / 'verify-result.json'
out.write_text(json.dumps({'checked': len(results), 'failed': bad, 'results': results}, ensure_ascii=False, indent=1), encoding='utf-8')
print(f'核对 {len(results)} 处摘录（{sum(r["kind"]=="line" for r in results)} 行数字 + {sum(r["kind"]=="reason" for r in results)} 条原因），失败 {bad}')
for r in results:
    if not (r.get('quoteFound') and r.get('numbersInQuote', True)): print('  ✗', r)
sys.exit(1 if bad else 0)
