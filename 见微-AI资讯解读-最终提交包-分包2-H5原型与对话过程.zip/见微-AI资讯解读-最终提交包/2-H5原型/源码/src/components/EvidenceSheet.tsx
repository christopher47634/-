import { Check, Copy, ExternalLink, Flag } from 'lucide-react';
import { useEffect, useState } from 'react';
import { factById, metricById, sourceById } from '../data/content';
import { evidenceLabel, factState } from '../logic/gate';
import { reportIssue, track, useStore } from '../logic/store';
import MetricEvidence, { MetricSwitch, metricTitle } from './MetricEvidence';
import Sheet from './Sheet';
import { Stopped } from './bits';

/** 抽屉里要看的依据：整条事实，或某一个数字（带同卡其它数字的切换） */
export type EvTarget = { kind: 'fact'; id: string } | { kind: 'metric'; id: string; ids: string[]; eventId: string };

export default function EvidenceSheet({ target, onClose, onSwitch }: { target: EvTarget | null; onClose: () => void; onSwitch?: (id: string) => void }) {
  const s = useStore((x) => x);
  if (target?.kind === 'metric') {
    const m = metricById(target.id);
    // 切换数字只换抽屉内容，不叠第二层弹窗
    return (
      <Sheet open onClose={onClose} title={m ? metricTitle(m) : '引用无效'} label={<span>核对原文{s.demoMode && <span className="mono"> · {target.id}</span>}</span>}>
        <MetricSwitch ids={target.ids} current={target.id} onPick={(id) => onSwitch?.(id)} eventId={target.eventId} />
        <MetricEvidence metricId={target.id} eventId={target.eventId} />
      </Sheet>
    );
  }
  const fact = target ? factById(target.id) : undefined;
  if (!fact) return <Sheet open={false} onClose={onClose} title="">{null}</Sheet>;
  return (
    <Sheet open onClose={onClose} title="原文依据" label={s.demoMode ? <span className="mono">{fact.id}</span> : undefined}>
      <EvidenceBody factId={fact.id} />
    </Sheet>
  );
}

/** 原文依据的内容：手机上放在底部抽屉里，桌面放在右侧依据栏里 */
export function EvidenceBody({ factId }: { factId: string }) {
  const s = useStore((x) => x);
  const [copied, setCopied] = useState(false);
  const [reporting, setReporting] = useState(false);
  const [text, setText] = useState('');
  const [sent, setSent] = useState(false);
  const fact = factId ? factById(factId) : undefined;

  useEffect(() => {
    setCopied(false); setReporting(false); setText(''); setSent(false);
    if (factId) track('source_open', factId);
  }, [factId]);

  if (!fact) return null;
  const fs = factState(s, fact);
  const sources = fact.sourceIds.map(sourceById).filter(Boolean);

  const copy = async () => {
    const src = sources[0]!;
    const line = `【见微 · AI 辅助整理，以原文为准】${fact.text}\n来源：${src.org}《${src.title}》${src.publishedAt}${src.url ? `\n${src.url}` : '（虚构示范来源）'}`;
    try {
      await navigator.clipboard.writeText(line);
      setCopied(true);
    } catch {
      window.prompt('复制以下引用', line);
    }
  };

  return (
    <div className="ev-body" key={fact.id}>
      <p className="ev-claim">{fact.text}</p>
      {fs === 'corrected' && <Stopped>这条事实已被更正，下方保留原来源供对照。更正后的数字请看同页的新版本事实。</Stopped>}
      {fs === 'missing' && <Stopped>来源暂不可用（模拟）。依赖它的解释已停止展示；来源恢复后自动重新检查。</Stopped>}

      <dl className="ev-grid">
        <div><dt>对象</dt><dd>{fact.subject}</dd></div>
        <div><dt>期间</dt><dd>{fact.period}</dd></div>
        {fact.value && <div><dt>数值</dt><dd className="num">{fact.value}</dd></div>}
        <div><dt>口径</dt><dd>{fact.caliber}</dd></div>
      </dl>

      <div className="ev-scope">
        <div className="scope-yes"><span>能支持</span>{fact.supports}</div>
        <div className="scope-no"><span>不能支持</span>{fact.notSupports}</div>
      </div>

      {sources.map((src) => {
        const missing = !!s.sourceMissing[src!.id];
        return (
          <article key={src!.id} className={`ev-source${missing ? ' is-missing' : ''}`}>
            <div className="ev-source-top">
              <span className={`evs evs-${missing ? 'unverified' : src!.status}`}>{missing ? '来源暂不可用' : evidenceLabel(src!.status)}</span>
              {s.demoMode && <span className="mono dim">{src!.id}</span>}
            </div>
            <h3 className="ev-org">{src!.org}</h3>
            <p className="ev-title">{src!.title}</p>
            <blockquote className="ev-quote">
              {src!.excerpt}
              <footer>{src!.excerptIsParaphrase ? '自写释义' : '原文短摘录'}</footer>
            </blockquote>
            {src!.url ? (
              <a className="btn btn-primary" href={src!.url} target="_blank" rel="noopener noreferrer">
                <ExternalLink size={16} strokeWidth={1.75} aria-hidden="true" /> 打开原文
              </a>
            ) : (
              <p className="dim small">虚构示范来源，没有原文链接。</p>
            )}
            <dl className="ev-meta">
              <div><dt>发布时间</dt><dd>{src!.publishedAt}</dd></div>
              <div><dt>在原文哪里</dt><dd>{src!.locator}</dd></div>
            </dl>
            <details className="ev-more">
              <summary>更多来源信息</summary>
              <dl className="ev-meta">
                <div><dt>来源链</dt><dd>{src!.chain}</dd></div>
                <div><dt>核验访问</dt><dd>{src!.accessedAt}</dd></div>
                <div><dt>版本</dt><dd>{src!.docVersion}</dd></div>
              </dl>
            </details>
          </article>
        );
      })}

      <div className="ev-actions">
        <button className="btn btn-ghost" onClick={copy}>
          {copied ? <Check size={16} aria-hidden="true" /> : <Copy size={16} strokeWidth={1.75} aria-hidden="true" />}
          {copied ? '已复制带标识引用' : '复制带标识引用'}
        </button>
        <button className="btn btn-ghost" onClick={() => setReporting((v) => !v)} aria-expanded={reporting}>
          <Flag size={16} strokeWidth={1.75} aria-hidden="true" /> 报告问题
        </button>
      </div>
      {reporting && (
        <div className="report">
          {sent ? (
            <p className="small">已记录在本机（演示）。正式环境会进入内容审核队列。</p>
          ) : (
            <>
              <label className="small" htmlFor="rep">哪里不对？例如数字与原文不一致、定位找不到</label>
              <textarea id="rep" rows={3} value={text} onChange={(e) => setText(e.target.value)} />
              <button className="btn btn-primary" disabled={!text.trim()} onClick={() => { reportIssue(sources[0]!.id, text.trim()); setSent(true); }}>
                提交到本机
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
