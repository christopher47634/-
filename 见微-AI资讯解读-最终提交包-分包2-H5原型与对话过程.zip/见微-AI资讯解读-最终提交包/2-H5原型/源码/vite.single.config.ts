import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import { fileURLToPath } from 'node:url';

// 单文件版：所有脚本、样式、字体都内嵌进一个 HTML，双击即可打开，不需要 Node 或网络。
// 字体用 scripts/subset-font.py 生成的裁剪版替换完整的 fontsource 分片。
export default defineConfig({
  base: './',
  plugins: [react(), viteSingleFile()],
  resolve: {
    alias: {
      '@fontsource/noto-serif-sc/600.css': fileURLToPath(new URL('./src/styles/font-embedded.css', import.meta.url)),
    },
  },
  build: { outDir: 'dist-single', emptyOutDir: true, assetsInlineLimit: 100_000_000, cssCodeSplit: false },
});
