import { ArrowLeft, Check } from 'lucide-react';
import { INSIGHTS, INTERPS, eventById } from '../data/content';
import { metricState } from '../logic/evidence';
import { KindBadge, StatusTag, Stopped } from '../components/bits';
import { interpEffective, isLive } from '../logic/gate';
import { back } from '../logic/router';
import { ackWatch, adoptSuggestedQuestion, useStore } from '../logic/store';
import { watchDiff, watchStatus } from '../logic/watch';

export default function Update({ watchId }: { watchId: string }) {
  const s = useStore((x) => x);
  const w = s.watches.find((x) => x.watchId === watchId);
  if (!w) return (
    <div className="page"><div className="empty-state"><h2>这条关注已不存在</h2><a className="btn btn-primary" href="#/watch">回到我的关注</a></div></div>
  );
  const ev = eventById(w.eventId)!;
  const st = watchStatus(s, w);
  const { added, corrected } = watchDiff(s, w);
  const newInterps = INTERPS.filter((i) => i.eventId === w.eventId && i.introducedIn && !w.interpIds.includes(i.id));

  return (
    <div className="page">
      <header className="topbar is-glass">
        <button className="icon-btn" onClick={() => back('#/watch')} aria-label="返回"><ArrowLeft size={21} strokeWidth={1.7} /></button>
        <span className="topbar-title">有什么变化</span>
        <span style={{ width: 44 }} />
      </header>

      <article className="reading">
        <div className="meta">
          <KindBadge ev={ev} />
          {st.simulated && <span className="tag tag-demo">演示更新 · 不是实时推送</span>}
        </div>
        <h1 className="headline">{ev.question}</h1>
        <p className="answer">你关注时是 <span className="mono">{w.savedVersion}</span>{st.seenVersion !== w.savedVersion && <>，上次看到 <span className="mono">{st.seenVersion}</span></>}，现在是 <span className="mono">{st.current}</span>。</p>

        <section className="upd">
          <h2 className="upd-h">新增了什么</h2>
          {added.length === 0 && corrected.length === 0 && <p className="dim">相对你上次看到的版本，没有新增或更正的事实。</p>}
          {added.map(({ fact, state }) => state === 'active'
            ? <p key={fact.id} className="diff-add">{fact.text}</p>
            : <Stopped key={fact.id}>新材料的来源暂不可用，先不展示内容。来源恢复后会重新检查。</Stopped>)}
          {corrected.map((f) => <p key={f.id} className="diff-del"><span>已被更正</span><s>{f.text}</s></p>)}
        </section>

        <section className="upd">
          <h2 className="upd-h">原来的解释受到什么影响</h2>
          <ul className="interps">
            {w.interpIds.map((id) => {
              const i = INTERPS.find((x) => x.id === id);
              if (!i) return null;
              const eff = interpEffective(s, i);
              return (
                <li key={id}>
                  <StatusTag status={eff.status} />
                  {isLive(eff) ? <p>{i.text}</p> : <><p>{eff.reason}</p><p className="small"><s className="dim">{i.text}</s></p></>}
                </li>
              );
            })}
          </ul>
          {newInterps.map((i) => {
            const eff = interpEffective(s, i);
            if (!isLive(eff)) return eff.status === 'hidden' ? null : <Stopped key={i.id}><StatusTag status={eff.status} /> 新版解释：{eff.reason}</Stopped>;
            return (
              <div key={i.id} className="diff-add">
                <p><strong>新版解释　</strong>{i.text}</p>
                <p className="small">局限：{i.limitations}</p>
              </div>
            );
          })}
        </section>

        {w.insightId && (() => {
          const ins = INSIGHTS.find((i) => i.id === w.insightId);
          return (
            <section className="upd">
              <h2 className="upd-h">你关注时依据的数字</h2>
              <p className="small dim">保存时：{w.basis}</p>
              {ins ? (
                <ul className="cov-list">
                  {ins.metricIds.map((id) => {
                    const m = metricState(s, id, w.eventId);
                    return (
                      <li key={id}>
                        <span>{m.metric?.label} <span className="num">{m.metric?.display}</span>{!m.usable && <span className="dim"> · {m.reason}</span>}</span>
                        <span className={`mx-st mx-st-${m.status}`}>{m.usable ? (m.status === 'partial' ? '部分来源不可用' : '仍可核对原文') : '不能作为有效事实'}</span>
                      </li>
                    );
                  })}
                </ul>
              ) : <Stopped>保存时的差异卡已不存在。</Stopped>}
            </section>
          );
        })()}

        <section className="upd">
          <h2 className="upd-h">还没回答的问题</h2>
          <p>{w.openQuestion}</p>
          {w.suggestedQuestion && (
            <p className="small">本卡建议的问题：「{w.suggestedQuestion}」 <button className="btn btn-ghost btn-sm" onClick={() => adoptSuggestedQuestion(w.watchId)}>改用这个问题</button></p>
          )}
          <p className="small dim">下次要看：{w.nextCheck}</p>
        </section>

        <section className="upd">
          <h2 className="upd-h">你的笔记</h2>
          <p className="small dim">和更新内容分开保存，更新不会改动它。</p>
          <p className="note-text">{w.note || '（还没有笔记）'}</p>
        </section>

        <div className="upd-actions">
          {st.unseenVersion ? (
            <button className="btn btn-primary btn-block" onClick={() => ackWatch(w.watchId, st.current)}>我已看过，采纳 {st.current}</button>
          ) : (
            <p className="acked"><Check size={16} aria-hidden="true" /> 已看过当前版本 {st.current}{st.tone !== 'ok' ? '；下方状态会一直保留到解释恢复' : ''}</p>
          )}
          <a className="btn btn-ghost btn-block" href={`#/watch/edit/${w.eventId}/${w.watchId}`}>{w.note ? '改笔记' : '加笔记'}</a>
        </div>
      </article>
    </div>
  );
}
