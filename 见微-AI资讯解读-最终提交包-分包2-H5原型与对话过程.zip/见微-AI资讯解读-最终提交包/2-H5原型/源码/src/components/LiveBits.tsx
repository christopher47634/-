import { ArrowUpRight, ChevronDown, RefreshCw } from 'lucide-react';
import { useEffect, useId, useMemo, useState } from 'react';
import { EVENTS } from '../data/content';
import { curatedBySecu } from '../data/earnings2026';
import { SNAPSHOT_AT, refreshNews, useLive, useNewsAutoRefresh } from '../logic/live';
import { LIVE_IMPORTANT, type LiveRanked, liveCompanies, liveRelated, rankLive } from '../logic/liveRank';
import { MIX } from '../logic/rank';
import { track, useStore } from '../logic/store';
import { DimRow, ScoreChips } from './RankBits';

/*
 * 实时快讯（v0.8）：取自公开接口，没有经过编辑核验。
 * 页面上始终标明三件事：数据是实时的还是离线快照、什么时候取的、这条快讯没有逐句核对。
 * 快讯可以把读者带到两类「有依据」的内容：相关的精选解读、提到的公司的财报对比。
 */

const hm = (iso: string) => {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
};

/** 每 30 秒重算一次「几分钟前」 */
export function useNow(ms = 30_000) {
  const [n, setN] = useState(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setN(Date.now()), ms);
    return () => window.clearInterval(t);
  }, [ms]);
  return n;
}

export function LiveStatus() {
  const news = useLive((s) => s.news);
  const [busy, setBusy] = useState(false);
  const cls = news.status === 'live' ? 'is-live' : news.status === 'loading' ? 'is-loading' : 'is-snap';
  const text =
    news.status === 'live'
      ? <>实时 · {hm(news.at)} 更新 · {news.source} · 每 60 秒自动刷新{news.error ? `（最近一次刷新失败：${news.error}，仍显示 ${hm(news.at)} 的数据）` : ''}</>
      : news.status === 'loading'
        ? <>正在连接实时接口…先显示离线快照（采集于 {hm(SNAPSHOT_AT)}）</>
        : <>离线快照 · 采集于 {hm(news.at)}{news.tried ? ` · 实时接口暂时取不到（${news.error ?? '未知原因'}）` : ''}</>;
  return (
    <p className={`live-status ${cls}`} role="status" data-status={news.status}>
      <span className="live-dot" aria-hidden="true" />
      <span className="live-status-text">{text}</span>
      <button className="live-refresh" aria-label="立即刷新快讯" disabled={busy} onClick={async () => { setBusy(true); await refreshNews(); setBusy(false); }}>
        <RefreshCw size={14} strokeWidth={2} aria-hidden="true" className={busy ? 'spin' : ''} />
      </button>
    </p>
  );
}

function useRankedLive() {
  const s = useStore((x) => x);
  const news = useLive((x) => x.news);
  const tick = useNow();
  const now = news.status === 'live' ? tick : Date.parse(news.at);
  return useMemo(() => rankLive(s, news.items, s.sort, now), [s, news, now]);
}

export function LiveRow({ r }: { r: LiveRanked }) {
  const { it, sc } = r;
  const [open, setOpen] = useState(false);
  const rid = useId();
  const related = liveRelated(it);
  const ev = related ? EVENTS.find((e) => e.id === related) : undefined;
  const cos = liveCompanies(it);
  return (
    <li className={`live-row${open ? ' is-open' : ''}`} data-id={it.id}>
      <button className="live-head" aria-expanded={open} aria-controls={rid} onClick={() => { setOpen((v) => !v); track('live_open', it.id); }}>
        <span className="live-meta">
          <span className="num live-time">{it.time.slice(11, 16)}</span>
          <span className="tag tag-live">快讯 · 未核验</span>
          <span>{r.topic}</span>
          {it.flagged && <span className="tag">来源标红</span>}
        </span>
        <ScoreChips sc={sc} rank={r.rank} />
        <span className="live-title">{it.title}</span>
        <ChevronDown size={17} strokeWidth={1.75} aria-hidden="true" className="live-chev" />
      </button>
      {open && (
        <div className="live-body" id={rid}>
          {it.summary && <p className="live-summary">{it.summary}</p>}
          <p className="small dim">{it.source} · {it.time}（北京时间）· 这条快讯没有经过编辑核对原文，数字以原始发布为准。</p>
          <div className="live-links">
            <a className="btn btn-ghost btn-sm" href={it.url} target="_blank" rel="noopener noreferrer">打开{it.source}原文 <ArrowUpRight size={14} aria-hidden="true" /></a>
            {ev && <a className="btn btn-ghost btn-sm" href={`#/e/${ev.id}`}>相关的精选解读：{ev.question}</a>}
            {cos.slice(0, 2).map((c) => (
              <a key={c} className="btn btn-ghost btn-sm" href={`#/fin/${c}`}>看 {curatedBySecu(c)?.name ?? c.slice(0, 6)} 的财报对比</a>
            ))}
          </div>
          <details className="live-why">
            <summary>为什么排在第 {r.rank} 位</summary>
            <h4>重要程度 {sc.importance}</h4>
            <ul className="rk-list">{sc.dims.map((d) => <DimRow key={d.key} d={d} unit="five" />)}</ul>
            <h4>用户关注度 {sc.attention}</h4>
            <ul className="rk-list">{sc.attnDims.map((d) => <DimRow key={d.key} d={d} unit="hundred" />)}</ul>
            <p className="small dim">综合 {sc.total} = 重要程度 × {MIX.importance} + 关注度 × {MIX.attention}。影响范围、幅度、政策三项由关键词规则自动判断；来源热度是{it.source}页面上的真实数据。分数只决定展示顺序，不代表投资价值。</p>
          </details>
        </div>
      )}
    </li>
  );
}

/** 快讯列表（快讯页用） */
export function LiveList() {
  useNewsAutoRefresh();
  const list = useRankedLive();
  const [onlyKey, setOnlyKey] = useState(false);
  const shown = onlyKey ? list.filter((r) => r.sc.importance >= LIVE_IMPORTANT) : list;
  return (
    <section className="live" aria-label="实时快讯">
      <LiveStatus />
      <label className="live-filter">
        <input type="checkbox" checked={onlyKey} onChange={(e) => setOnlyKey(e.target.checked)} />
        只看重要（重要程度 ≥ {LIVE_IMPORTANT}）<span className="dim num">· {shown.length}/{list.length} 条</span>
      </label>
      <ol className="live-list">{shown.map((r) => <LiveRow key={r.it.id} r={r} />)}</ol>
      {!shown.length && <p className="note">现在没有达到这个重要程度的快讯。</p>}
      <p className="note">快讯取自{list[0]?.it.source ?? '东方财富'} 7×24 公开接口，按与精选解读相同的两套评分排序：影响范围、幅度、政策三项由关键词规则判断，来源热度用评论、分享和编辑标红这些真实数据。快讯没有经过逐句核对；需要核对的内容，请看精选解读和财报对比。</p>
    </section>
  );
}

/** 首页顶部的快讯条：只放前 3 条 */
export function LiveStrip() {
  useNewsAutoRefresh();
  const list = useRankedLive();
  return (
    <section className="live-strip" aria-label="实时快讯（前 3 条）">
      <div className="live-strip-head">
        <h2>实时快讯</h2>
        <a href="#/live" className="live-more">全部 {list.length} 条 <ArrowUpRight size={14} aria-hidden="true" /></a>
      </div>
      <LiveStatus />
      <ol className="live-list">{list.slice(0, 3).map((r) => <LiveRow key={r.it.id} r={r} />)}</ol>
    </section>
  );
}

