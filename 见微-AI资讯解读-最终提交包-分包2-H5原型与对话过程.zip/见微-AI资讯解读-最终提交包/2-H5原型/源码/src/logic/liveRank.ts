import { CURATED } from '../data/earnings2026';
import { ATTN, type Dim, LEAD_MIN, MIX, type Score, type SortMode, W } from './rank';
import { type LiveItem, bjTime } from './live';
import type { State } from './store';

/*
 * 实时快讯的两套评分（v0.8）——和精选解读同一套权重、同一套维度，只是信号从哪来不同：
 *
 * 重要程度：影响范围、来源权威、变化幅度、政策关联由关键词规则自动判断（规则全部在下面，可审计）；
 *           时效按发布时间距现在的分钟数算。快讯没有经过编辑核验，来源权威最高只给 4 分（一手原文才给 5）。
 * 用户关注度：大众热度 × 0.6 用来源网站的真实信号（评论数、分享数、编辑标红），不再是模拟值；
 *             与我相关 × 0.4 仍只看本机：关心的主题、关注的公司、读过的内容。
 *
 * 快讯不进「精选解读」的头条：它们没有经过逐句核对。快讯区自己按分排序。
 */

export const LIVE_TOPICS: [string, RegExp][] = [
  ['宏观政策', /国务院|国常会|央行|人民银行|降准|降息|LPR|财政部|发改委|证监会|金融监管|外汇局|政治局|专项债|国债/],
  ['宏观数据', /统计局|GDP|CPI|PPI|PMI|社零|社会消费品|工业增加值|固定资产投资|社融|M2|进出口|外汇储备|失业率/],
  ['海外官方', /美联储|欧洲央行|日本央行|英国央行|白宫|美国财政部|特朗普|鲍威尔|欧盟|OPEC|非农/],
  ['房地产', /房地产|楼市|房价|住建|房企|限购|公积金|土拍|二手房/],
  ['公司财报', /净利|营收|业绩|财报|季报|年报|半年报|扭亏|预增|预减|亏损/],
  ['行业数据', /行业|销量|产量|出货|装机|渗透率|板块|产能/],
];

export function liveTopic(it: LiveItem): string {
  const t = `${it.title}${it.summary}`;
  return LIVE_TOPICS.find(([, re]) => re.test(t))?.[0] ?? '其他';
}

const OFFICIAL = /^(国家统计局|统计局|央行|中国人民银行|人民银行|证监会|财政部|国务院|国常会|发改委|上交所|深交所|北交所|美联储|商务部|工信部|外交部|海关总署|国家金融监督管理总局|金融监管总局|外汇局|住建部|国家能源局)/;

export function liveScope(it: LiveItem): [number, string] {
  const t = `${it.title}${it.summary}`;
  if (/美联储|欧洲央行|日本央行|全球|OPEC|原油|美债|非农|关税/.test(t)) return [5, '全球性（主要央行、全球市场）'];
  if (/国务院|国常会|统计局|央行|人民银行|证监会|财政部|发改委|GDP|CPI|PPI|PMI|LPR|降准|降息|社融/.test(t)) return [5, '全国宏观'];
  if (/行业|板块|产业|新能源|半导体|芯片|汽车|房地产|楼市|光伏|医药|券商|人工智能|AI|机器人|锂电|白酒/.test(t)) return [4, '单一行业'];
  if (it.stocks.length || /^[^：:]{2,12}[：:]/.test(it.title)) return [3, '单一公司'];
  return [2, '其他（社会、国际等）'];
}

export function liveAuthority(it: LiveItem): [number, string] {
  if (OFFICIAL.test(it.title)) return [4, `${it.source}快讯，转述官方表态（未经编辑核对原文）`];
  if (it.stocks.length && /^[^：:]{2,12}[：:]/.test(it.title)) return [3, `${it.source}快讯，转述公司公告`];
  return [2, `${it.source}快讯`];
}

/** 变化幅度：标题摘要里出现的最大百分比 + 强度词 */
export function liveMagnitude(it: LiveItem): [number, string] {
  const t = `${it.title}${it.summary}`;
  const pcts = [...t.matchAll(/([+-]?\d+(?:\.\d+)?)\s?%/g)].map((m) => Math.abs(Number(m[1]))).filter((x) => x < 1000);
  const top = pcts.length ? Math.max(...pcts) : 0;
  let v = top >= 20 ? 4 : top >= 10 ? 3 : top >= 5 ? 2 : top > 0 ? 1 : 1;
  const strong = /创新高|创历史|历史新高|暴跌|暴涨|大涨|大跌|扭亏|首次|激增|骤降|跳水|熔断|涨停|跌停|爆雷/.exec(t);
  if (strong) v = Math.min(5, v + 1);
  const why = [top ? `最大变动 ${top}%` : '没有给出数值变动', strong ? `出现「${strong[0]}」` : ''].filter(Boolean).join('，');
  return [v, why];
}

export function livePolicy(it: LiveItem): [number, string] {
  const t = `${it.title}${it.summary}`;
  const rate = /降准|降息|加息|LPR|利率决议|议息/.exec(t);
  if (rate) return [5, `直接的货币政策动作（${rate[0]}）`];
  const pol = /国常会|政治局|新规|办法|通知|意见|条例|关税|制裁|补贴|监管|政策/.exec(t);
  if (pol) return [3, `涉及政策（${pol[0]}）`];
  return [0, '没有提到政策'];
}

/** 时效：距现在的分钟数 */
export function liveRecency(it: LiveItem, now: number): [number, string] {
  const m = Math.max(0, Math.round((now - bjTime(it.time)) / 60000));
  const txt = m < 60 ? `${m} 分钟前` : m < 1440 ? `${Math.round(m / 60)} 小时前` : `${Math.round(m / 1440)} 天前`;
  if (m <= 30) return [5, txt];
  if (m <= 120) return [4, txt];
  if (m <= 360) return [3, txt];
  if (m <= 1440) return [2, txt];
  if (m <= 4320) return [1, txt];
  return [0, txt];
}

/** 来源热度（0–100）：真实信号 */
export function liveHeat(it: LiveItem): [number, string] {
  const v = Math.min(100, (it.flagged ? 40 : 0) + Math.min(40, it.comments * 4) + Math.min(20, it.shares * 4));
  const why = [`评论 ${it.comments}`, `分享 ${it.shares}`, it.flagged ? '来源编辑标红' : ''].filter(Boolean).join('，');
  return [v, `${it.source}页面上的真实数据：${why}`];
}

/** 这条快讯提到了哪些「财报对比」里的公司（代码或简称） */
export function liveCompanies(it: LiveItem): string[] {
  const t = `${it.title}${it.summary}`;
  const hit = new Set(it.stocks);
  for (const c of CURATED) if (t.includes(c.name)) hit.add(c.secucode);
  return [...hit];
}

export function livePersonal(s: State, it: LiveItem): [number, string] {
  let v = 0;
  const why: string[] = [];
  const topic = liveTopic(it);
  if (s.topics.includes(topic)) { v += 35; why.push(`你关心「${topic}」`); }
  const cos = liveCompanies(it);
  const followed = cos.filter((c) => s.finFollow.includes(c));
  if (followed.length) { v += 45; why.push('提到你关注的公司'); }
  else {
    const read = new Set(s.track.filter((t) => t.name === 'fin_open').map((t) => t.key));
    if (cos.some((c) => read.has(c))) { v += 20; why.push('提到你看过财报的公司'); }
  }
  if (s.track.some((t) => t.name === 'live_open' && t.key === it.id)) { v -= 15; why.push('已看过（降低重复）'); }
  v = Math.max(0, Math.min(100, v));
  return [v, why.length ? why.join('；') : '还没有相关的关注或阅读记录'];
}

const dim = (key: string, label: string, [score, why]: [number, string], weight: number, max = 5): Dim => ({ key, label, score, max, weight, points: (score / max) * weight, why });

export function liveScore(s: State, it: LiveItem, now: number): Score {
  const dims = [
    dim('scope', '影响范围', liveScope(it), W.scope),
    dim('authority', '来源权威', liveAuthority(it), W.authority),
    dim('magnitude', '变化幅度', liveMagnitude(it), W.magnitude),
    dim('policy', '政策关联', livePolicy(it), W.policy),
    dim('recency', '时效', liveRecency(it, now), W.recency),
  ];
  const importance = Math.round(dims.reduce((a, d) => a + d.points, 0));
  const [heat, heatWhy] = liveHeat(it);
  const [p, pWhy] = livePersonal(s, it);
  const attnDims: Dim[] = [
    { key: 'heat', label: '来源热度', score: heat, max: 100, weight: ATTN.heat * 100, points: heat * ATTN.heat, why: heatWhy },
    { key: 'personal', label: '与我相关', score: p, max: 100, weight: ATTN.personal * 100, points: p * ATTN.personal, why: pWhy },
  ];
  const attention = Math.round(attnDims.reduce((a, d) => a + d.points, 0));
  return { importance, attention, total: Math.round(importance * MIX.importance + attention * MIX.attention), dims, attnDims, simulatedHeat: false };
}

export interface LiveRanked { it: LiveItem; sc: Score; rank: number; topic: string }

/** 与精选同样的排序规则；「只看重要」= 重要程度 ≥ LEAD_MIN − 10 */
export function rankLive(s: State, items: LiveItem[], mode: SortMode, now: number): LiveRanked[] {
  const key = (sc: Score) => (mode === 'importance' ? sc.importance : mode === 'attention' ? sc.attention : sc.total);
  return items
    .map((it) => ({ it, sc: liveScore(s, it, now), topic: liveTopic(it) }))
    .sort((a, b) => key(b.sc) - key(a.sc) || b.sc.importance - a.sc.importance || bjTime(b.it.time) - bjTime(a.it.time))
    .map((x, i) => ({ ...x, rank: i + 1 }));
}

export const LIVE_IMPORTANT = LEAD_MIN - 10;

/** 快讯 → 相关的精选解读（关键词），让读者从一条快讯走到有核对依据的解读 */
export const LIVE_RELATED: [RegExp, string][] = [
  [/美联储|加息|鲍威尔|FOMC/, 'fomc-2609'],
  [/CPI|PPI|物价|通胀/, 'price-2608'],
  [/工业企业利润|规上工业利润/, 'profit-2608'],
  [/房地产|楼市|房价|二手房|新房/, 'realestate-2608'],
  [/PMI|采购经理/, 'pmi-2608'],
  [/社零|社会消费品|工业增加值|固定资产投资/, 'macro-2608'],
];

export function liveRelated(it: LiveItem): string | undefined {
  const t = `${it.title}${it.summary}`;
  return LIVE_RELATED.find(([re]) => re.test(t))?.[1];
}
