import { useSyncExternalStore } from 'react';
import { EVENTS, INTERPS } from '../data/content';
import type { ReviewStatus, WatchItem } from '../data/types';

/*
 * 单一状态仓库：H5 阅读页与内容工作台共用。
 * 工作台撤回一条解释后，详情、观察卡和追问读到的是同一份状态。
 * 生产环境需要服务端鉴权与发布控制，这里的按钮只是前端模拟。
 */

export interface AuditEntry {
  at: string;
  actor: 'demo-reviewer';
  action: string;
  target: string;
}

export interface TrackEvent {
  name: string;
  key: string;
  at: string;
}

export interface State {
  schema: 5;
  /** 演示模式：工作台、异常样本、演示更新、技术编号只在这里出现 */
  demoMode: boolean;
  /** 外观：跟随系统 / 浅色 / 深色 */
  theme: 'system' | 'light' | 'dark';
  /** 工作台设置的审核状态（published / withdrawn / needs_review…） */
  review: Record<string, ReviewStatus>;
  /** 模拟来源不可用（工作台模拟；真实来源只表示「本机演示假设不可访问」，不代表原站状态） */
  sourceMissing: Record<string, boolean>;
  /** 各事件当前版本 */
  version: Record<string, string>;
  /** 是否由「演示更新」触发，用于持续标注 */
  demoUpdate: Record<string, boolean>;
  conditions: Record<string, Record<string, boolean>>;
  watches: WatchItem[];
  quiz: Record<string, number>;
  depth: 'brief' | 'full';
  /** 我关心的主题（参与「与我相关」评分） */
  topics: string[];
  /** 首页排序方式 */
  sort: 'mix' | 'importance' | 'attention';
  /** 财报对比里关注的公司（600519.SH 形式；参与快讯的「与我相关」评分） */
  finFollow: string[];
  audit: AuditEntry[];
  track: TrackEvent[];
  reports: { at: string; sourceId: string; text: string }[];
}

const KEY = 'jianwei.demo.v5';
/** 上一版的存储键：首次打开新版时读一次并迁移，不改写旧键，旧版页面照常使用 */
const LEGACY_KEY = 'jianwei.demo.v4';

export function initialState(): State {
  const review: Record<string, ReviewStatus> = {};
  for (const i of INTERPS) review[i.id] = 'published';
  const conditions: State['conditions'] = {};
  for (const e of EVENTS) {
    if (!e.toggles) continue;
    conditions[e.id] = Object.fromEntries(e.toggles.map((t) => [t.id, t.default]));
  }
  return {
    schema: 5,
    demoMode: false,
    theme: 'system',
    review,
    sourceMissing: {},
    version: { 'demo-a': 'v1' },
    demoUpdate: {},
    conditions,
    watches: [],
    quiz: {},
    depth: 'brief',
    topics: [],
    sort: 'mix',
    finFollow: [],
    audit: [],
    track: [],
    reports: [],
  };
}

// ---------- 持久化：localStorage 不可用时降级为会话内状态 ----------

export let storageOK = true;

/*
 * 迁移规则（v4 → v5）
 * - 观察卡：缺 interpIds / note / nextCheck / openQuestion 的补成空值；保存时版本、笔记原样保留
 * - 新增字段（insightId、evidenceRefIds…）旧卡没有就保持空，下一次「关注这个问题」时合并
 * - 其它字段缺失用初始值；结构看不懂（不是对象、schema 不认识）就放弃旧数据，不崩溃
 */
export function normalizeWatch(w: Partial<WatchItem> & { watchId?: string; eventId?: string }): WatchItem | null {
  if (!w || typeof w !== 'object' || !w.watchId || !w.eventId || !EVENTS.some((e) => e.id === w.eventId)) return null;
  const str = (v: unknown) => (typeof v === 'string' ? v : '');
  const arr = (v: unknown) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string') : undefined);
  return {
    ...(w as WatchItem),
    savedVersion: str(w.savedVersion) || 'v1',
    savedAt: str(w.savedAt) || new Date(0).toISOString(),
    change: str(w.change),
    basis: str(w.basis),
    openQuestion: str(w.openQuestion),
    nextCheck: str(w.nextCheck),
    note: str(w.note),
    paused: !!w.paused,
    interpIds: arr(w.interpIds) ?? [],
    factIds: arr(w.factIds),
    evidenceRefIds: arr(w.evidenceRefIds),
  };
}

export function migrate(raw: unknown): State {
  const base = initialState();
  if (!raw || typeof raw !== 'object') return base;
  const r = raw as Omit<Partial<State>, 'schema'> & { schema?: number };
  if (r.schema !== 4 && r.schema !== 5) return base;
  const watches = (Array.isArray(r.watches) ? r.watches : []).map(normalizeWatch).filter((w): w is WatchItem => !!w);
  const obj = <T,>(v: unknown, d: T): T => (v && typeof v === 'object' && !Array.isArray(v) ? (v as T) : d);
  return {
    ...base,
    demoMode: !!r.demoMode,
    theme: r.theme === 'light' || r.theme === 'dark' ? r.theme : 'system',
    review: { ...base.review, ...obj(r.review, {}) },
    sourceMissing: obj(r.sourceMissing, {}),
    version: { ...base.version, ...obj(r.version, {}) },
    demoUpdate: obj(r.demoUpdate, {}),
    conditions: { ...base.conditions, ...obj(r.conditions, {}) },
    watches,
    quiz: obj(r.quiz, {}),
    depth: r.depth === 'full' ? 'full' : 'brief',
    topics: Array.isArray(r.topics) ? r.topics : [],
    sort: r.sort === 'importance' || r.sort === 'attention' ? r.sort : 'mix',
    finFollow: Array.isArray(r.finFollow) ? r.finFollow.filter((x) => typeof x === 'string' && /^\d{6}\.(SH|SZ)$/.test(x)) : [],
    audit: Array.isArray(r.audit) ? r.audit : [],
    track: Array.isArray(r.track) ? r.track : [],
    reports: Array.isArray(r.reports) ? r.reports : [],
    schema: 5,
  };
}

function load(): State {
  try {
    const raw = window.localStorage.getItem(KEY) ?? window.localStorage.getItem(LEGACY_KEY);
    if (!raw) return initialState();
    return migrate(JSON.parse(raw));
  } catch {
    storageOK = false;
    return initialState();
  }
}

function persist(s: State) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(s));
    storageOK = true;
  } catch {
    storageOK = false;
  }
}

let state: State = typeof window === 'undefined' ? initialState() : load();
const listeners = new Set<() => void>();

export function getState() {
  return state;
}

export function setState(fn: (s: State) => State) {
  state = fn(state);
  if (typeof window !== 'undefined') persist(state);
  listeners.forEach((l) => l());
}

/** 测试用：直接替换状态，不写存储 */
export function __resetForTest(s: State = initialState()) {
  state = s;
}

export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => sel(state),
    () => sel(state),
  );
}

const now = () => new Date().toISOString();

// ---------- 埋点：只记录事件名 + 去重键，不记录笔记正文 ----------

export function track(name: string, key: string) {
  const s = getState();
  if (s.track.some((t) => t.name === name && t.key === key)) return; // 同一会话同一对象只计一次
  setState((st) => ({ ...st, track: [...st.track, { name, key, at: now() }].slice(-200) }));
}

// ---------- 阅读侧操作 ----------

export function setCondition(eventId: string, id: string, v: boolean) {
  setState((s) => ({ ...s, conditions: { ...s.conditions, [eventId]: { ...s.conditions[eventId], [id]: v } } }));
  track('assumption_change', `${eventId}:${id}:${v}`);
}

export function setDepth(depth: State['depth']) {
  setState((s) => ({ ...s, depth }));
}

export function answerQuiz(eventId: string, idx: number) {
  setState((s) => ({ ...s, quiz: { ...s.quiz, [eventId]: idx } }));
  track('question_answer', eventId);
}

export function saveWatch(w: WatchItem) {
  setState((s) => ({ ...s, watches: [w, ...s.watches.filter((x) => x.watchId !== w.watchId)] }));
  track('watch_save', w.eventId);
}

/** 编辑观察卡：原位替换，不改变列表顺序 */
export function updateWatch(w: WatchItem) {
  setState((s) => ({ ...s, watches: s.watches.some((x) => x.watchId === w.watchId) ? s.watches.map((x) => (x.watchId === w.watchId ? w : x)) : [w, ...s.watches] }));
}

/** 用户明确选择「采用本卡问题」：只换问题，笔记与版本不动 */
export function adoptSuggestedQuestion(watchId: string) {
  setState((s) => ({
    ...s,
    watches: s.watches.map((w) => {
      if (w.watchId !== watchId || !w.suggestedQuestion) return w;
      const { suggestedQuestion, ...rest } = w;
      return { ...rest, openQuestion: suggestedQuestion };
    }),
  }));
}

/** 看过更新并采纳新版：只改 ackVersion，保存时版本和私人笔记不动 */
export function ackWatch(watchId: string, version: string) {
  setState((s) => ({ ...s, watches: s.watches.map((w) => (w.watchId === watchId ? { ...w, ackVersion: version } : w)) }));
}

export function setTheme(theme: State['theme']) {
  setState((s) => ({ ...s, theme }));
}

export function setDemoMode(on: boolean) {
  setState((s) => ({ ...s, demoMode: on }));
}

export function removeWatch(watchId: string) {
  setState((s) => ({ ...s, watches: s.watches.filter((w) => w.watchId !== watchId) }));
}

export function togglePause(watchId: string) {
  setState((s) => ({ ...s, watches: s.watches.map((w) => (w.watchId === watchId ? { ...w, paused: !w.paused } : w)) }));
}

export function reportIssue(sourceId: string, text: string) {
  setState((s) => ({ ...s, reports: [...s.reports, { at: now(), sourceId, text }] }));
  track('feedback_submit', sourceId);
}

export function setSort(sort: State['sort']) {
  setState((s) => ({ ...s, sort }));
}

export function toggleFinFollow(secucode: string) {
  setState((s) => ({ ...s, finFollow: s.finFollow.includes(secucode) ? s.finFollow.filter((x) => x !== secucode) : [...s.finFollow, secucode] }));
  track('fin_follow', secucode);
}

export function toggleTopic(t: string) {
  setState((s) => ({ ...s, topics: s.topics.includes(t) ? s.topics.filter((x) => x !== t) : [...s.topics, t] }));
}

// ---------- 工作台操作（全部标注模拟审核） ----------

function audit(s: State, action: string, target: string): State {
  return { ...s, audit: [{ at: now(), actor: 'demo-reviewer' as const, action, target }, ...s.audit].slice(0, 60) };
}

export function setReview(interpId: string, status: ReviewStatus) {
  setState((s) => audit({ ...s, review: { ...s.review, [interpId]: status } }, `模拟审核：设为 ${status}`, interpId));
}

export function setSourceMissing(sourceId: string, missing: boolean) {
  setState((s) =>
    audit({ ...s, sourceMissing: { ...s.sourceMissing, [sourceId]: missing } }, missing ? '模拟来源缺失' : '恢复来源', sourceId),
  );
}

/** 演示更新：示范公司 A 发布更正公告 → v2 */
export function applyDemoCorrection(from: 'watch' | 'studio') {
  setState((s) =>
    audit(
      { ...s, version: { ...s.version, 'demo-a': 'v2' }, demoUpdate: { ...s.demoUpdate, 'demo-a': true } },
      from === 'watch' ? '加载演示更新（我的观察）' : '发布演示更正',
      'demo-a → v2',
    ),
  );
  track('update_open', 'demo-a:v2');
}

export function resetDemo() {
  setState(() => ({ ...initialState(), demoMode: true }));
}

/** 清除本地数据：笔记、偏好、观察全部删除 */
export function clearLocal() {
  try {
    window.localStorage.removeItem(KEY);
    // 旧键也要删：否则刷新后会被当作旧数据重新迁移回来
    window.localStorage.removeItem(LEGACY_KEY);
  } catch {
    /* 存储不可用时本来就没有落盘 */
  }
  state = initialState();
  listeners.forEach((l) => l());
}
