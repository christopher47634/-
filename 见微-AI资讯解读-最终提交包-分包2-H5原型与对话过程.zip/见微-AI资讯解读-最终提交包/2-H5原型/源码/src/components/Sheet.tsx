import { X } from 'lucide-react';
import { type ReactNode, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';

/*
 * 底部抽屉：role=dialog、Esc 关闭、Tab 焦点圈在抽屉内、关闭后把焦点还给打开它的元素。
 * 阅读位置不动：抽屉覆盖在正文之上，body 只锁滚动不跳位。
 */
export default function Sheet({
  open,
  onClose,
  title,
  label,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  label?: ReactNode;
  children: ReactNode;
}) {
  const panel = useRef<HTMLDivElement>(null);
  const opener = useRef<Element | null>(null);

  useEffect(() => {
    if (!open) return;
    opener.current = document.activeElement;
    const y = window.scrollY;
    document.body.style.overflow = 'hidden';
    const f = panel.current?.querySelector<HTMLElement>('[data-autofocus], button, a, input, textarea');
    f?.focus({ preventScroll: true });
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); onClose(); }
      if (e.key === 'Tab' && panel.current) {
        const els = [...panel.current.querySelectorAll<HTMLElement>('button, a[href], input, textarea, select, [tabindex="0"]')].filter((x) => !x.hasAttribute('disabled'));
        if (!els.length) return;
        const first = els[0], last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      window.scrollTo({ top: y, behavior: 'instant' as ScrollBehavior });
      (opener.current as HTMLElement | null)?.focus?.({ preventScroll: true });
    };
  }, [open, onClose]);

  if (!open) return null;
  return createPortal(
    <div className="sheet-root">
      <div className="sheet-scrim" onClick={onClose} />
      <div className="sheet glass-strong" role="dialog" aria-modal="true" aria-label={title} ref={panel}>
        <div className="sheet-grip" aria-hidden="true" />
        <header className="sheet-head">
          <div>
            {label && <div className="sheet-label">{label}</div>}
            <h2 className="sheet-title">{title}</h2>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="关闭">
            <X size={20} strokeWidth={1.75} />
          </button>
        </header>
        <div className="sheet-body">{children}</div>
      </div>
    </div>,
    document.body,
  );
}
