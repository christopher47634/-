import { ArrowUp, ShieldAlert } from 'lucide-react';
import { useState } from 'react';
import type { EventItem } from '../data/types';
import { type Answer, ask, resolveQA, visibleQA } from '../logic/qa';
import { useStore } from '../logic/store';
import Sheet from './Sheet';
import { Cite, Stopped } from './bits';

type Turn = { q: string; a: Answer };

export default function AskSheet({ ev, open, onClose, onCite }: { ev: EventItem; open: boolean; onClose: () => void; onCite: (f: string) => void }) {
  return (
    <Sheet open={open} onClose={onClose} title="追问" label="离线预设问答 · 不联网生成">
      <AskBody ev={ev} onCite={onCite} />
    </Sheet>
  );
}

export function AskBody({ ev, onCite }: { ev: EventItem; onCite: (f: string) => void }) {
  const s = useStore((x) => x);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [text, setText] = useState('');
  const qa = visibleQA(s, ev);
  const asked = new Set(turns.map((t) => t.q));

  const submit = (q: string) => {
    if (!q.trim()) return;
    setTurns((t) => [...t, { q, a: ask(s, ev.id, q) }]);
    setText('');
  };

  return (
    <div className="ask-body">
      <div className="turns" aria-live="polite">
        {turns.map((t, i) => {
          // 每次渲染都按当前状态重新判定：工作台撤回后，已经显示过的回答也会同步停止
          const a = t.a.kind === 'answer' || t.a.kind === 'stopped' ? resolveQA(s, t.a.qa) : t.a;
          return (
            <div key={i} className="turn">
              <p className="turn-q">{t.q}</p>
              {a.kind === 'answer' && (
                <div className="turn-a">
                  <p>{a.qa.a}</p>
                  <div className="turn-cites">依据 {a.qa.factIds.map((f, k) => <Cite key={f} n={k + 1} onClick={() => onCite(f)} />)}</div>
                </div>
              )}
              {a.kind === 'term' && (
                <div className="turn-a">
                  <p><strong>{a.term.term}</strong>　{a.term.text}</p>
                  <div className="turn-cites">术语解释由编辑部撰写 · 本篇相关 {a.term.factIds.map((f, k) => <Cite key={f} n={k + 1} onClick={() => onCite(f)} />)}</div>
                </div>
              )}
              {a.kind === 'stopped' && <Stopped>{a.reason}</Stopped>}
              {a.kind === 'boundary' && (
                <div className="turn-a turn-boundary">
                  <ShieldAlert size={16} strokeWidth={1.75} aria-hidden="true" />
                  <p>这里不提供买卖、目标价、仓位或交易时机的建议。可以问这篇解读里的数字、口径和依据。</p>
                </div>
              )}
              {a.kind === 'uncovered' && (
                <div className="turn-a turn-uncovered">
                  <p>这个问题当前离线样本没有覆盖，为避免编造就不回答了。可以试试下面的问题，或者问本篇出现的术语是什么意思。</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="suggest">
        <p className="suggest-h">你可能还想知道</p>
        <div className="chips" role="list">
          {qa.filter((q) => !asked.has(q.q)).map((q) => (
            <button key={q.id} role="listitem" className="chip" onClick={() => submit(q.q)}>{q.q}</button>
          ))}
          {ev.terms?.slice(0, 2).filter((t) => !asked.has(`${t.term}是什么意思？`)).map((t) => (
            <button key={t.term} role="listitem" className="chip chip-term" onClick={() => submit(`${t.term}是什么意思？`)}>{t.term}是什么意思？</button>
          ))}
        </div>
      </div>

      <form className="ask-form" onSubmit={(e) => { e.preventDefault(); submit(text); }}>
        <label className="sr-only" htmlFor="ask">输入问题</label>
        <input id="ask" value={text} onChange={(e) => setText(e.target.value)} placeholder="也可以直接问，比如「翘尾是什么意思」" autoComplete="off" enterKeyHint="send" />
        <button className="icon-btn icon-btn-solid" aria-label="发送" disabled={!text.trim()}>
          <ArrowUp size={18} strokeWidth={2} />
        </button>
      </form>
    </div>
  );
}
