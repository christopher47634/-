import { useEffect, useSyncExternalStore } from 'react';
import SNAP from '../data/liveSnapshot.json';
import type { ApiFinRow } from './earnings';

/*
 * 实时数据（v0.8）
 *
 * 浏览器直接向公开接口取数，不经过我们自己的服务器：
 *   快讯     东方财富 7×24 快讯（失败时换新浪财经 7×24）
 *   财报     东方财富 F10「主要指标」（累计数 + 单季同比/环比字段）
 *   公告     东方财富公告列表（只取定期报告，拿到原文 PDF）
 *   搜索     东方财富证券代码联想
 * 用 JSONP（<script> 加载）而不是 fetch：这些接口不带 CORS 头，但都支持回调参数；
 * 这样双击打开的单文件（file://）也能取到实时数据。
 *
 * 取不到时（断网、被安全策略拦截、接口改版）自动退回打包时抓的快照，并在页面上写明「离线快照 · 采集时间」。
 * 只发送公开参数（股票代码、页码），不发送任何用户数据。
 * 生产环境应改走自己的服务端代理：JSONP 等于执行第三方脚本，演示可以接受，正式产品不行。
 */

export const REFRESH_MS = 60_000;
const TIMEOUT_MS = 8_000;

let seq = 0;
export function jsonp<T>(url: string, cbParam = 'callback', timeout = TIMEOUT_MS): Promise<T> {
  return new Promise((resolve, reject) => {
    const name = `__jw_${Date.now().toString(36)}_${seq++}`;
    const w = window as unknown as Record<string, unknown>;
    const s = document.createElement('script');
    let timer = 0;
    const done = (err: Error | null, data?: T) => {
      window.clearTimeout(timer);
      // 晚到的回调不能报错：留一个空函数
      w[name] = () => undefined;
      s.remove();
      if (err) reject(err);
      else resolve(data as T);
    };
    w[name] = (d: T) => done(null, d);
    s.onerror = () => done(new Error('接口加载失败'));
    timer = window.setTimeout(() => done(new Error('接口超时')), timeout);
    s.src = `${url}${url.includes('?') ? '&' : '?'}${cbParam}=${name}`;
    s.referrerPolicy = 'no-referrer';
    document.head.appendChild(s);
  });
}

// ---------- 快讯 ----------

export interface LiveItem {
  id: string;
  title: string;
  summary: string;
  /** 北京时间 YYYY-MM-DD HH:mm:ss */
  time: string;
  source: '东方财富' | '新浪财经';
  url: string;
  /** 涉及的 A 股，形如 600519.SH */
  stocks: string[];
  comments: number;
  shares: number;
  /** 来源编辑标红 / 焦点 */
  flagged: boolean;
}

interface EmNews { code: string; title: string; summary: string; showTime: string; stockList?: string[]; pinglun_Num?: number; share?: number; titleColor?: number }

/** 东方财富 stockList：「1.600519」= 沪市，「0.000001」= 深市；其他市场不接 */
export function emStock(s: string): string | null {
  const m = /^([01])\.(\d{6})$/.exec(s);
  return m ? `${m[2]}.${m[1] === '1' ? 'SH' : 'SZ'}` : null;
}

export function fromEm(n: EmNews): LiveItem {
  return {
    id: `em-${n.code}`,
    title: n.title.trim(),
    summary: n.summary.replace(/^【[^】]*】/, '').trim(),
    time: n.showTime,
    source: '东方财富',
    url: `https://finance.eastmoney.com/a/${n.code}.html`,
    stocks: (n.stockList ?? []).map(emStock).filter((x): x is string => !!x),
    comments: n.pinglun_Num ?? 0,
    shares: n.share ?? 0,
    flagged: n.titleColor === 1,
  };
}

interface SinaItem { id: number; rich_text: string; create_time: string; docurl?: string; ext?: string; is_focus?: number; like_nums?: number; comment_list?: { total?: number } }

export function fromSina(n: SinaItem): LiveItem {
  const m = /^【([^】]+)】(.*)$/s.exec(n.rich_text.trim());
  let stocks: string[] = [];
  let url = n.docurl ?? '';
  try {
    const e = JSON.parse(n.ext ?? '{}') as { stocks?: { market: string; symbol: string }[]; docurl?: string };
    stocks = (e.stocks ?? []).filter((x) => /^s[hz]\d{6}$/.test(x.symbol)).map((x) => `${x.symbol.slice(2)}.${x.symbol.slice(0, 2).toUpperCase()}`);
    url = url || e.docurl || '';
  } catch { /* ext 不是 JSON 就当没有 */ }
  const text = n.rich_text.trim();
  return {
    id: `sina-${n.id}`,
    title: m ? m[1] : text.length > 40 ? `${text.slice(0, 38)}…` : text,
    summary: m ? m[2].trim() : text,
    time: n.create_time,
    source: '新浪财经',
    url: url || 'https://finance.sina.com.cn/7x24/',
    stocks,
    comments: n.comment_list?.total ?? 0,
    shares: n.like_nums ?? 0,
    flagged: n.is_focus === 1,
  };
}

// ---------- 状态 ----------

export type LiveStatus = 'snapshot' | 'loading' | 'live';

export interface NewsState { status: LiveStatus; items: LiveItem[]; at: string; source: string; error?: string; tried: boolean }
export interface FinState { status: LiveStatus | 'missing'; rows: ApiFinRow[]; at: string; error?: string }
export interface AnnItem { art_code: string; title: string; notice_date: string; column: string }
export interface AnnState { status: LiveStatus | 'missing'; list: AnnItem[]; at: string }

interface Snap { capturedAt: string; news: EmNews[]; fin: Record<string, ApiFinRow[]>; ann: Record<string, AnnItem[]> }
const snap = SNAP as unknown as Snap;
export const SNAPSHOT_AT = snap.capturedAt;

interface LiveStore { news: NewsState; fin: Record<string, FinState>; ann: Record<string, AnnState> }

let store: LiveStore = {
  news: { status: 'snapshot', items: snap.news.map(fromEm), at: snap.capturedAt, source: '东方财富 7×24（离线快照）', tried: false },
  fin: {},
  ann: {},
};
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());
const set = (fn: (s: LiveStore) => LiveStore) => {
  store = fn(store);
  emit();
};

export function useLive<T>(sel: (s: LiveStore) => T): T {
  return useSyncExternalStore(
    (l) => {
      subs.add(l);
      return () => subs.delete(l);
    },
    () => sel(store),
    () => sel(store),
  );
}
export const getLive = () => store;

/** 测试用 */
export function __resetLive() {
  store = { news: { status: 'snapshot', items: snap.news.map(fromEm), at: snap.capturedAt, source: '东方财富 7×24（离线快照）', tried: false }, fin: {}, ann: {} };
}

const errMsg = (e: unknown) => (e instanceof Error ? e.message : String(e));

let newsBusy = false;
export async function refreshNews(): Promise<void> {
  if (newsBusy || typeof document === 'undefined') return;
  newsBusy = true;
  set((s) => ({ ...s, news: { ...s.news, status: s.news.status === 'live' ? 'live' : 'loading' } }));
  try {
    const j = await jsonp<{ data?: { fastNewsList?: EmNews[] } }>(
      `https://np-weblist.eastmoney.com/comm/web/getFastNewsList?client=web&biz=web_724&fastColumn=102&sortEnd=&pageSize=60&req_trace=jw${Date.now()}`,
    );
    const list = j.data?.fastNewsList;
    if (!list?.length) throw new Error('东方财富返回空列表');
    set((s) => ({ ...s, news: { status: 'live', items: list.map(fromEm), at: new Date().toISOString(), source: '东方财富 7×24', tried: true } }));
  } catch (e1) {
    try {
      const j = await jsonp<{ result?: { data?: { feed?: { list?: SinaItem[] } } } }>(
        'https://zhibo.sina.com.cn/api/zhibo/feed?page=1&page_size=60&zhibo_id=152&tag_id=0&dire=f&dpc=1&type=0',
      );
      const list = j.result?.data?.feed?.list;
      if (!list?.length) throw new Error('新浪返回空列表');
      set((s) => ({ ...s, news: { status: 'live', items: list.map(fromSina), at: new Date().toISOString(), source: '新浪财经 7×24（东方财富不可用时的备用源）', tried: true } }));
    } catch (e2) {
      // 两个源都失败：保留手上的数据（上一次实时结果或快照），只记录原因
      set((s) => ({ ...s, news: { ...s.news, status: s.news.status === 'live' ? 'live' : 'snapshot', error: `${errMsg(e1)}；备用源：${errMsg(e2)}`, tried: true } }));
    }
  } finally {
    newsBusy = false;
  }
}

/** 首页 / 快讯页挂载时调用：立即取一次，之后页面可见时每 60 秒刷新 */
export function useNewsAutoRefresh() {
  useEffect(() => {
    void refreshNews();
    const t = window.setInterval(() => {
      if (document.visibilityState === 'visible') void refreshNews();
    }, REFRESH_MS);
    return () => window.clearInterval(t);
  }, []);
}

// ---------- 财报 ----------

const finBusy = new Set<string>();
export async function loadFin(secucode: string): Promise<void> {
  if (finBusy.has(secucode)) return;
  finBusy.add(secucode);
  const fallback = snap.fin[secucode];
  set((s) => ({ ...s, fin: { ...s.fin, [secucode]: s.fin[secucode]?.status === 'live' ? s.fin[secucode] : { status: 'loading', rows: fallback ?? [], at: snap.capturedAt } } }));
  try {
    const j = await jsonp<{ result?: { data?: ApiFinRow[] } }>(
      `https://datacenter.eastmoney.com/securities/api/data/get?type=RPT_F10_FINANCE_MAINFINADATA&sty=APP_F10_MAINFINADATA&quoteColumns=&filter=(SECUCODE%3D%22${encodeURIComponent(secucode)}%22)&p=1&ps=12&sr=-1&st=REPORT_DATE&source=HSF10&client=PC`,
    );
    const rows = j.result?.data;
    if (!rows?.length) throw new Error('接口没有这家公司的财报数据');
    set((s) => ({ ...s, fin: { ...s.fin, [secucode]: { status: 'live', rows, at: new Date().toISOString() } } }));
  } catch (e) {
    set((s) => ({ ...s, fin: { ...s.fin, [secucode]: fallback ? { status: 'snapshot', rows: fallback, at: snap.capturedAt, error: errMsg(e) } : { status: 'missing', rows: [], at: '', error: errMsg(e) } } }));
  } finally {
    finBusy.delete(secucode);
  }
}

export async function loadAnn(secucode: string): Promise<void> {
  const fallback = snap.ann[secucode];
  try {
    const j = await jsonp<{ data?: { list?: { art_code: string; title: string; notice_date: string; columns?: { column_name: string }[] }[] } }>(
      `https://np-anotice-stock.eastmoney.com/api/security/ann?sr=-1&page_size=20&page_index=1&ann_type=A&client_source=web&stock_list=${secucode.slice(0, 6)}&f_node=1&s_node=1`,
      'cb',
    );
    const list = (j.data?.list ?? []).map((x) => ({ art_code: x.art_code, title: x.title, notice_date: x.notice_date, column: x.columns?.[0]?.column_name ?? '' }));
    set((s) => ({ ...s, ann: { ...s.ann, [secucode]: { status: 'live', list, at: new Date().toISOString() } } }));
  } catch {
    set((s) => ({ ...s, ann: { ...s.ann, [secucode]: fallback ? { status: 'snapshot', list: fallback, at: snap.capturedAt } : { status: 'missing', list: [], at: '' } } }));
  }
}

/** 公告原文 PDF（东方财富镜像；原始出处是交易所 / 巨潮资讯网） */
export const annPdf = (art: string) => `https://pdf.dfcfw.com/pdf/H2_${art}_1.pdf`;

/** 某一期定期报告的全文公告：栏目对得上、标题里有「YYYY年」 */
export function reportFor(list: AnnItem[], year: number, q: number): AnnItem | undefined {
  const col = ['一季度报告全文', '半年度报告全文', '三季度报告全文', '年度报告全文'][q - 1];
  return list.find((a) => a.column === col && a.title.includes(`${year}年`));
}

// ---------- 搜索 ----------

export interface StockHit { secucode: string; code: string; name: string }

export const SNAP_COMPANIES: StockHit[] = Object.entries(snap.fin).map(([secucode, rows]) => ({ secucode, code: secucode.slice(0, 6), name: rows[0]?.SECURITY_NAME_ABBR ?? secucode }));

export async function suggest(q: string): Promise<StockHit[]> {
  const k = q.trim();
  if (!k) return [];
  try {
    const j = await jsonp<{ QuotationCodeTable?: { Data?: { Code: string; Name: string; Classify: string; MktNum: string; SecurityTypeName: string }[] } }>(
      `https://searchapi.eastmoney.com/api/suggest/get?input=${encodeURIComponent(k)}&type=14&token=D43BF722C8E33BDC906FB84D85E326E8&count=8`,
      'cb',
      5000,
    );
    return (j.QuotationCodeTable?.Data ?? [])
      .filter((d) => d.Classify === 'AStock' && (d.MktNum === '1' || d.MktNum === '0'))
      .map((d) => ({ code: d.Code, name: d.Name, secucode: `${d.Code}.${d.MktNum === '1' ? 'SH' : 'SZ'}` }));
  } catch {
    // 离线：只在快照里的公司中找
    return SNAP_COMPANIES.filter((c) => c.code.includes(k) || c.name.includes(k));
  }
}

/** 6 位代码 → 带交易所后缀（6 开头沪市，0/3 开头深市；北交所等不支持） */
export function toSecucode(s: string): string | null {
  if (/^\d{6}\.(SH|SZ)$/.test(s)) return s;
  if (/^6\d{5}$/.test(s)) return `${s}.SH`;
  if (/^[03]\d{5}$/.test(s)) return `${s}.SZ`;
  return null;
}

/** 北京时间字符串 → 毫秒 */
export const bjTime = (t: string) => Date.parse(`${t.replace(' ', 'T')}+08:00`);
