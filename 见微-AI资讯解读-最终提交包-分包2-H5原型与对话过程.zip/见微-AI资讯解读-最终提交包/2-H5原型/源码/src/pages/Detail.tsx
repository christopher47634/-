import { ArrowLeft, Bookmark, BookmarkCheck, ChevronLeft, ChevronRight, MessageCircleQuestion } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { FACTS, INTERPS, SOURCES, eventById, factById, interpById } from '../data/content';
import type { EventItem, NodeView, PathNode } from '../data/types';
import AskSheet, { AskBody } from '../components/AskSheet';
import EvidenceSheet, { EvidenceBody, type EvTarget } from '../components/EvidenceSheet';
import DifferenceInsight from '../components/DifferenceInsight';
import { RankBreakdown } from '../components/RankBits';
import MetricEvidence, { MetricSwitch } from '../components/MetricEvidence';
import Figure from '../components/Figure';
import Sheet from '../components/Sheet';
import { AiBadge, Cite, Disclosure, KindBadge, StatusTag, Stopped, ThemeToggle, Toast, ToneTag, coverOf } from '../components/bits';
import { evidenceLabel, factState, interpEffective, isLive } from '../logic/gate';
import { useWide } from '../logic/hooks';
import { back } from '../logic/router';
import { answerQuiz, saveWatch, setCondition, setDepth, track, useStore } from '../logic/store';
import { insightView, metricState } from '../logic/evidence';
import { eventView, pointState } from '../logic/view';
import { followEvent } from '../logic/watch';

export default function Detail({ id }: { id: string }) {
  const ev = eventById(id);
  const s = useStore((x) => x);
  const [evid, setEvid] = useState<EvTarget | null>(null);
  const [node, setNode] = useState<PathNode | null>(null);
  const [asking, setAsking] = useState(false);
  const [toast, setToast] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const wide = useWide();
  const [panel, setPanel] = useState<Panel>({ tab: 'src' });
  const closeFact = useCallback(() => setEvid(null), []);
  const switchMetric = useCallback((id: string) => setEvid((e) => (e?.kind === 'metric' ? { ...e, id } : e)), []);
  const [toastText, setToastText] = useState('');
  const [openCmp, setOpenCmp] = useState(false);
  /** 桌面：打开依据前的触发控件，「回到正文」时把焦点还给它 */
  const trigger = useRef<HTMLElement | null>(null);
  const closeNode = useCallback(() => setNode(null), []);
  const closeAsk = useCallback(() => setAsking(false), []);
  const endToast = useCallback(() => setToast(false), []);

  useEffect(() => { if (ev) track('article_open', ev.id); }, [ev]);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 120);
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);

  if (!ev || (ev.demoOnly && !s.demoMode)) return (
    <div className="page"><div className="empty-state"><h2>找不到这条解读</h2><a className="btn btn-primary" href="#/">回到首页</a></div></div>
  );

  const { summary, path, version } = eventView(s, ev);
  const cond = s.conditions[ev.id] ?? {};
  const view = (n: PathNode): NodeView => (n.resolve ? n.resolve(cond) : n.base);
  const full = s.depth === 'full';
  const factDead = factState(s, factById(summary.fact.factId)!);
  const watched = s.watches.find((w) => w.eventId === ev.id);
  const cover = coverOf(ev.id);
  const openFact = (f: string) => (wide ? setPanel({ tab: 'fact', id: f }) : setEvid({ kind: 'fact', id: f }));
  const iv = insightView(s, ev);
  const card = iv.kind === 'card' ? iv : null;
  const figIds = ev.figure && (ev.figure.kind === 'bars' || ev.figure.kind === 'dots') ? ev.figure.rows.map((r) => r.metricId).filter((x): x is string => !!x) : [];
  /** 点一个数字：手机开底部抽屉，桌面换右侧依据栏；同一面板里切换，不叠弹窗 */
  const openMetric = (id: string, ids: string[]) => {
    trigger.current = document.activeElement as HTMLElement | null;
    if (wide) setPanel({ tab: 'metric', id, ids });
    else setEvid({ kind: 'metric', id, ids, eventId: ev.id });
  };
  const focusMetric = wide ? (panel.tab === 'metric' ? panel.id : null) : evid?.kind === 'metric' ? evid.id : null;
  const moreCaliber = () => {
    setOpenCmp(true);
    requestAnimationFrame(() => document.getElementById('sec-cmp')?.scrollIntoView({ block: 'start', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }));
  };
  const openNode = (n: PathNode) => (wide ? setPanel({ tab: 'node', node: n }) : setNode(n));

  const follow = () => {
    const r = followEvent(s, ev.id);
    saveWatch(r.watch);
    if (card) track('watch_question_saved', `${ev.id}:${card.insight.id}:${card.version}`);
    setToastText(
      r.keptOwnQuestion
        ? '已合并到你原来的关注。你写的问题保留不变，可以在卡片里选择改用本卡问题。'
        : card
          ? `已关注这个问题：${r.watch.openQuestion}（只保存在本机）`
          : '已关注。原文更正或解释变化时，「我的关注」里会提示（仅保存在本机）。',
    );
    setToast(true);
  };

  return (
    <div className="page page-detail">
      <header className={`topbar${scrolled ? ' is-glass' : ''}`}>
        <button className="icon-btn" onClick={() => back('#/')} aria-label="返回"><ArrowLeft size={21} strokeWidth={1.7} /></button>
        <span className="topbar-title" aria-hidden={!scrolled}>{ev.question}</span>
        <div className="top-actions">
        <ThemeToggle />
        <div className="depth" role="group" aria-label="阅读深度">
          <button aria-pressed={!full} className={!full ? 'on' : ''} onClick={() => setDepth('brief')}>简读</button>
          <button aria-pressed={full} className={full ? 'on' : ''} onClick={() => setDepth('full')}>细读</button>
        </div>
        </div>
      </header>

      <div className="detail-grid">
      <article className="reading">
        {cover && <img className="cover cover-detail" src={cover} alt="" />}
        <div className="meta">
          <KindBadge ev={ev} />
          <AiBadge />
          {ev.demoOnly && version === 'v2' && s.demoUpdate[ev.id] && <span className="tag tag-demo">演示更新 · v2</span>}
        </div>
        <h1 className="headline">{ev.question}</h1>
        {!card && <p className="answer">{ev.answer}</p>}
        <p className="dateline">
          <span className="dl-src">{ev.sourceLabel}</span>
          <span className="num">原文 {ev.sourceDate}<span className="dl-sep" aria-hidden="true">·</span>解读更新 {ev.interpUpdatedAt}</span>
        </p>

        {card && <DifferenceInsight ev={ev} iv={card} focus={focusMetric} onCheck={openMetric} onFollow={follow} onMoreCaliber={ev.compare ? moreCaliber : undefined} />}
        {iv.kind === 'unavailable' && <InsightUnavailable eventId={ev.id} version={iv.version} reason={iv.reason} problems={s.demoMode ? iv.problems : []} />}

        {ev.figure && (
          <Figure
            fig={ev.figure}
            onSource={() => openFact(ev.figure!.factIds[0])}
            onMetric={figIds.length ? (id) => openMetric(id, figIds) : undefined}
            focus={focusMetric}
            off={new Set(figIds.filter((id) => !metricState(s, id, ev.id).usable))}
          />
        )}

        {/* ---------- 要点：一条事实 + 两三句解释 + 一处不能下结论 ---------- */}
        <section className="gist" aria-labelledby="h-gist">
          <h2 id="h-gist" className="sr-only">要点</h2>
          {/* 有差异卡时，数字已经在卡里逐项可核对，不再重复一遍 */}
          {!card && (
            <p className="gist-fact">
              <span className="gist-k">已披露</span>
              {summary.fact.text} <Cite n="原文" missing={factDead === 'missing'} onClick={() => openFact(summary.fact.factId)} />
            </p>
          )}
          {card && summary.points.length > 0 && <span className="gist-k">还可以注意</span>}
          {summary.points.length > 0 && (
            <ul className="gist-points">
              {summary.points.map((p, i) => {
                const st = pointState(s, p);
                const cite = p.factId ?? (p.interpId ? interpById(p.interpId)!.factIds[0] : undefined);
                return (
                  <li key={i}>
                    {st.live ? (
                      <>{p.text} {cite && <Cite n={i + 1} onClick={() => openFact(cite)} />}</>
                    ) : (
                      <Stopped>{st.eff && <StatusTag status={st.eff.status} />} {st.reason}</Stopped>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
          {!card && (
            <div className="gist-unknown">
              <span className="gist-k">还不能下结论</span>
              <p>{summary.unknown}</p>
            </div>
          )}
        </section>

        {ev.aggregated && <p className="aside">{ev.aggregated}</p>}

        {ev.demoOnly && ev.versions && (
          <div className="versions">
            {ev.versions.map((v) => (
              <div key={v.id} className={`ver${v.id === version ? ' on' : ''}`}>
                <span className="mono">{v.label}</span>
                <span>{v.note}</span>
                {v.id === version && <span className="ver-now">当前</span>}
              </div>
            ))}
          </div>
        )}

        {/* ---------- 按需展开 ---------- */}
        <div className="more">
          <h2 className="more-h">继续看</h2>
          <RankBreakdown ev={ev} />

          {ev.retro && (
            <Disclosure id="sec-retro" open={full} title="后来发生了什么" badge={<span className="tag tag-new">有后续材料</span>} preview={ev.retro.verdicts.map((v) => v.label).join(' · ')}>
              <RetroBlock ev={ev} onCite={openFact} />
            </Disclosure>
          )}

          <Disclosure id="sec-path" open={full} title="影响路径" preview={ev.toggles ? '切换条件，看推论怎样跟着变' : path.map((n) => n.stage).join(' → ')}>
            <p className="block-note">箭头表示分析关系，不等于已经证明因果；终点不是股价涨跌。点每一步查看依据和失效条件。</p>
            {ev.toggles && (
              <fieldset className="toggles">
                <legend>条件<span className="dim"> · {ev.kind === 'hypothetical' ? '机制教学，不是预测模型' : '预审过的条件分支，不改变事实'}</span></legend>
                {ev.toggles.map((t) => (
                  <label key={t.id} className="switch">
                    <input type="checkbox" role="switch" checked={!!cond[t.id]} onChange={(e) => setCondition(ev.id, t.id, e.target.checked)} />
                    <span className="switch-track" aria-hidden="true"><span /></span>
                    <span className="switch-text"><span>{t.label}</span><span className="dim small">{t.hint}</span></span>
                  </label>
                ))}
              </fieldset>
            )}
            <ol className="path">
              {path.map((n) => {
                const v = view(n);
                const eff = n.interpId ? interpEffective(s, interpById(n.interpId)!) : null;
                const stopped = !!eff && !isLive(eff);
                return (
                  <li key={n.id} className={`pnode tone-${v.tone}${stopped ? ' is-stopped' : ''}`}>
                    <span className="pnode-stage">{n.stage}</span>
                    <button className="pnode-card" onClick={() => { openNode(n); track('chain_node_open', `${ev.id}:${n.id}`); }} aria-label={`${n.stage}：${stopped ? '这一步的解释已停止展示' : v.title}，查看依据与条件`}>
                      <span key={v.title} className="pnode-title reink">{stopped ? '这一步的解释已停止展示' : v.title}</span>
                      {!stopped && v.note && <span key={v.note} className="pnode-note reink">{v.note}</span>}
                      <span className="pnode-foot">
                        {stopped ? <StatusTag status={eff!.status} /> : <ToneTag tone={v.tone} />}
                        <ChevronRight size={16} strokeWidth={1.75} aria-hidden="true" />
                      </span>
                    </button>
                  </li>
                );
              })}
            </ol>
          </Disclosure>

          {ev.compare && (
            <Disclosure id="sec-cmp" open={full || openCmp} title="口径对照" preview={ev.compare.title}>
              <CompareBlock ev={ev} onCite={openFact} />
            </Disclosure>
          )}

          {ev.translations && (
            <Disclosure id="sec-tr" open={full} title="英文原句与中文释义" preview="三处容易被译重的地方">
              <TranslationBlock ev={ev} onCite={openFact} />
            </Disclosure>
          )}

          {ev.quiz && (
            <Disclosure id="sec-quiz" open={full} title="容易看错的地方" preview="一道可跳过的小题，不计分">
              <QuizBlock ev={ev} onCite={openFact} />
            </Disclosure>
          )}

          <Disclosure id="sec-next" open={full} title="接下来看什么" preview={ev.watchSuggestions[0]}>
            {ev.timeNote && <p className="block-note">{ev.timeNote}</p>}
            <ul className="next">{ev.watchSuggestions.map((w) => <li key={w}>{w}</li>)}</ul>
          </Disclosure>

          {full && <FullLayer ev={ev} onCite={openFact} />}
        </div>

        <p className="disclaimer">AI 辅助整理的研究阅读材料，事实以原文为准；不构成投资建议，不提供买卖、目标价、仓位或时机判断。</p>
      </article>

      {wide && (
        <aside className="panel" aria-label="依据与追问">
          <div className="panel-head">
            <div className="panel-tabs" role="tablist">
              <button role="tab" aria-selected={panel.tab !== 'ask'} className={panel.tab !== 'ask' ? 'on' : ''} onClick={() => setPanel({ tab: 'src' })}>依据</button>
              <button role="tab" aria-selected={panel.tab === 'ask'} className={panel.tab === 'ask' ? 'on' : ''} onClick={() => setPanel({ tab: 'ask' })}>追问</button>
            </div>
            <button className={`btn btn-sm ${watched ? 'btn-done' : 'btn-primary'}`} onClick={watched ? undefined : follow} aria-pressed={!!watched}>
              {watched ? <BookmarkCheck size={16} strokeWidth={1.75} aria-hidden="true" /> : <Bookmark size={16} strokeWidth={1.75} aria-hidden="true" />}
              {watched ? '已关注' : '关注后续'}
            </button>
          </div>
          <div className="panel-body" key={panel.tab === 'fact' ? panel.id : panel.tab === 'node' ? panel.node.id : panel.tab}>
            {panel.tab === 'src' && <SourceList ev={ev} onPick={(f) => setPanel({ tab: 'fact', id: f })} />}
            {panel.tab === 'metric' && (
              <MetricPanel
                eventId={ev.id}
                id={panel.id}
                ids={panel.ids}
                onPick={(id) => setPanel({ tab: 'metric', id, ids: panel.ids })}
                onAll={() => setPanel({ tab: 'src' })}
                onBack={() => {
                  const t = trigger.current;
                  if (t && document.contains(t)) { t.focus({ preventScroll: true }); t.scrollIntoView({ block: 'center' }); }
                }}
              />
            )}
            {panel.tab === 'fact' && (<>
              <button className="panel-back" onClick={() => setPanel({ tab: 'src' })}><ChevronLeft size={16} aria-hidden="true" /> 本篇全部依据</button>
              <EvidenceBody factId={panel.id} />
            </>)}
            {panel.tab === 'node' && (<>
              <button className="panel-back" onClick={() => setPanel({ tab: 'src' })}><ChevronLeft size={16} aria-hidden="true" /> 本篇全部依据</button>
              <NodeBody ev={ev} node={panel.node} view={view(panel.node)} onCite={(f) => setPanel({ tab: 'fact', id: f })} />
            </>)}
            {panel.tab === 'ask' && <AskBody ev={ev} onCite={(f) => setPanel({ tab: 'fact', id: f })} />}
          </div>
        </aside>
      )}
      </div>

      {!wide && <div className="actionbar glass">
        <button className="btn btn-quiet" onClick={() => setAsking(true)}>
          <MessageCircleQuestion size={18} strokeWidth={1.75} aria-hidden="true" /> 追问
        </button>
        <button className={`btn ${watched ? 'btn-done' : 'btn-primary'}`} onClick={watched ? undefined : follow} aria-pressed={!!watched}>
          {watched ? <BookmarkCheck size={18} strokeWidth={1.75} aria-hidden="true" /> : <Bookmark size={18} strokeWidth={1.75} aria-hidden="true" />}
          {watched ? '已关注' : '关注后续'}
        </button>
      </div>}

      {toast && watched && <Toast text={toastText} action={{ label: '加笔记', href: `#/watch/edit/${ev.id}/${watched.watchId}` }} onDone={endToast} />}

      {!wide && <>
        <EvidenceSheet target={evid} onClose={closeFact} onSwitch={switchMetric} />
        <NodeSheet ev={ev} node={node} view={node ? view(node) : null} onClose={closeNode} onCite={(f) => { setNode(null); setEvid({ kind: 'fact', id: f }); }} />
        <AskSheet ev={ev} open={asking} onClose={closeAsk} onCite={(f) => { setAsking(false); setEvid({ kind: 'fact', id: f }); }} />
      </>}
    </div>
  );
}

function RetroBlock({ ev, onCite }: { ev: EventItem; onCite: (f: string) => void }) {
  const r = ev.retro!;
  return (
    <div className="retro">
      <p className="retro-asked">{r.asked}</p>
      <ol className="retro-later">
        {r.later.map((l, i) => (
          <li key={i}>
            <span className="retro-date num">{l.date}</span>
            <p>{l.text} <Cite n="原文" onClick={() => onCite(l.factId)} /></p>
          </li>
        ))}
      </ol>
      <ul className="retro-verdicts">
        {r.verdicts.map((v, i) => (
          <li key={i}><span className={`verdict-tag v-${v.label}`}>{v.label}</span><p>{v.text}</p></li>
        ))}
      </ul>
      <p className="small dim">后续材料只收录已核对过原文的条目。</p>
    </div>
  );
}

type Panel = { tab: 'src' } | { tab: 'ask' } | { tab: 'fact'; id: string } | { tab: 'node'; node: PathNode } | { tab: 'metric'; id: string; ids: string[] };

/** 桌面右栏里的逐项核对：打开时焦点移到标题；「回到正文」把焦点还给点过的那个数字 */
function MetricPanel({ eventId, id, ids, onPick, onAll, onBack }: { eventId: string; id: string; ids: string[]; onPick: (id: string) => void; onAll: () => void; onBack: () => void }) {
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // 从切换按钮来的不抢焦点，只在从正文打开时把焦点放到标题
    if (!box.current?.contains(document.activeElement)) box.current?.querySelector<HTMLElement>('[data-mx-title]')?.focus({ preventScroll: true });
    box.current?.closest('.panel-body')?.scrollTo({ top: 0 });
  }, [id]);
  return (
    <div className="mx-panel" ref={box}>
      <div className="mx-panel-nav">
        <button className="panel-back" onClick={onAll}><ChevronLeft size={16} aria-hidden="true" /> 本篇全部依据</button>
        <button className="panel-back" onClick={onBack}>回到正文</button>
      </div>
      <MetricSwitch ids={ids} current={id} onPick={onPick} eventId={eventId} />
      <MetricEvidence metricId={id} eventId={eventId} showTitle />
    </div>
  );
}

/** 有差异卡配置、但当前版本不能展示：说清原因，不回退旧卡 */
function InsightUnavailable({ eventId, version, reason, problems }: { eventId: string; version: string; reason: string; problems: string[] }) {
  useEffect(() => { track('insight_unavailable', `${eventId}:${version}`); }, [eventId, version]);
  return <Stopped>差异卡暂不展示：{reason}{problems.length > 0 && <span className="small"> {problems.join('；')}</span>}</Stopped>;
}

/** 桌面依据栏的默认内容：本篇用到的全部事实与来源 */
function SourceList({ ev, onPick }: { ev: EventItem; onPick: (f: string) => void }) {
  const s = useStore((x) => x);
  const facts = FACTS.filter((f) => f.eventId === ev.id && factState(s, f) !== 'hidden');
  return (
    <div className="src-overview">
      <p className="block-note">点正文里的「原文」或编号，对应依据会显示在这里。</p>
      <ol className="src-items">
        {facts.map((f) => {
          const src = SOURCES.find((x) => x.id === f.sourceIds[0])!;
          const st = factState(s, f);
          return (
            <li key={f.id}>
              <button onClick={() => onPick(f.id)}>
                <span className="src-fact">{f.subject}<span className="dim"> · {f.period}</span></span>
                <span className="src-org">{src.org}</span>
                <span className={`evs evs-${st === 'missing' ? 'unverified' : st === 'corrected' ? 'corrected' : src.status}`}>{st === 'missing' ? '来源暂不可用' : st === 'corrected' ? '已更正' : evidenceLabel(src.status)}</span>
              </button>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

function NodeSheet({ ev, node, view, onClose, onCite }: { ev: EventItem; node: PathNode | null; view: NodeView | null; onClose: () => void; onCite: (f: string) => void }) {
  const s = useStore((x) => x);
  if (!node || !view) return <Sheet open={false} onClose={onClose} title="">{null}</Sheet>;
  const interp = node.interpId ? interpById(node.interpId) : undefined;
  const eff = interp ? interpEffective(s, interp) : null;
  const live = !eff || isLive(eff);
  return (
    <Sheet open onClose={onClose} title={live ? view.title : '这一步的解释已停止展示'} label={<>{node.stage} · {live ? <ToneTag tone={view.tone} /> : <StatusTag status={eff!.status} />}</>}>
      <NodeBody ev={ev} node={node} view={view} onCite={onCite} bare />
    </Sheet>
  );
}

function NodeBody({ ev, node, view, onCite, bare }: { ev: EventItem; node: PathNode; view: NodeView; onCite: (f: string) => void; bare?: boolean }) {
  const s = useStore((x) => x);
  const interp = node.interpId ? interpById(node.interpId) : undefined;
  const eff = interp ? interpEffective(s, interp) : null;
  const live = !eff || isLive(eff);
  return (
    <div className="node-body">
      {!bare && <div className="node-head"><span className="dim small">{node.stage}</span> {live ? <ToneTag tone={view.tone} /> : <StatusTag status={eff!.status} />}<h3 className="node-title">{live ? view.title : '这一步的解释已停止展示'}</h3></div>}
      {!live && <Stopped>{eff!.reason}</Stopped>}
      <div className="node-sec">
        <h3>依据是什么</h3>
        {node.basisFactIds.length ? (
          <ul className="facts">
            {node.basisFactIds.map((f, i) => {
              const fact = factById(f)!;
              const st = factState(s, fact);
              return (
                <li key={f}>
                  <p>{fact.text} <Cite n={i + 1} missing={st === 'missing'} onClick={() => onCite(f)} /></p>
                  {st !== 'active' && <span className="small warn">{st === 'corrected' ? '已更正' : '来源暂不可用'}</span>}
                </li>
              );
            })}
          </ul>
        ) : <p className="dim">这一步没有直接事实支持，是基于前一步的推论。</p>}
      </div>
      {live && (
        <>
          <div className="node-sec"><h3>为什么可能成立</h3><p>{node.why}</p>{view.note && <p className="dim">{view.note}</p>}</div>
          <div className="node-sec"><h3>什么情况下不再成立</h3><p>{node.breaksIf}</p></div>
          {interp && <div className="node-sec"><h3>依赖的条件</h3><p>{interp.conditions.join('；')}</p><p className="small dim">局限：{interp.limitations}</p></div>}
        </>
      )}
      {ev.kind === 'hypothetical' && <p className="small dim">本节点来自{ev.demoOnly ? '虚构示范公司' : '假设教学案例'}。</p>}
    </div>
  );
}

function CompareBlock({ ev, onCite }: { ev: EventItem; onCite: (f: string) => void }) {
  const s = useStore((x) => x);
  const c = ev.compare!;
  const [focus, setFocus] = useState(0);
  const cur = c.items[focus];
  return (
    <div>
      <p className="block-note">{c.lead}</p>
      <div className="cmp-tabs" role="tablist" aria-label="选择要对照的数字">
        {c.items.map((it, i) => (
          <button key={it.name} role="tab" aria-selected={i === focus} className={i === focus ? 'on' : ''} onClick={() => setFocus(i)}>
            <span>{it.name}</span>
            <span className="num">{it.value}</span>
            {factState(s, factById(it.factId)!) === 'missing' && <span className="cmp-off">来源不可用</span>}
          </button>
        ))}
      </div>
      <div className="cmp-grid" role="tabpanel">
        {c.dimLabels.map((d) => (
          <div key={d} className="cmp-row">
            <span className="cmp-dim">{d}</span>
            <span className="cmp-val">{cur.dims[d]}</span>
            <span className="cmp-others">
              {c.items.map((it, i) => i !== focus && (
                <span key={it.name} className={it.dims[d] === cur.dims[d] ? 'same' : 'diff'}>
                  <span className="sr-only">{it.dims[d] === cur.dims[d] ? '相同：' : '不同：'}</span>
                  <span className="dim">{it.name}　</span>{it.dims[d]}
                </span>
              ))}
            </span>
          </div>
        ))}
      </div>
      <button className="btn btn-ghost btn-sm" onClick={() => onCite(cur.factId)}>「{cur.name}」的原文依据</button>
      <div className="verdict">
        <p><strong>能否同时成立</strong>{c.coexist}</p>
        <p><strong>结论边界</strong>{c.boundary}</p>
      </div>
    </div>
  );
}

function TranslationBlock({ ev, onCite }: { ev: EventItem; onCite: (f: string) => void }) {
  return (
    <div>
      <p className="block-note">「强化语气」一栏是示例写法，不是某家媒体的真实报道。</p>
      <ul className="tr">
        {ev.translations!.map((t) => (
          <li key={t.original}>
            <p className="tr-en" lang="en">“{t.original}” <Cite n="原文" onClick={() => onCite(t.factId)} /></p>
            <p className="tr-ok"><span>贴近原文</span>{t.faithful}</p>
            <p className="tr-bad"><span>强化语气</span><s>{t.inflated}</s></p>
            <p className="small dim">{t.why}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

function FullLayer({ ev, onCite }: { ev: EventItem; onCite: (f: string) => void }) {
  const s = useStore((x) => x);
  const facts = FACTS.filter((f) => f.eventId === ev.id && factState(s, f) !== 'hidden');
  const interps = INTERPS.filter((i) => i.eventId === ev.id);
  return (
    <Disclosure open title="事实与解释分层" preview="本篇用到的全部事实和解释">
      {ev.deepNotes.map((n) => <p key={n} className="deep-note">{n}</p>)}
      <h3 className="sub">事实</h3>
      <ul className="facts">
        {facts.map((f, i) => {
          const st = factState(s, f);
          return (
            <li key={f.id} className={st !== 'active' ? 'is-off' : ''}>
              <p>{f.text} <Cite n={i + 1} missing={st === 'missing'} onClick={() => onCite(f.id)} /></p>
              <span className="small dim">{f.caliber}{st === 'corrected' ? ' · 已更正' : st === 'missing' ? ' · 来源暂不可用' : ''}</span>
            </li>
          );
        })}
      </ul>
      <h3 className="sub">解释</h3>
      <ul className="interps">
        {interps.map((i) => {
          const eff = interpEffective(s, i);
          if (eff.status === 'hidden') return null;
          return (
            <li key={i.id}>
              <StatusTag status={eff.status} />
              {isLive(eff) ? <p>{i.text}</p> : <p className="dim">{eff.reason}</p>}
              {isLive(eff) && <p className="small dim">依赖条件：{i.conditions.join('；')}</p>}
            </li>
          );
        })}
      </ul>
    </Disclosure>
  );
}

function QuizBlock({ ev, onCite }: { ev: EventItem; onCite: (f: string) => void }) {
  const picked = useStore((s) => s.quiz[ev.id]);
  const q = ev.quiz!;
  return (
    <div className="quiz">
      <p className="block-q">{q.q}</p>
      <div className="quiz-opts" role="radiogroup" aria-label={q.q}>
        {q.options.map((o, i) => {
          const state = picked === undefined ? '' : o.correct ? ' is-right' : picked === i ? ' is-wrong' : ' is-dim';
          return (
            <button key={o.t} role="radio" aria-checked={picked === i} className={`quiz-opt${state}`} onClick={() => answerQuiz(ev.id, i)} disabled={picked !== undefined}>
              {o.t}
              {picked !== undefined && o.correct && <span className="quiz-mark">正解</span>}
              {picked === i && !o.correct && <span className="quiz-mark">你的选择</span>}
            </button>
          );
        })}
      </div>
      {picked !== undefined && (
        <div className="quiz-explain">
          <p>{q.explain}</p>
          <div className="turn-cites">依据 {q.factIds.map((f, i) => <Cite key={f} n={i + 1} onClick={() => onCite(f)} />)}</div>
        </div>
      )}
    </div>
  );
}
