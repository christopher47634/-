import { describe, expect, it } from 'vitest';
import { EVENTS, eventById } from '../src/data/content';
import type { EventItem } from '../src/data/types';
import { LEAD_MIN, importance, personal, rankEvents, recencyScore, score } from '../src/logic/rank';
import { initialState, type State } from '../src/logic/store';
import { makeWatch } from '../src/logic/watch';

/* v0.7 重要程度 × 用户关注度排序：只测规则 */
const real = EVENTS.filter((e) => !e.demoOnly);
const ids = (r: { ev: EventItem }[]) => r.map((x) => x.ev.id);

describe('重要程度', () => {
  it('每条都在 0–100，且由五个维度加总', () => {
    for (const e of EVENTS) {
      const i = importance(e);
      expect(i.value).toBeGreaterThanOrEqual(0);
      expect(i.value).toBeLessThanOrEqual(100);
      expect(i.dims.map((d) => d.key)).toEqual(['scope', 'authority', 'magnitude', 'policy', 'recency']);
      expect(Math.round(i.dims.reduce((a, d) => a + d.points, 0))).toBe(i.value);
    }
  });
  it('每条资讯都有编辑写明理由的排序信号', () => {
    for (const e of EVENTS) {
      expect(e.signals, e.id).toBeTruthy();
      expect(e.signals!.magnitude[1].length, e.id).toBeGreaterThan(1);
    }
  });
  it('时效按资讯池日期计算：当天 5 分，一年前的历史案例 0 分', () => {
    expect(recencyScore(eventById('profit-2608')!)[0]).toBe(5);
    expect(recencyScore(eventById('baba-2506')!)[0]).toBe(0);
  });
  it('教学与虚构内容的来源权威为 0，排在所有真实资讯之后', () => {
    const r = ids(rankEvents(initialState(), real, 'importance'));
    expect(r[r.length - 1]).toBe('teach-cost');
  });
  it('新资讯整体排在一年前的历史案例之前（综合排序）', () => {
    const r = ids(rankEvents(initialState(), real));
    const lastNew = Math.max(...['profit-2608', 'price-2608', 'fomc-2609', 'macro-2608', 'realestate-2608'].map((x) => r.indexOf(x)));
    expect(lastNew).toBeLessThan(r.indexOf('cpi-2508'));
    expect(lastNew).toBeLessThan(r.indexOf('baba-2506'));
  });
});

describe('用户关注度', () => {
  it('新用户没有任何本机记录：与我相关为 0，关注度只来自（模拟）大众热度', () => {
    const s = initialState();
    const sc = score(s, eventById('price-2608')!);
    expect(sc.attnDims[1].score).toBe(0);
    expect(sc.simulatedHeat).toBe(true);
    expect(sc.attnDims[0].label).toMatch(/模拟/);
  });
  it('关注了 2025 年的 CPI 解读后，相关的 2026 年价格资讯「与我相关」上升', () => {
    const s0 = initialState();
    const s: State = { ...s0, watches: [makeWatch(s0, 'cpi-2508')] };
    const [p] = personal(s, eventById('price-2608')!);
    expect(p).toBeGreaterThanOrEqual(40);
    const before = ids(rankEvents(s0, real, 'attention')).indexOf('price-2608');
    const after = ids(rankEvents(s, real, 'attention')).indexOf('price-2608');
    expect(after).toBeLessThanOrEqual(before);
  });
  it('选择关心的主题会提高同主题资讯；读过的资讯降低，避免重复推荐', () => {
    const s0 = initialState();
    const e = eventById('realestate-2608')!;
    expect(personal({ ...s0, topics: ['房地产'] }, e)[0]).toBe(35);
    const read = { ...s0, topics: ['房地产'], track: [{ name: 'article_open', key: e.id, at: '' }] };
    expect(personal(read, e)[0]).toBe(20);
  });
});

describe('排序护栏', () => {
  it('热度极高、重要程度不足的内容上不了头条', () => {
    const bait: EventItem = { ...eventById('teach-cost')!, id: 'bait', signals: { scope: 'teaching', magnitude: [0, '无'], policy: [0, '无'], heat: 100 } };
    const s = { ...initialState(), topics: ['教学案例'] };
    for (const mode of ['mix', 'attention'] as const) {
      const r = rankEvents(s, [bait, ...real], mode);
      expect(r[0].sc.importance, mode).toBeGreaterThanOrEqual(LEAD_MIN);
      expect(r[0].ev.id).not.toBe('bait');
    }
  });
  it('综合分 = 重要程度 × 0.65 + 关注度 × 0.35', () => {
    const sc = score(initialState(), eventById('fomc-2609')!);
    expect(sc.total).toBe(Math.round(sc.importance * 0.65 + sc.attention * 0.35));
  });
  it('三种排序都返回全部资讯，名次连续', () => {
    for (const mode of ['mix', 'importance', 'attention'] as const) {
      const r = rankEvents(initialState(), real, mode);
      expect(r).toHaveLength(real.length);
      expect(r.map((x) => x.rank)).toEqual(real.map((_, i) => i + 1));
    }
  });
});
