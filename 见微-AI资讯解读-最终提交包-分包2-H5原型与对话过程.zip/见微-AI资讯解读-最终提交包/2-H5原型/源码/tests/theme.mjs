// 深色模式与自定义光标检查 + 截图。
//   node tests/theme.mjs [http://localhost:4173] [截图目录]
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { byText, launch, q, sleep } from './cdp.mjs';

const BASE = process.argv[2] || 'http://localhost:5178';
const OUT = process.argv[3] || join(process.cwd(), '..', '04-过程记录', '深色与光标截图');
mkdirSync(OUT, { recursive: true });
const b = await launch();
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
async function check(name, fn) {
  try { await fn(); results.push(['PASS', name]); console.log('PASS', name); }
  catch (e) { results.push(['FAIL', name, e.message]); console.log('FAIL', name, '—', e.message); }
}
const shot = (n, full) => b.shot(join(OUT, n + '.png'), full);
// WCAG 对比度：取元素文字色与给定底色
const contrast = (sel, bg) => b.ev(`(() => {
  const p = (c) => c.match(/[\\d.]+/g).slice(0, 3).map(Number);
  const L = ([r, g, bl]) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(bl); };
  const a = L(p(getComputedStyle(document.querySelector(${JSON.stringify(sel)})).color)), c = L(p(${JSON.stringify(bg)}));
  return (Math.max(a, c) + 0.05) / (Math.min(a, c) + 0.05);
})()`);
const hoverAt = async (expr) => {
  await b.ev(`(${expr}).scrollIntoView({block:'nearest'})`); await sleep(250);
  const r = await b.ev(`(()=>{const e=(${expr}).getBoundingClientRect();return {x:e.left+e.width/2,y:e.top+Math.min(e.height/2,40)}})()`);
  for (let i = 0; i < 6; i++) { await b.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: r.x + i, y: r.y }); await sleep(30); }
  await sleep(450);
};
const mode = () => b.ev(`document.querySelector('.cursor-ring')?.dataset.mode`);

// ---------- 手机：跟随系统深色 ----------
await b.viewport(390, 844);
// 真机手机是粗指针、不能悬停：打开触屏模拟
await b.send('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });
await b.send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: 'dark' }] });
await b.send('Page.navigate', { url: (BASE.endsWith('.html') ? BASE : BASE + '/') + '#/' });
await sleep(1200);
await b.ev('localStorage.clear()');
await b.send('Page.reload');
await sleep(1500);

await check('手机：跟随系统进入深色；正文对比度达标', async () => {
  assert(await b.ev(`document.documentElement.dataset.theme === 'dark'`), '没有跟随系统深色');
  for (const [sel, min] of [['.lead-title', 7], ['.lead-answer', 7], ['.row-source', 4.5], ['.meta', 4.5]]) {
    const c = await contrast(sel, 'rgb(7, 11, 23)');
    assert(c >= min, `${sel} 对比度 ${c.toFixed(1)} < ${min}`);
  }
  assert(!(await b.ev(`!!document.querySelector('.cursor-ring') && getComputedStyle(document.querySelector('.cursor-ring')).display !== 'none'`)), '触屏不应显示自定义光标');
  await sleep(1200);
  await shot('01-手机深色-首页');
});

await check('手机深色：详情、玻璃卡片、图表', async () => {
  await b.go('#/e/baba-2506'); await sleep(1800);
  const bf = await b.ev(`getComputedStyle(document.querySelector('.fig')).backdropFilter`);
  assert(/blur/.test(bf), '图表卡片没有玻璃模糊：' + bf);
  const c = await contrast('.insight-explain', 'rgb(16, 23, 43)');
  assert(c >= 7, '要点对比度不足：' + c.toFixed(1));
  await shot('02-手机深色-详情', true);
  await b.click(`document.querySelector('.gist-points .cite')`);
  await b.waitFor(`document.querySelector('[role=dialog]')`);
  await sleep(500);
  await shot('03-手机深色-依据抽屉');
  await b.key('Escape');
});

await check('手动切换：点主题按钮切回浅色，刷新后保持', async () => {
  await b.go('#/');
  await b.click(q('.theme-toggle'));
  assert(await b.ev(`document.documentElement.dataset.theme === 'light'`), '没有切换');
  await b.send('Page.reload'); await sleep(1200);
  assert(await b.ev(`document.documentElement.dataset.theme === 'light'`), '刷新后没有保持（系统仍是深色）');
  await b.click(q('.theme-toggle'));
  assert(await b.ev(`document.documentElement.dataset.theme === 'dark'`), '切不回深色');
});

// ---------- 桌面：光标 ----------
await b.send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: 'light' }] });
await b.send('Emulation.setTouchEmulationEnabled', { enabled: false });
await b.viewport(1440, 900, false);
await b.ev(`localStorage.clear()`);
await b.send('Page.reload'); await sleep(2000);

await check('桌面：启用自定义光标，隐藏系统指针', async () => {
  await b.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 700, y: 400 }); await sleep(300);
  assert(await b.ev(`document.documentElement.classList.contains('has-cursor')`), '没有启用');
  assert(await b.ev(`getComputedStyle(document.body).cursor === 'none'`), '系统指针未隐藏');
  assert(await b.ev(`getComputedStyle(document.querySelector('.cursor-ring')).display === 'block'`), '圆环未显示');
});

await check('悬停：按钮 → 放大；卡片 →「阅读」；图表 →「数据」；原文 → 小方框', async () => {
  await hoverAt(q('.hero-btn'));
  assert((await mode()) === 'link', '按钮：' + (await mode()));
  await shot('04-光标-首屏按钮');
  await b.ev(`document.getElementById('feed').scrollIntoView()`); await sleep(1500);
  await hoverAt(q('.dk-lead-text'));
  assert((await mode()) === 'read', '卡片：' + (await mode()));
  assert(await b.ev(`document.querySelector('.cursor-label').textContent === '阅读'`), '缺少「阅读」标签');
  await shot('05-光标-阅读');
  await hoverAt(q('.dk-lead .fig-svg'));
  assert((await mode()) === 'data', '图表：' + (await mode()));
  await shot('06-光标-图表');
  await b.go('#/e/baba-2506'); await sleep(900);
  await hoverAt(q('.gist-points .cite'));
  assert((await mode()) === 'cite', '原文：' + (await mode()));
  await shot('07-光标-原文');
});

await check('输入框交还系统文本光标', async () => {
  await b.click(byText('.panel-tabs button', '追问'));
  await hoverAt(q('.panel #ask'));
  assert((await mode()) === 'text', '输入框：' + (await mode()));
  assert(await b.ev(`getComputedStyle(document.querySelector('#ask')).cursor === 'text'`), '文本光标没有恢复');
});

// ---------- 桌面深色 ----------
await check('桌面深色：首屏、纸面变玻璃、详情依据栏', async () => {
  await b.go('#/');
  await b.click(q('.hero-nav .theme-toggle'));
  assert(await b.ev(`document.documentElement.dataset.theme === 'dark'`), '没有切到深色');
  await sleep(1200);
  await b.ev('window.scrollTo(0, innerHeight * 0.62)'); await sleep(900);
  const bf = await b.ev(`getComputedStyle(document.querySelector('.sheet-paper')).backdropFilter`);
  assert(/blur/.test(bf), '纸面没有玻璃模糊');
  await shot('08-桌面深色-玻璃纸面');
  await b.ev(`document.querySelector('.dk-grid').scrollIntoView({block:'start'})`); await sleep(1500);
  await hoverAt(`document.querySelectorAll('.dk-card a')[1]`);
  await shot('09-桌面深色-卡片悬停');
  await b.go('#/e/cpi-2508'); await sleep(1600);
  await b.click(`document.querySelector('.gist-points .cite')`); await sleep(500);
  await hoverAt(q('.panel .ev-source'));
  await shot('10-桌面深色-详情');
  const c = await contrast('.headline', 'rgb(7, 11, 23)');
  assert(c >= 7, '标题对比度不足');
});

await check('深色下无溢出、控制台无报错', async () => {
  for (const hash of ['#/', '#/e/fomc-2509', '#/watch', '#/studio']) { await b.go(hash); await sleep(300); assert(await b.noOverflow(), hash + ' 溢出'); }
  const real = b.problems.filter((p) => !/favicon/.test(p));
  assert(real.length === 0, real.join(' | '));
});

const pass = results.filter((r) => r[0] === 'PASS').length;
console.log(`\n${pass}/${results.length} 项通过；截图：${OUT}`);
writeFileSync(join(OUT, '深色与光标结果.json'), JSON.stringify({ base: BASE, at: new Date().toISOString(), results, problems: b.problems }, null, 2));
b.close();
process.exit(pass === results.length ? 0 : 1);
