# -*- coding: utf-8 -*-
"""
为单文件版生成内嵌字体：只保留页面里实际出现的字。
读取 @fontsource/noto-serif-sc/600.css 的各个 unicode-range 分片，
与 src/ 和 index.html 中出现的全部字符求交集，逐片裁剪成 woff2 并以 base64 内嵌，
输出 src/styles/font-embedded.css（单文件构建时替换原来的 600.css）。
用法：python scripts/subset-font.py
"""
import base64, io, os, re, sys
from fontTools import subset
from fontTools.ttLib import TTFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FS = os.path.join(ROOT, 'node_modules', '@fontsource', 'noto-serif-sc')
OUT = os.path.join(ROOT, 'src', 'styles', 'font-embedded.css')

# 1) 收集字符
chars = set()
for base in [os.path.join(ROOT, 'src'), os.path.join(ROOT, 'index.html')]:
    paths = [base] if os.path.isfile(base) else [os.path.join(d, f) for d, _, fs in os.walk(base) for f in fs if f.endswith(('.ts', '.tsx', '.css', '.html'))]
    for p in paths:
        if p.endswith('font-embedded.css'):
            continue
        chars.update(open(p, encoding='utf-8').read())
chars.update('0123456789%+−–—.,:;!?()[]「」『』《》、，。：；！？（）…·' + 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
cps = {ord(c) for c in chars if ord(c) > 31}

def in_range(cp, rng):
    for part in rng.split(','):
        part = part.strip().replace('U+', '')
        if '-' in part:
            a, b = part.split('-'); a, b = int(a, 16), int(b, 16)
        elif '?' in part:
            a, b = int(part.replace('?', '0'), 16), int(part.replace('?', 'F'), 16)
        else:
            a = b = int(part, 16)
        if a <= cp <= b:
            return True
    return False

css = open(os.path.join(FS, '600.css'), encoding='utf-8').read()
blocks = re.findall(r'@font-face\s*\{([^}]*)\}', css)
out, total, used = [], 0, 0
for blk in blocks:
    m_src = re.search(r"url\(\./files/([^)]+\.woff2)\)", blk)
    m_rng = re.search(r'unicode-range:\s*([^;]+);', blk)
    if not m_src or not m_rng:
        continue
    rng = m_rng.group(1)
    need = [cp for cp in cps if in_range(cp, rng)]
    if not need:
        continue
    font = TTFont(os.path.join(FS, 'files', m_src.group(1)))
    opts = subset.Options(); opts.flavor = 'woff2'; opts.layout_features = ['*']; opts.name_IDs = []; opts.notdef_outline = True
    sub = subset.Subsetter(opts); sub.populate(unicodes=need); sub.subset(font)
    buf = io.BytesIO(); font.flavor = 'woff2'; font.save(buf)
    data = buf.getvalue(); total += len(data); used += len(need)
    out.append("@font-face{font-family:'Noto Serif SC';font-style:normal;font-display:swap;font-weight:600;"
               f"src:url(data:font/woff2;base64,{base64.b64encode(data).decode()}) format('woff2');unicode-range:{rng};}}")

open(OUT, 'w', encoding='utf-8').write('/* 由 scripts/subset-font.py 生成：只含页面用到的字 */\n' + '\n'.join(out) + '\n')
print(f'{len(out)} 个分片，{used} 个字，内嵌字体 {total/1024:.0f} KB → {OUT}')
