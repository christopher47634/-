// v0.8 浏览器验收：实时快讯 + 财报对比。
// 用法：node tests/live-e2e.mjs <地址> [结果.json]
// 先在联网状态下验证「实时」，再用 CDP 屏蔽东方财富 / 新浪 / 巨潮的请求，验证「离线快照」兜底。
import { writeFileSync } from 'node:fs';
import { launch, sleep } from './cdp.mjs';

const BASE = process.argv[2] ?? 'http://localhost:5188/';
const OUT = process.argv[3];
const b = await launch();
const results = [];
const check = async (id, name, fn) => {
  try { const detail = await fn(); results.push({ id, name, ok: true, detail }); console.log('✓', id, name, detail ?? ''); }
  catch (e) { results.push({ id, name, ok: false, detail: String(e.message ?? e) }); console.log('✗', id, name, e.message ?? e); }
};
const assert = (c, m) => { if (!c) throw new Error(m); };
const open = async (hash) => {
  await b.send('Page.navigate', { url: BASE.replace(/#.*$/, '') + hash });
  await sleep(1200);
};
const store = () => b.ev(`JSON.parse(localStorage.getItem('jianwei.demo.v5')||'{}')`);

await b.viewport(390, 844);
await open('#/');
await b.ev(`localStorage.clear()`);
await open('#/');

await check('L1', '首页：快讯条连上实时接口，显示更新时间，前 3 条带两个分数', async () => {
  await b.waitFor(`document.querySelector('.live-status')?.dataset.status==='live'`, 15000);
  const t = await b.ev(`document.querySelector('.live-status').textContent`);
  assert(/实时 · \d\d\/\d\d \d\d:\d\d 更新/.test(t), t);
  const n = await b.ev(`document.querySelectorAll('.live-strip .live-row').length`);
  assert(n === 3, `快讯条 ${n} 条`);
  assert(await b.ev(`[...document.querySelectorAll('.live-strip .live-row')].every(r=>r.querySelector('.sc') && r.querySelector('.tag-live').textContent.includes('未核验'))`), '缺分数或未核验标签');
  assert(await b.ev(`!!document.querySelector('.fin-teaser') && document.querySelectorAll('.fin-teaser li').length===4`), '缺财报对比入口');
  assert(await b.noOverflow(), '横向溢出');
  return t;
});

await check('L2', '快讯页：展开一条看到原文链接和评分拆解；「只看重要」只留重要程度 ≥ 60', async () => {
  await open('#/live');
  await b.waitFor(`document.querySelectorAll('.live .live-row').length > 20`, 15000);
  const total = await b.ev(`document.querySelectorAll('.live .live-row').length`);
  await b.click(`document.querySelector('.live .live-head')`);
  const href = await b.ev(`document.querySelector('.live .live-body a[target=_blank]').href`);
  assert(/^https:\/\/(finance\.eastmoney\.com|finance\.sina)/.test(href), href);
  await b.click(`document.querySelector('.live-why summary')`);
  const dims = await b.ev(`document.querySelectorAll('.live-why .rk-row').length`);
  assert(dims === 7, `评分维度 ${dims}`);
  assert(await b.ev(`document.querySelector('.live-why').textContent.includes('真实数据')`), '热度没写真实数据');
  await b.click(`document.querySelector('.live-filter input')`);
  const imp = await b.ev(`[...document.querySelectorAll('.live .live-row .sc-item:not(.sc-attn) b')].map(x=>+x.textContent)`);
  assert(imp.length < total && imp.every((x) => x >= 60), `过滤后 ${imp.length}/${total}：${imp.join(',')}`);
  return `${total} 条 → 重要 ${imp.length} 条`;
});

await check('L3', '财报对比页：4 家核对过的公司 + 搜索任意 A 股（实时联想）', async () => {
  await open('#/fin');
  assert(await b.ev(`document.querySelectorAll('.fin-card').length`) === 4, '核对公司不是 4 家');
  assert(await b.ev(`[...document.querySelectorAll('.fin-card .tag-verified')].length===4`), '缺已核对标签');
  await b.click(`document.querySelector('#fin-q')`);
  await b.type('隆基');
  await b.waitFor(`document.querySelectorAll('.fin-hits a').length>0`, 8000);
  const hit = await b.ev(`document.querySelector('.fin-hits a').getAttribute('href')`);
  assert(hit === '#/fin/601012.SH', hit);
  return hit;
});

await check('L4', '茅台：环比 −31.7% 判为季节性；三项逐项对回原文页码；接口口径差异写明', async () => {
  await open('#/fin/600519.SH');
  await b.waitFor(`document.querySelector('.fin-api')?.textContent.includes('实时数据')`, 12000);
  const head = await b.ev(`document.querySelector('.fin-head').textContent`);
  assert(head.includes('同比下降 5.1%') && head.includes('季节性'), head);
  const rev = await b.ev(`document.querySelector('.fin-m[data-metric=rev]').textContent`);
  assert(rev.includes('367.9 亿') && rev.includes('−31.7%') && rev.includes('−5.1%') && rev.includes('+1.5%'), rev);
  assert(await b.ev(`document.querySelectorAll('.fin-src-item').length`) === 3, '原文核对不是 3 项');
  await b.click(`document.querySelector('.fin-src-item[data-metric=rev] summary')`);
  const links = await b.ev(`[...document.querySelectorAll('.fin-src-item[data-metric=rev] a')].map(a=>a.href)`);
  assert(links.length === 2 && links[0].startsWith('https://static.cninfo.com.cn/') && links[0].endsWith('#page=5') && links[1].endsWith('#page=1'), links.join(' '));
  assert(await b.ev(`document.querySelector('.fin-reason blockquote').textContent.includes('主要是本期销量增加')`), '缺公司原因');
  const api = await b.ev(`document.querySelector('.fin-api').textContent`);
  assert(api.includes('8/12') && api.includes('营业总收入'), api);
  assert(await b.ev(`document.querySelector('.fin-chart-note').textContent.includes('口径不同')`), '缺图表口径说明');
  assert(await b.noOverflow(), '横向溢出');
  return head;
});

await check('L5', '比亚迪：收入降、利润升；关注后写入本机', async () => {
  await open('#/fin/002594.SZ');
  const t = await b.ev(`document.querySelector('.fin-ins-item h3').textContent`);
  assert(t === '收入降、利润升', t);
  await b.click(`document.querySelector('.fin-actions button')`);
  const s = await store();
  assert(s.finFollow?.includes('002594.SZ'), JSON.stringify(s.finFollow));
  assert(await b.ev(`document.querySelector('.fin-actions button').getAttribute('aria-pressed')`) === 'true', '按钮状态');
  return t;
});

await check('L6', '接口公司（美的）：标「接口数据 · 未逐句核对」，给出三期报告原文 PDF', async () => {
  await open('#/fin/000333.SZ');
  await b.waitFor(`document.querySelectorAll('.fin-ann a').length===3`, 12000);
  assert(await b.ev(`!!document.querySelector('.fin-doc .tag-api')`), '缺接口标签');
  const pdf = await b.ev(`[...document.querySelectorAll('.fin-ann a')].map(a=>a.href)`);
  assert(pdf.every((u) => /^https:\/\/pdf\.dfcfw\.com\/pdf\/H2_AN\d+_1\.pdf$/.test(u)), pdf.join(' '));
  const self = await b.ev(`document.querySelector('.fin-api').textContent`);
  assert(/24 项一致/.test(self), self);
  return pdf.length + ' 份 PDF';
});

const liveProblems = [...b.problems];

// ---------- 屏蔽接口：退回离线快照 ----------
await b.send('Network.enable');
await b.send('Network.setBlockedURLs', { urls: ['*eastmoney.com*', '*sina.com.cn*', '*dfcfw.com*', '*cninfo.com.cn*'] });
b.problems.length = 0;

await check('L7', '接口被屏蔽：快讯退回离线快照并写明采集时间和原因，列表照常可用', async () => {
  await open('#/');
  await b.send('Page.reload'); // 整页重载：内存里上一次的实时结果清空，才是真正的「打开时就连不上」
  await sleep(1500);
  await b.waitFor(`document.querySelector('.live-status')?.textContent.includes('实时接口暂时取不到')`, 20000);
  const t = await b.ev(`document.querySelector('.live-status').textContent`);
  assert(t.includes('离线快照 · 采集于') && (await b.ev(`document.querySelector('.live-status').dataset.status`)) === 'snapshot', t);
  assert(await b.ev(`document.querySelectorAll('.live-strip .live-row').length`) === 3, '快照没有显示');
  return t;
});

await check('L8', '接口被屏蔽：核对过的公司照常显示原文数字；接口公司用快照；快照外的公司明确说取不到', async () => {
  await open('#/fin/300750.SZ');
  await b.send('Page.reload');
  await sleep(1500);
  await b.waitFor(`document.querySelector('.fin-api')?.textContent.includes('离线快照')`, 20000);
  assert((await b.ev(`document.querySelector('.fin-head').textContent`)).includes('增收不同步增利'), '宁德时代结论');
  await open('#/fin/000333.SZ');
  await b.waitFor(`!!document.querySelector('.fin-m')`, 20000);
  await open('#/fin/601012.SH');
  await b.waitFor(`document.querySelector('.empty-state h2')?.textContent.includes('暂时取不到')`, 20000);
  return 'ok';
});

const blockedNoise = b.problems.filter((p) => !/ERR_BLOCKED_BY_CLIENT|net::ERR|Failed to load resource/.test(p));

await check('L9', '宽屏 1440：首页快讯与财报并排，财报详情页不溢出', async () => {
  await b.send('Network.setBlockedURLs', { urls: [] });
  await b.viewport(1440, 900);
  await open('#/');
  await b.waitFor(`!!document.querySelector('.dk-live-fin .live-strip') && !!document.querySelector('.dk-live-fin .fin-teaser')`, 8000);
  const cols = await b.ev(`getComputedStyle(document.querySelector('.dk-live-fin')).gridTemplateColumns.split(' ').length`);
  assert(cols === 2, `列数 ${cols}`);
  assert(await b.noOverflow(), '首页溢出');
  await open('#/fin/688981.SH');
  assert(await b.noOverflow(), '详情溢出');
  assert((await b.ev(`document.querySelector('.fin-ins-item h3').textContent`)).includes('基数低'), '中芯结论');
  return `grid ${cols} 列`;
});

await check('L10', '控制台：联网阶段无报错；屏蔽阶段只有被屏蔽请求本身的报错', async () => {
  assert(!liveProblems.length, liveProblems.join(' | '));
  assert(!blockedNoise.length, blockedNoise.join(' | '));
  return 'clean';
});

b.close();
const pass = results.filter((r) => r.ok).length;
console.log(`\n${pass}/${results.length} 通过`);
if (OUT) writeFileSync(OUT, JSON.stringify({ base: BASE, at: new Date().toISOString(), pass, total: results.length, results }, null, 1));
process.exit(pass === results.length ? 0 : 1);
