// 桌面端检查与截图：叙事首屏、滚动盖纸、依据栏、图表动效（含动画中途帧）。
//   node tests/desktop.mjs [http://localhost:4173] [截图目录]
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { byText, launch, q, sleep } from './cdp.mjs';

const BASE = process.argv[2] || 'http://localhost:5178';
const OUT = process.argv[3] || join(process.cwd(), '..', '04-过程记录', '桌面端截图');
mkdirSync(OUT, { recursive: true });
const b = await launch();
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
async function check(name, fn) {
  console.log('…', name);
  try { await fn(); results.push(['PASS', name]); console.log('PASS', name); }
  catch (e) { results.push(['FAIL', name, e.message]); console.log('FAIL', name, '—', e.message); }
}
const shot = (n) => b.shot(join(OUT, n + '.png'));

console.log('start');
await b.viewport(1440, 900, false);
await b.send('Page.navigate', { url: (BASE.endsWith('.html') ? BASE : BASE + '/') + '#/' });
await sleep(1200);
await b.ev('localStorage.clear()');
await b.send('Page.reload');
await sleep(2200);

await check('首屏：流体画布在跑、标题逐行升起、导航可见', async () => {
  assert(await b.ev(`!!document.querySelector('.hero canvas.hero-ink:not(.is-off)')`), '流体未启用');
  assert(await b.ev(`document.querySelectorAll('.hero-title .line').length === 3`), '标题行数不对');
  for (let i = 0; i <= 30; i++) {
    await b.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 520 + i * 26, y: 330 + Math.sin(i / 4) * 170 });
    await sleep(18);
  }
  await sleep(900);
  assert(await b.noOverflow(), '水平溢出');
  await shot('01-首屏');
});

await check('滚动：纸面盖上首屏，首屏文字随进度淡出', async () => {
  await b.ev('window.scrollTo(0, innerHeight * 0.55)'); await sleep(700);
  const p = await b.ev(`parseFloat(getComputedStyle(document.querySelector('.hero')).getPropertyValue('--p'))`);
  assert(p > 0.3, '滚动进度没有传到首屏：' + p);
  await shot('02-滚动盖纸');
});

await check('精选区：头条两栏 + 图表动画播放完成', async () => {
  await b.ev(`document.getElementById('feed').scrollIntoView()`); await sleep(260);
  const mid = await b.ev(`document.querySelector('.dk-lead .fig').dataset.anim`);
  await shot('03-头条-动画中');
  await sleep(1800);
  assert(await b.ev(`document.querySelector('.dk-lead .fig').dataset.anim === 'in'`), '图表没有播放：' + mid);
  // v0.7 头条按评分排序（当前是美联储区间图，没有滚动数字）；滚动数字改查第一张带数值的卡片图
  const card = `[...document.querySelectorAll('.dk-grid .fig')].find(f=>f.querySelector('.fig-value'))`;
  await b.ev(`${card}.scrollIntoView({block:'center'})`); await sleep(2200);
  const v = await b.ev(`[...${card}.querySelectorAll('.fig-value')].map(e=>e.textContent)`);
  const want = await b.ev(`[...${card}.querySelectorAll('title')].map(t=>t.textContent.split('：')[1])`);
  assert(want.length > 0 && want.every((w) => v.includes(w)), '数字没有滚到最终值：' + v.join(',') + ' 期望 ' + want.join(','));
  await b.ev(`document.querySelector('.dk-lead').scrollIntoView({block:'start'})`); await sleep(300);
  const fs = await b.ev(`parseFloat(getComputedStyle(document.querySelector('.dk-lead .fig-label')).fontSize) * document.querySelector('.dk-lead .fig-svg').getBoundingClientRect().width / document.querySelector('.dk-lead .fig-svg').viewBox.baseVal.width`);
  assert(fs < 15, '图表文字被放大：' + fs.toFixed(1) + 'px');
  await shot('04-头条-动画后');
});

await check('卡片网格：两列、逐个浮现', async () => {
  await b.ev(`document.querySelector('.dk-grid').scrollIntoView({block:'start'})`); await sleep(1600);
  assert(await b.ev(`getComputedStyle(document.querySelector('.dk-grid')).gridTemplateColumns.split(' ').length === 2`), '不是两列');
  assert(await b.ev(`[...document.querySelectorAll('.dk-card')].every(c=>c.dataset.anim!=='armed' || c.getBoundingClientRect().top > innerHeight)`), '卡片没有浮现');
  await shot('05-卡片网格');
});

await check('详情：两栏；点「原文」在右栏显示依据，不弹抽屉', async () => {
  await b.go('#/e/baba-2506'); await sleep(900);
  assert(await b.ev(`!!document.querySelector('aside.panel') && !document.querySelector('.actionbar')`), '依据栏或操作栏状态不对');
  await shot('06-详情-依据栏');
  await b.click(`document.querySelector('.gist-points .cite')`);
  await b.waitFor(`document.querySelector('.panel .ev-body')`);
  assert(await b.ev(`!document.querySelector('[role=dialog]')`), '桌面不应弹抽屉');
  assert(await b.ev(`document.querySelector('.panel').textContent.includes('打开原文')`), '依据栏内容不全');
  await shot('07-详情-原文依据');
});

await check('详情：路径节点与追问也在右栏', async () => {
  await b.click(q('#sec-path .disc-btn')); await sleep(700);
  await b.click(`document.querySelectorAll('.pnode-card')[1]`);
  await b.waitFor(`document.querySelector('.panel .node-body')`);
  await b.click(byText('.panel-tabs button', '追问'));
  await b.waitFor(`document.querySelector('.panel .ask-body .chip')`);
  await b.click(q('.panel #ask')); await b.type('投资收益是什么意思'); await b.key('Enter');
  await b.waitFor(`[...document.querySelectorAll('.panel .turn-a')].some(e=>e.textContent.includes('编辑部撰写'))`);
  await b.click(byText('.panel-head .btn', '关注后续'));
  await b.waitFor(`document.querySelector('.panel-head .btn-done')`);
  await shot('08-详情-追问与关注');
});

await check('FOMC 区间图与降准斜线图动画完成', async () => {
  for (const id of ['fomc-2509', 'pboc-2505']) {
    await b.go('#/e/' + id); await sleep(1800);
    assert(await b.ev(`document.querySelector('.fig').dataset.anim === 'in'`), id + ' 图表未播放');
  }
  await shot('09-降准-斜线图');
});

await check('桌面我的关注与演示路线', async () => {
  await b.go('#/watch'); await sleep(800);
  assert(await b.ev(`document.querySelectorAll('.watch').length === 1`), '关注未显示');
  await b.click(`document.querySelector('.demo-switch')`);
  await b.waitFor(q('.tour-btn'));
  await b.click(q('.tour-btn'));
  await b.waitFor(q('.tour-card'));
  await shot('10-我的关注-演示路线');
});

await check('1280 与 1920 宽度无溢出', async () => {
  for (const [w, h] of [[1280, 800], [1920, 1080]]) {
    await b.viewport(w, h, false);
    for (const hash of ['#/', '#/e/cpi-2508', '#/watch', '#/studio']) { await b.go(hash); await sleep(300); assert(await b.noOverflow(), `${w} ${hash} 溢出`); }
  }
  await b.go('#/'); await sleep(1500);
  await shot('11-1920-首屏');
});

await check('控制台无报错', async () => {
  const real = b.problems.filter((p) => !/favicon/.test(p));
  assert(real.length === 0, real.join(' | '));
});

const pass = results.filter((r) => r[0] === 'PASS').length;
console.log(`\n${pass}/${results.length} 项通过；截图：${OUT}`);
writeFileSync(join(OUT, '桌面结果.json'), JSON.stringify({ base: BASE, at: new Date().toISOString(), results, problems: b.problems }, null, 2));
b.close();
process.exit(pass === results.length ? 0 : 1);
