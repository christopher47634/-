import { Check, Copy, ExternalLink } from 'lucide-react';
import { useEffect, useState } from 'react';
import { factById, refById, sourceById } from '../data/content';
import type { EvidenceRef, MetricNote } from '../data/types';
import { type MetricState, REF_LABEL, type RefState, metricState, outLink } from '../logic/evidence';
import { track, useStore } from '../logic/store';
import { Stopped } from './bits';

/*
 * 指标级证据：点哪个数字，就只看这个数字的原文。
 * 顺序：被点的指标 → 匹配的原文摘录（标出对应数字）→ 表格行列 → 来源、时间、版本 → 外部原文入口与检索关键词。
 * 本地高亮只表示「这段摘录核对过」；第三方网页能不能跳到这句，按真实验证记录写，不在前端假装成功。
 */

const MS_LABEL: Record<MetricState['status'], string> = {
  verified: '已核对原文摘录',
  partial: '部分来源不可用',
  weak: '仅有转述或未核对',
  corrected: '已更正',
  unavailable: '来源暂不可用',
  invalid: '引用无效',
};
const NOTE_LABEL: Record<MetricNote['kind'], string> = { company: '公司披露', editor: '编辑解释', unknown: '仍未知' };
/** 公司公告写「公司披露」，统计局、央行等写「官方披露」 */
export const noteLabel = (n: MetricNote, sourceId?: string) => (n.kind === 'company' && sourceId && !/BABA|DEMO/.test(sourceId) ? '官方披露' : NOTE_LABEL[n.kind]);

export const metricTitle = (m: { label: string; basis: string; display: string }) => `${m.label} · ${m.basis.split('（')[0].split('，')[0]} ${m.display}`;

export function MetricSwitch({ ids, current, onPick, eventId }: { ids: string[]; current: string; onPick: (id: string) => void; eventId: string }) {
  const s = useStore((x) => x);
  if (ids.length < 2) return null;
  const labels = ids.map((id) => metricState(s, id, eventId).metric?.label);
  return (
    <div className="mx-switch" role="group" aria-label="切换要核对的数字">
      {ids.map((id) => {
        const m = metricState(s, id, eventId).metric;
        if (!m) return null;
        return (
          <button key={id} aria-pressed={id === current} className={id === current ? 'on' : ''} onClick={() => onPick(id)}>
            <span>{labels.filter((l) => l === m.label).length > 1 ? `${m.label} ${m.basis.split('（')[0].split('，')[0]}` : m.label}</span>
            <span className="num">{m.display}</span>
          </button>
        );
      })}
    </div>
  );
}

export default function MetricEvidence({ metricId, eventId, showTitle }: { metricId: string; eventId: string; showTitle?: boolean }) {
  const s = useStore((x) => x);
  const st = metricState(s, metricId, eventId);
  useEffect(() => { track('metric_evidence_open', `${eventId}:${metricId}`); }, [eventId, metricId]);
  const m = st.metric;
  if (!m) return <Stopped>这个数字的引用无效：{st.reason}</Stopped>;
  const fact = factById(m.factId);
  const valueRefs = st.refs.filter((r) => r.ref && !r.ref.metricKey.endsWith('.reason'));
  // 能用的排前面
  valueRefs.sort((a, b) => Number(b.usable) - Number(a.usable));
  const src = valueRefs[0]?.ref ? sourceById(valueRefs[0].ref.sourceId) : undefined;
  const primary = valueRefs.find((r) => r.usable)?.ref ?? valueRefs[0]?.ref;

  return (
    <div className="mx" key={metricId}>
      {showTitle && (
        <h3 className="mx-title" tabIndex={-1} data-mx-title>
          {metricTitle(m)}
        </h3>
      )}
      <p className="mx-period">
        <span>{m.period}</span>
        <span className={`mx-st mx-st-${st.status}`}>{MS_LABEL[st.status]}</span>
      </p>
      {st.status === 'unavailable' && <Stopped>{st.reason}。下面保留的是历史摘录，只供对照，不作为有效事实展示；依赖它的解释已停止。</Stopped>}
      {st.status === 'partial' && <Stopped>{st.reason}。</Stopped>}
      {st.status === 'weak' && <Stopped>{st.reason}。</Stopped>}
      {st.status === 'corrected' && <Stopped>{st.reason}。</Stopped>}
      {st.status === 'invalid' && <Stopped>这个数字的引用无效：{st.reason}</Stopped>}

      <p className="mx-scope"><span className="mx-k">口径</span>{m.scope}</p>

      {valueRefs.map((r) => <Excerpt key={r.id} rs={r} />)}

      {m.derivation && (
        <details className="ev-more mx-derive">
          <summary>复算这个百分比</summary>
          <p className="num">{m.derivation.formula}</p>
          <p className="small dim">{m.derivation.rounding}</p>
        </details>
      )}

      {m.notes && m.notes.length > 0 && (
        <ul className="mx-notes">
          {m.notes.map((n, i) => <Note key={i} n={n} />)}
        </ul>
      )}

      {src && (
        <section className="mx-src" aria-label="来源">
          <p className="ev-org">{src.org}</p>
          <p className="ev-title">{src.title}</p>
          <dl className="ev-meta">
            <div><dt>发布时间</dt><dd>{src.publishedAt}</dd></div>
            <div><dt>文档版本</dt><dd>{src.docVersion}</dd></div>
            {primary?.checkedAt && <div><dt>摘录核对</dt><dd>{primary.checkedAt}（不代表此刻原站在线）</dd></div>}
          </dl>
          {primary && <OpenOriginal refItem={primary} disabled={st.status === 'invalid'} />}
        </section>
      )}

      {fact && (
        <details className="ev-more">
          <summary>这条事实能说明、不能说明什么</summary>
          <div className="ev-scope">
            <div className="scope-yes"><span>能支持</span>{fact.supports}</div>
            <div className="scope-no"><span>不能支持</span>{fact.notSupports}</div>
          </div>
        </details>
      )}
    </div>
  );
}

function Marked({ text, mark }: { text: string; mark?: string }) {
  if (!mark) return <>{text}</>;
  const i = text.indexOf(mark);
  if (i < 0) return <>{text}</>;
  return <>{text.slice(0, i)}<mark className="mx-mark">{mark}</mark>{text.slice(i + mark.length)}</>;
}

function Excerpt({ rs }: { rs: RefState }) {
  const r = rs.ref!;
  const en = /[A-Za-z]{6,}/.test(r.excerpt);
  return (
    <article className={`mx-ex${rs.usable ? '' : ' is-off'}`}>
      <div className="mx-ex-top">
        <span className="mx-ex-kind">{r.locator.kind === 'table' ? '表格行列' : '原文句子'}</span>
        <span className={`mx-st mx-st-${rs.usable ? 'verified' : 'unavailable'}`}>{REF_LABEL[rs.status]}</span>
      </div>
      {r.locator.kind === 'table' && (
        <dl className="mx-cell">
          <div><dt>表格</dt><dd lang={en ? 'en' : undefined}>{r.locator.table}</dd></div>
          <div><dt>行</dt><dd lang={en ? 'en' : undefined}>{r.locator.row}</dd></div>
          <div><dt>列</dt><dd lang={en ? 'en' : undefined}>{r.locator.column}</dd></div>
          <div><dt>单位</dt><dd>{r.locator.unit}</dd></div>
        </dl>
      )}
      <blockquote className="ev-quote" lang={en ? 'en' : 'zh-CN'}>
        <Marked text={r.excerpt} mark={r.mark} />
        <footer>{r.excerptKind === 'verbatim' ? '原文短摘录' : '转述，不是原文'} · {r.section}</footer>
      </blockquote>
      {r.translation && <p className="mx-tr"><span className="mx-k">{r.locator.kind === 'table' ? '读表提示' : '中文释义（非原文）'}</span>{r.translation}</p>}
      {!rs.usable && rs.reason && <p className="small warn">{rs.reason}</p>}
    </article>
  );
}

function Note({ n }: { n: MetricNote }) {
  const ref = n.refId ? refById(n.refId) : undefined;
  return (
    <li className={`mx-note mx-note-${n.kind}`}>
      <span className="mx-k">{noteLabel(n, ref?.sourceId)}</span>
      <p>{n.text}</p>
      {ref && ref.metricKey.endsWith('.reason') && (
        <details className="ev-more">
          <summary>{ref.sourceId.includes('BABA') ? '看公司原话' : '看官方原话'}</summary>
          <blockquote className="ev-quote" lang="en"><Marked text={ref.excerpt} mark={ref.mark} /><footer>原文短摘录 · {ref.section}</footer></blockquote>
          {ref.translation && <p className="mx-tr"><span className="mx-k">中文释义（非原文）</span>{ref.translation}</p>}
        </details>
      )}
    </li>
  );
}

/** 外部原文：用户点击同步打开新窗口；定位能力按验证记录如实说明，并始终给检索关键词 */
export function OpenOriginal({ refItem, disabled }: { refItem: EvidenceRef; disabled?: boolean }) {
  const [copied, setCopied] = useState(false);
  useEffect(() => setCopied(false), [refItem.id]);
  const link = outLink(refItem);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(refItem.searchText);
      setCopied(true);
    } catch {
      window.prompt('复制以下文字，到原文页面里搜索（Ctrl/⌘ + F）', refItem.searchText);
    }
  };
  return (
    <div className="mx-open">
      {link && !disabled ? (
        <a className="btn btn-primary" href={link.href} target="_blank" rel="noopener noreferrer" onClick={() => track('original_open_attempt', refItem.id)}>
          <ExternalLink size={18} strokeWidth={1.75} aria-hidden="true" /> {link.label}
        </a>
      ) : (
        <p className="small dim">{link ? '引用无效，暂不提供原文入口。' : '没有可用的原文链接。'}</p>
      )}
      {typeof navigator !== 'undefined' && navigator.onLine === false && <p className="small warn">当前处于离线状态：上面的本地摘录可以核对，打开原文需要联网。</p>}
      <p className="small dim">
        {link?.locates
          ? `${refItem.link!.testedBrowser}于 ${refItem.link!.testedAt} 验证可跳到这句。其他浏览器或原站改版后，若没有跳到对应段落，可以搜索下面的文字。`
          : '打开后如没有自动跳到对应位置，请在原文页面里搜索下面的文字。'}
      </p>
      <div className="mx-search">
        <code lang={/[A-Za-z]{6,}/.test(refItem.searchText) ? 'en' : undefined}>{refItem.searchText}</code>
        <button className="btn btn-ghost btn-sm" onClick={copy}>
          {copied ? <Check size={18} strokeWidth={1.75} aria-hidden="true" /> : <Copy size={18} strokeWidth={1.75} aria-hidden="true" />}
          {copied ? '已复制' : '复制检索关键词'}
        </button>
      </div>
      <p className="small dim">在原文哪里：{refItem.locator.kind === 'table' ? `「${refItem.locator.table}」表，「${refItem.locator.row}」行` : refItem.section}</p>
    </div>
  );
}
