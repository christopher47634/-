import { offMetricIds } from '../logic/evidence';
import { getState } from '../logic/store';
import { Bookmark, PauseCircle, PlayCircle, RotateCcw, Search, Trash2, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import { EVENTS, TOPICS } from '../data/content';
import type { EventItem } from '../data/types';
import Figure from '../components/Figure';
import { KindBadge, Reveal, Seal, ThemeSelect, ThemeToggle, coverOf } from '../components/bits';
import { go } from '../logic/router';
import { applyDemoCorrection, clearLocal, removeWatch, setDemoMode, storageOK, togglePause, useStore, adoptSuggestedQuestion } from '../logic/store';
import { watchStatus } from '../logic/watch';
import { useWide } from '../logic/hooks';
import HomeDesktop from './HomeDesktop';
import { ScoreChips, SortBar } from '../components/RankBits';
import { type Ranked, rankEvents } from '../logic/rank';
import type { HomeTab } from '../logic/router';
import { LiveList, LiveStrip } from '../components/LiveBits';
import { FinHome, FinTeaser } from './Fin';

export default function Home({ tab }: { tab: HomeTab }) {
  const wide = useWide();
  return wide ? <HomeDesktop tab={tab} /> : <HomeMobile tab={tab} />;
}

function HomeMobile({ tab }: { tab: HomeTab }) {
  const watches = useStore((s) => s.watches);
  const demo = useStore((s) => s.demoMode);
  return (
    <div className="page page-home">
      <header className="masthead">
        <a className="brand" href="#/" aria-label="见微 首页">
          <Seal />
          <span className="brand-name">见微</span>
          <span className="brand-sub">AI 资讯解读</span>
        </a>
        <div className="mast-actions">
        <ThemeToggle />
        <a className="icon-btn" href="#/watch" aria-label={`我的关注，${watches.length} 条`}>
          <Bookmark size={21} strokeWidth={1.7} />
          {watches.length > 0 && <span className="dot-count num">{watches.length}</span>}
        </a>
        </div>
      </header>

      <nav className="tabs" aria-label="首页入口">
        <a href="#/" className={tab === 'feed' ? 'on' : ''} aria-current={tab === 'feed' ? 'page' : undefined}>精选解读</a>
        <a href="#/live" className={tab === 'live' ? 'on' : ''} aria-current={tab === 'live' ? 'page' : undefined}>实时快讯</a>
        <a href="#/fin" className={tab === 'fin' ? 'on' : ''} aria-current={tab === 'fin' ? 'page' : undefined}>财报对比</a>
        <a href="#/watch" className={tab === 'watch' ? 'on' : ''} aria-current={tab === 'watch' ? 'page' : undefined}>
          我的关注{watches.length > 0 && <span className="num tab-n">{watches.length}</span>}
        </a>
      </nav>

      {tab === 'feed' && <Feed demo={demo} />}
      {tab === 'live' && <><SortBar /><LiveList /></>}
      {tab === 'fin' && <FinHome />}
      {tab === 'watch' && <Watches demo={demo} />}

      <footer className="foot">
        <details className="about">
          <summary>关于这些样本</summary>
          <p>三类内容，可信程度不同，页面上分别标注。<b>实时快讯</b>和<b>接口财报数据</b>在打开页面时从东方财富等公开接口实时获取，取不到时退回离线快照，并写明采集时间；这两类没有经过逐句核对。<b>精选解读</b>和<b>四家公司的财报对比</b>的每个数字都逐句核对过原文，包括 2026 年 8–9 月国家统计局、美联储的官方发布，2026 年半年报与一季报，以及 2025 年的历史案例。精选解读排序中的「大众热度」是演示用模拟值，快讯的热度来自来源网站的真实评论与分享。教学案例为假设情境。解读由 AI 辅助整理，审核标识为演示用的「模拟审核」。本页不构成投资建议。</p>
        </details>
        <label className="demo-switch">
          <input type="checkbox" role="switch" checked={demo} onChange={(e) => setDemoMode(e.target.checked)} />
          <span className="switch-track" aria-hidden="true"><span /></span>
          <span>演示模式<span className="dim">（评审用：内容工作台、异常场景）</span></span>
        </label>
        {demo && <a className="foot-link" href="#/studio">打开内容工作台</a>}
        <ThemeSelect />
      </footer>
    </div>
  );
}

function Feed({ demo }: { demo: boolean }) {
  const [q, setQ] = useState('');
  const [topic, setTopic] = useState('全部');
  const [searching, setSearching] = useState(false);
  const s = useStore((x) => x);
  const list = useMemo(() => {
    const k = q.trim();
    const hit = EVENTS.filter((e) => (demo || !e.demoOnly) && (topic === '全部' || e.topic === topic) && (!k || `${e.title}${e.question}${e.answer}${e.sourceLabel}`.includes(k)));
    return rankEvents(s, hit, s.sort);
  }, [q, topic, demo, s]);
  const [lead, ...rest] = list;

  return (
    <>
      <div className="filters">
        <div className="filter-row">
          <div className="topics" role="group" aria-label="主题筛选">
            {TOPICS.map((t) => (
              <button key={t} className={`topic${topic === t ? ' on' : ''}`} aria-pressed={topic === t} onClick={() => setTopic(t)}>{t}</button>
            ))}
          </div>
          <button className="icon-btn search-toggle" aria-label="搜索" aria-expanded={searching || !!q} onClick={() => setSearching((v) => !v)}>
            <Search size={19} strokeWidth={1.75} />
          </button>
        </div>
        {(searching || q) && <div className="search">
          <Search size={17} strokeWidth={1.75} aria-hidden="true" />
          <label className="sr-only" htmlFor="q">搜索解读</label>
          <input id="q" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索标题、答案或来源" autoComplete="off" enterKeyHint="search" autoFocus />
          <button className="icon-btn icon-sm" onClick={() => { setQ(''); setSearching(false); }} aria-label="关闭搜索"><X size={16} /></button>
        </div>}
      </div>

      <SortBar />

      {lead ? <Lead r={lead} /> : (
        <div className="empty">
          <p>没有匹配「{q}」的解读。</p>
          <button className="btn btn-ghost" onClick={() => { setQ(''); setTopic('全部'); }}>清空筛选</button>
        </div>
      )}

      {/* 头条之后：实时快讯 + 财报对比入口（头条仍在首屏内，答案先行） */}
      {!q && topic === '全部' && <><LiveStrip /><FinTeaser /></>}
      {!q && topic === '全部' && rest.length > 0 && <h2 className="feed-h">更多精选解读 <span className="small dim">· 每个数字都核对过原文</span></h2>}

      {rest.length > 0 && (
        <ol className="feed">
          {rest.map((r, i) => <Row key={r.ev.id} r={r} i={i} />)}
        </ol>
      )}
    </>
  );
}

function Meta({ ev }: { ev: EventItem }) {
  return (
    <div className="meta">
      <KindBadge ev={ev} />
      <span>{ev.topic}</span>
      <span className="num">{ev.sourceDate}</span>
    </div>
  );
}

function Lead({ r }: { r: Ranked }) {
  const ev = r.ev;
  const cover = coverOf(ev.id);
  return (
    <article className="lead">
      <a className="lead-link" href={`#/e/${ev.id}`}>
        {cover && <img className="cover" src={cover} alt="" loading="eager" />}
        <Meta ev={ev} />
        <ScoreChips sc={r.sc} rank={r.rank} />
        <h2 className="lead-title">{ev.question}</h2>
        <p className="lead-answer">{ev.answer}</p>
        <p className="lead-fact">{ev.title}</p>
      </a>
      {!cover && ev.figure && <div className="lead-fig"><Figure fig={ev.figure} off={offMetricIds(getState(), ev)} /></div>}
      <a className="lead-more" href={`#/e/${ev.id}`}>读完整解读 · 约 {ev.readMins} 分钟</a>
    </article>
  );
}

function Row({ r, i }: { r: Ranked; i: number }) {
  const ev = r.ev;
  const cover = coverOf(ev.id);
  return (
    <Reveal as="li" delay={Math.min(i, 3) * 60}>
      <a className={`row${cover ? ' has-cover' : ''}`} href={`#/e/${ev.id}`}>
        <div className="row-text">
          <Meta ev={ev} />
          <ScoreChips sc={r.sc} rank={r.rank} />
          <h3 className="row-title">{ev.question}</h3>
          <p className="row-answer">{ev.answer}</p>
          <p className="row-source">{ev.sourceLabel}</p>
        </div>
        {cover && <img className="thumb" src={cover} alt="" loading="lazy" />}
      </a>
    </Reveal>
  );
}

export function Watches({ demo }: { demo: boolean }) {
  const s = useStore((x) => x);
  const [confirm, setConfirm] = useState(false);

  return (
    <section aria-label="我的关注" className="watches">
      {!storageOK && <p className="note">当前浏览器不允许本地存储，关注只在本次打开期间保留。</p>}

      {s.watches.length === 0 ? (
        <div className="empty-state">
          <h2>还没有关注</h2>
          <p>读到想跟进的解读，点底部的「关注后续」。之后原文被更正、解释有变化，都会在这里提示。</p>
          <a className="btn btn-primary" href="#/">去看精选解读</a>
        </div>
      ) : (
        <ul className="watch-list">
          {s.watches.map((w) => {
            const ev = EVENTS.find((e) => e.id === w.eventId)!;
            const st = watchStatus(s, w);
            return (
              <li key={w.watchId} className={`watch${w.paused ? ' is-paused' : ''}`}>
                <div className="meta">
                  <KindBadge ev={ev} />
                  {st.simulated && <span className="tag tag-demo">演示更新</span>}
                  {w.paused && <span className="tag">已暂停</span>}
                </div>
                <h3 className="watch-title"><a href={`#/e/${w.eventId}`}>{ev.question}</a></h3>
                <p className={`watch-state state-${st.tone}`}>{st.label}</p>
                {w.openQuestion && <p className="watch-next"><span>想弄清</span>{w.openQuestion}</p>}
                <p className="watch-next"><span>下次看</span>{w.nextCheck}</p>
                {w.suggestedQuestion && (
                  <p className="watch-suggest small">
                    本卡建议的问题：「{w.suggestedQuestion}」
                    <button className="btn btn-ghost btn-sm" onClick={() => adoptSuggestedQuestion(w.watchId)}>改用这个问题</button>
                  </p>
                )}
                {w.note && <p className="watch-note">{w.note}</p>}
                <div className="watch-actions">
                  {st.tone !== 'ok' && <button className="btn btn-primary btn-sm" onClick={() => go(`#/update/${w.watchId}`)}>查看变化</button>}
                  <a className="btn btn-ghost btn-sm" href={`#/watch/edit/${w.eventId}/${w.watchId}`}>{w.note ? '改笔记' : '加笔记'}</a>
                  <button className="btn btn-ghost btn-sm" onClick={() => togglePause(w.watchId)}>
                    {w.paused ? <PlayCircle size={15} aria-hidden="true" /> : <PauseCircle size={15} aria-hidden="true" />}
                    {w.paused ? '恢复' : '暂停'}
                  </button>
                  <button className="btn btn-ghost btn-sm" onClick={() => removeWatch(w.watchId)} aria-label={`取消关注：${ev.question}`}>
                    <Trash2 size={15} aria-hidden="true" /> 取消
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <p className="note">关注只保存在这台设备的浏览器里，不会推送通知；打开这里时会重新检查原文更正和解释变化。</p>

      {demo && (
        <div className="demo-box">
          <h2><span className="tag tag-demo">演示</span> 模拟一次原文更正</h2>
          <p>加载一份<strong>虚构</strong>的「示范公司 A 更正公告」。先在首页打开「示范公司 A」并关注，再点这里，就能看到旧关注的提示。</p>
          <button className="btn btn-ghost" onClick={() => applyDemoCorrection('watch')} disabled={s.version['demo-a'] === 'v2'}>
            {s.version['demo-a'] === 'v2' ? '已加载演示更新（v2）' : '加载演示更新'}
          </button>
        </div>
      )}

      <div className="danger-zone">
        {confirm ? (
          <div className="confirm">
            <p>将删除本机上的全部关注、笔记、偏好和演示状态。</p>
            <div className="row-btns">
              <button className="btn btn-danger" onClick={() => { clearLocal(); setConfirm(false); }}>确认清除</button>
              <button className="btn btn-ghost" onClick={() => setConfirm(false)}>取消</button>
            </div>
          </div>
        ) : (
          <button className="btn btn-ghost btn-sm" onClick={() => setConfirm(true)}>
            <RotateCcw size={15} aria-hidden="true" /> 清除本地数据
          </button>
        )}
      </div>
    </section>
  );
}
