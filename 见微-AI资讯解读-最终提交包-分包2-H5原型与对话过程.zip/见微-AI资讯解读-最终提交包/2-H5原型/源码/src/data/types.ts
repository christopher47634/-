// 与方案 7.3 节同语义的核心对象。Demo 与生产字段保持一致，未知字段写 null 并附原因。

export type SampleKind = 'real' | 'hypothetical';

/** 证据状态：方案 4.4 —— 不显示没有校准依据的"可信度百分比" */
export type EvidenceStatus = 'original' | 'relayed' | 'unverified' | 'corrected';

export interface Source {
  id: string;
  kind: SampleKind;
  org: string;
  title: string;
  url: string | null;
  /** 原始发布时间，保留原时区写法，不换算成"今天" */
  publishedAt: string;
  /** 本 Demo 核验访问的日期 */
  accessedAt: string;
  docVersion: string;
  /** 来源链：谁发布、谁转载 */
  chain: string;
  /** 定位句：原文中可直接搜索到的开头片段 */
  locator: string;
  /** 短摘录（不超过一句）或自写释义 */
  excerpt: string;
  excerptIsParaphrase: boolean;
  status: EvidenceStatus;
  usageRight: string;
}

export interface Fact {
  id: string;
  eventId: string;
  text: string;
  sourceIds: string[];
  subject: string;
  period: string;
  value: string | null;
  caliber: string;
  /** 这份材料能支持什么 */
  supports: string;
  /** 这份材料不能支持什么 */
  notSupports: string;
  /** 版本：仅在某版本起生效 / 在某版本被更正 */
  introducedIn?: string;
  supersededIn?: string;
}

export type ReviewStatus =
  | 'draft'
  | 'needs_review'
  | 'published'
  | 'blocked'
  | 'superseded'
  | 'withdrawn';

export interface Interpretation {
  id: string;
  eventId: string;
  text: string;
  factIds: string[];
  conditions: string[];
  limitations: string;
  introducedIn?: string;
  supersededIn?: string;
}

export type NodeStage = '事件' | '经营变量' | '财务表现' | '待观察';
export type NodeTone = 'supported' | 'conditional' | 'undetermined' | 'watch';

export interface NodeView {
  title: string;
  tone: NodeTone;
  note?: string;
}

export interface PathNode {
  id: string;
  stage: NodeStage;
  base: NodeView;
  /** 依据：关联的事实 */
  basisFactIds: string[];
  /** 为什么成立 */
  why: string;
  /** 什么条件会使解释失去支撑 */
  breaksIf: string;
  interpId?: string;
  /** 条件切换只改变推论节点，不改事实层 */
  resolve?: (c: Record<string, boolean>) => NodeView;
}

export interface Toggle {
  id: string;
  label: string;
  hint: string;
  default: boolean;
}

export interface CompareItem {
  name: string;
  value: string;
  factId: string;
  dims: Record<string, string>;
}

export interface Compare {
  title: string;
  lead: string;
  dimLabels: string[];
  items: CompareItem[];
  coexist: string;
  boundary: string;
}

export interface Quiz {
  q: string;
  options: { t: string; correct: boolean }[];
  explain: string;
  factIds: string[];
}

export interface QA {
  id: string;
  q: string;
  /** 明确的常见同义问法（精确匹配，不做模糊检索） */
  aliases?: string[];
  a: string;
  factIds: string[];
  interpIds: string[];
}

/** 编辑部撰写的术语解释：只回答「是什么意思」，不涉及判断 */
export interface Term {
  term: string;
  aliases?: string[];
  text: string;
  factIds: string[];
}

export interface Translation {
  original: string;
  faithful: string;
  inflated: string;
  why: string;
  factId: string;
}

/** 解读要点：一条可以链接到解释或事实的句子 */
export interface Point {
  text: string;
  interpId?: string;
  factId?: string;
}

export interface Summary {
  fact: { text: string; factId: string };
  /** 两三句解释，每句都要能回到解释或事实 */
  points: Point[];
  /** 一个不能直接下结论的地方 */
  unknown: string;
}

/** 图表的一行。有 metricId 时，数值从指标表读取，并可以逐行核对原文 */
export interface FigureRow {
  label: string;
  value: number;
  display: string;
  metricId?: string;
}

/** 小图：数字本身就是内容，所以用图把对比摆出来 */
export type Figure =
  | { kind: 'bars'; title: string; unit: string; note: string; factIds: string[]; rows: FigureRow[] }
  /** base：茎线的起点（默认 0，读数是变动幅度）；PMI 这类水平读数用 50 荣枯线，并写 baseLabel */
  | { kind: 'dots'; title: string; unit: string; note: string; factIds: string[]; min: number; max: number; base?: number; baseLabel?: string; rows: FigureRow[] }
  | { kind: 'slope'; title: string; note: string; factIds: string[]; rows: { label: string; from: number; to: number; unit: string }[] }
  | { kind: 'range'; title: string; note: string; factIds: string[]; steps: { label: string; lo: number; hi: number; derived?: boolean }[] };

/** 历史复盘：当时的疑问 → 后来出现的材料 → 哪个解释被支持或修正 */
export interface Retro {
  asked: string;
  later: { date: string; text: string; factId: string }[];
  verdicts: { label: '支持' | '部分支持' | '修正' | '仍未知'; text: string }[];
}

export interface Revision {
  summary?: Summary;
  path?: PathNode[];
}

export interface EventItem {
  id: string;
  kind: SampleKind;
  /** 只在演示模式出现的异常场景样本 */
  demoOnly?: boolean;
  topic: string;
  type: string;
  /** 事实标题 */
  title: string;
  /** 读者会带着的问题 */
  question: string;
  /** 一句话先回答 */
  answer: string;
  sourceDate: string;
  sourceLabel: string;
  interpUpdatedAt: string;
  newFacts: string;
  /** 按字数估算，不是实测耗时 */
  readMins: number;
  aggregated?: string;
  summary: Summary;
  figure?: Figure;
  path: PathNode[];
  toggles?: Toggle[];
  compare?: Compare;
  translations?: Translation[];
  quiz?: Quiz;
  qa: QA[];
  terms?: Term[];
  retro?: Retro;
  /** 观察项的时间视角说明 */
  timeNote?: string;
  watchSuggestions: string[];
  deepNotes: string[];
  versions?: { id: string; label: string; note: string }[];
  /** 某版本起替换的要点与路径 */
  revisions?: Record<string, Revision>;
  /** 排序用的编辑信号（v0.7）；重要程度与关注度由 logic/rank.ts 计算 */
  signals?: RankSignals;
  /** 相关资讯：关注其中一条时，其它几条的「与我相关」会提高 */
  related?: string[];
}

/** 影响范围：全球 / 全国宏观 / 单一行业 / 单一公司 / 教学 */
export type RankScope = 'global' | 'macro' | 'sector' | 'company' | 'teaching';

export interface RankSignals {
  scope: RankScope;
  /** 变化幅度：0–5 分 + 编辑写明的理由 */
  magnitude: [number, string];
  /** 与政策或决策的关联：0–5 分 + 理由 */
  policy: [number, string];
  /** 大众热度 0–100：演示用模拟值，真实环境用站内阅读、搜索与关注数据 */
  heat: number;
}

export interface WatchItem {
  watchId: string;
  eventId: string;
  /** 保存时的版本：永远保留，用于对照 */
  savedVersion: string;
  savedAt: string;
  /** 用户看过更新并采纳的版本；不改 savedVersion */
  ackVersion?: string;
  change: string;
  basis: string;
  openQuestion: string;
  nextCheck: string;
  note: string;
  paused: boolean;
  /** 研究观察卡保存时依赖的解释 id，用于撤回联动 */
  interpIds: string[];
  /** 以下为关键差异卡带来的依赖（v0.6 起可选；旧数据没有这些字段） */
  insightId?: string;
  insightVersion?: string;
  factIds?: string[];
  evidenceRefIds?: string[];
  /** 本卡建议的问题：用户改过自己的问题时，不覆盖，只把建议放在这里等用户选择 */
  suggestedQuestion?: string;
}

// ---------- 逐项证据（v0.6） ----------

/** 原文里的位置：段落里的一句、表格里的一格、或 PDF 的一页 */
export type Locator =
  | { kind: 'text'; exact: string; prefix?: string; suffix?: string }
  | { kind: 'table'; table: string; row: string; column: string; unit: string }
  | { kind: 'pdf'; page: number; printedPage?: string; query: string };

/**
 * 外部原文定位。result 只能来自真实浏览器验证记录：
 * located = 验证时目标句子被滚动到视口内；openedOnly = 打开了原文但没有自动定位；
 * notTested = 没有验证过；failed = 验证过，定位失败。
 */
export interface EvidenceLink {
  method: 'element' | 'textFragment' | 'pdfPage' | 'plain';
  /** textFragment 的起始文字（未编码），element 的 id，pdfPage 的页码 */
  target: string;
  testedBrowser?: string;
  testedAt?: string;
  result: 'located' | 'openedOnly' | 'notTested' | 'failed';
}

export interface EvidenceRef {
  id: string;
  factId: string;
  sourceId: string;
  /** 必须等于 Source.docVersion，否则视为版本不匹配 */
  sourceVersion: string;
  /** 同一 Fact 内不同主张的稳定标识 */
  metricKey: string;
  label: string;
  /** 章节或表格标题 */
  section: string;
  locator: Locator;
  /** 经过核对的短摘录 */
  excerpt: string;
  excerptKind: 'verbatim' | 'paraphrase';
  /** 摘录里与数字对应的那一段，用于标记；必须是 excerpt 的子串 */
  mark?: string;
  /** 中文释义，页面上标注为释义，不当作原文 */
  translation?: string;
  /** 用户找不到时可以复制去原文里搜索的文字 */
  searchText: string;
  /** 真正核对摘录的日期；没核对就不填 */
  checkedAt?: string;
  verification: 'verified' | 'pending' | 'unavailable';
  link?: EvidenceLink;
}

/** 一句说明，标明是谁说的：公司披露 / 公司解释 / 编辑解释 / 仍未知 */
export interface MetricNote {
  kind: 'company' | 'editor' | 'unknown';
  text: string;
  refId?: string;
}

export interface InsightMetric {
  id: string;
  eventId: string;
  factId: string;
  evidenceRefIds: string[];
  label: string;
  /** 页面显示的数字，如 +76% */
  display: string;
  /** 画图用的数值 */
  value: number;
  period: string;
  unit: string;
  /** 同比、环比、报告口径等 */
  basis: string;
  /** 一句话口径：它衡量什么、不是什么 */
  scope: string;
  derivation?: { formula: string; inputRefIds: string[]; rounding: string };
  notes?: MetricNote[];
}

export interface DifferenceInsight {
  id: string;
  eventId: string;
  /** 适用的事件版本；当前版本没有对应卡片时不显示旧卡 */
  version: string;
  question: string;
  /** 默认可见的指标（2–3 项） */
  metricIds: string[];
  /** 正式解释仍存在 INTERPS 里 */
  interpIds: string[];
  /** 一句边界：这期材料还不足以判断什么 */
  boundary: string;
  openQuestion: string;
  nextCheck: string;
  /** 包括边界/问题中涉及的事实 */
  factIds: string[];
}
