// v0.6 关键差异与逐项核对：浏览器验收（本机 Chrome headless + CDP 真实点击 / 按键）
//   node tests/insight-e2e.mjs <http://localhost:4186 | file:///…/index.html> <截图目录> [结果 json]
// 编号对应方案包 04「关键验收矩阵」。截图只作佐证，每项都有断言。
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { byText, launch, q, sleep } from './cdp.mjs';

const BASE = process.argv[2] || 'http://localhost:4186';
const OUT = process.argv[3] || join(process.cwd(), 'e2e-shots');
const RES = process.argv[4];
mkdirSync(OUT, { recursive: true });
const URL0 = BASE.endsWith('.html') ? BASE : BASE + '/';
const KEY = 'jianwei.demo.v5';
const b = await launch();
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
const shot = (n, full) => b.shot(join(OUT, n + '.png'), full);
async function check(id, name, fn) {
  const t = Date.now();
  try { await fn(); results.push({ id, name, result: 'PASS', ms: Date.now() - t }); console.log('PASS', id, name); }
  catch (e) { results.push({ id, name, result: 'FAIL', error: e.message }); console.log('FAIL', id, name, '—', e.message); }
}
/** 清空本地状态后打开某页（先写存储再整页重载，避免内存里的旧状态写回） */
async function fresh(hash, state) {
  // 先到目标页，再写存储，再整页重载：页面打开时的埋点会把内存状态写回存储，顺序反了就会被覆盖
  await b.send('Page.navigate', { url: URL0 + hash });
  await sleep(900);
  await b.ev(`localStorage.clear(); ${state ? `localStorage.setItem(${JSON.stringify(state.key ?? KEY)}, ${JSON.stringify(JSON.stringify(state.value))})` : ''}`);
  await b.send('Page.reload');
  await sleep(1500);
}
const go = async (hash) => { await b.ev(`location.hash = ${JSON.stringify(hash)}`); await sleep(700); };
const store = () => b.ev(`JSON.parse(localStorage.getItem('${KEY}')||'{}')`);
const sheetTitle = () => b.ev(`document.querySelector('.sheet .sheet-title')?.textContent || ''`);
const firstQuote = () => b.ev(`document.querySelector('.mx .ev-quote')?.textContent || ''`);
const imCheck = (i) => `document.querySelectorAll('.insight .im-check')[${i}]`;
const figRow = (i) => `document.querySelectorAll('.fig-row')[${i}]`;
const studioRow = (id) => `[...document.querySelectorAll('.studio-list > li')].find(li=>li.querySelector('.mono').textContent==='${id}')`;
const srcSwitch = (id) => `[...document.querySelectorAll('.src-list li')].find(li=>li.textContent.includes('${id}')).querySelector('input')`;

const EXPECT = [
  ['净利润', /^Net income was RMB42,382/],
  ['经营利润', /^Income from operations was RMB34,988/],
  ['经营现金流', /^Net cash provided by operating activities was RMB20,672/],
];

// ================= 手机 390×844 =================
await b.viewport(390, 844);

await check('A01', '手机 390×844：首屏可见问题与第一项指标，字号正常', async () => {
  await fresh('#/e/baba-2506');
  await b.waitFor(q('.insight'));
  const r = await b.ev(`(()=>{const h=document.querySelector('.headline').getBoundingClientRect();const m=document.querySelector('.im').getBoundingClientRect();return {h:h.top, m:m.bottom, fs: parseFloat(getComputedStyle(document.querySelector('.im-label')).fontSize), body: parseFloat(getComputedStyle(document.body).fontSize)}})()`);
  assert(r.h >= 0 && r.m <= 844, `第一项指标在首屏外：${r.m}`);
  assert(r.fs >= 15 && r.body >= 16, '字号被缩小');
  assert(await b.noOverflow(), '水平溢出');
  await shot('01-手机-主卡首屏');
});

await check('A02', '依次点净利润 / 经营利润 / 经营现金流：标题、摘录、口径各自对应', async () => {
  for (let i = 0; i < 3; i++) {
    await b.click(imCheck(i));
    await b.waitFor(q('.sheet .mx'));
    const t = await sheetTitle(), qt = await firstQuote();
    assert(t.startsWith(EXPECT[i][0]), `第 ${i + 1} 项标题不对：${t}`);
    assert(EXPECT[i][1].test(qt), `第 ${i + 1} 项摘录不对：${qt.slice(0, 60)}`);
    assert(!/Free cash flow|attributable/.test(qt.split('原文短摘录')[0]), '摘录混入了自由现金流或归母净利润');
    assert(await b.ev(`!!document.querySelector('.sheet .mx-mark')`), '没有标出对应数字');
    if (i === 2) await shot('02-手机-经营现金流证据');
    await b.key('Escape');
    await sleep(250);
  }
});

await check('A07', '抽屉里切换指标：只有一个抽屉，内容与选中态同步', async () => {
  await b.click(imCheck(0));
  await b.waitFor(q('.sheet .mx-switch'));
  await b.click(`[...document.querySelectorAll('.sheet .mx-switch button')][2]`);
  assert(await b.ev(`document.querySelectorAll('.sheet').length === 1`), '叠了多个抽屉');
  assert((await sheetTitle()).startsWith('经营现金流'), '切换后标题没变');
  assert(await b.ev(`document.querySelector('.sheet .mx-switch button[aria-pressed="true"]').textContent.includes('经营现金流')`), '切换按钮选中态不同步');
  await b.key('Escape');
  await sleep(250);
});

await check('A04', '键盘：Enter 打开、Tab 留在抽屉内、Esc 关闭后焦点回到触发按钮', async () => {
  await b.ev(`window.scrollTo(0,0)`);
  const y0 = await b.ev('scrollY');
  await b.ev(`${imCheck(1)}.focus()`);
  await b.key('Enter');
  await b.waitFor(q('.sheet .mx'));
  for (let i = 0; i < 25; i++) {
    await b.key('Tab');
    assert(await b.ev(`!!document.activeElement.closest('.sheet')`), `第 ${i + 1} 次 Tab 焦点跑出了抽屉`);
  }
  await b.key('Escape');
  await sleep(300);
  assert(await b.ev(`document.activeElement === ${imCheck(1)}`), '关闭后焦点没回到触发按钮');
  assert(Math.abs((await b.ev('scrollY')) - y0) < 4, '关闭后阅读位置变了');
  // 图表行也能用键盘
  await b.ev(`${figRow(4)}.focus()`);
  await b.key('Enter');
  await b.waitFor(q('.sheet .mx'));
  assert((await sheetTitle()).startsWith('经营现金流'), '图表行键盘打开的不是经营现金流');
  await b.key('Escape');
  await sleep(250);
  assert(await b.ev(`document.activeElement === ${figRow(4)}`), '图表行关闭后焦点没回来');
});

await check('A03', '图表五行逐项引用：报告口径收入与同口径收入各自正确，不按下标误配', async () => {
  const want = [['收入（报告口径）', /^Revenue was RMB247,652/], ['收入（同口径）', /like-for-like basis would have grown by 10%/], ['经营利润', /^Income from operations/], ['净利润', /^Net income was/], ['经营现金流', /^Net cash provided by operating/]];
  assert(await b.ev(`document.querySelectorAll('.fig-row').length === 5`), '图表不是 5 行可点');
  for (let i = 0; i < 5; i++) {
    await b.click(figRow(i));
    await b.waitFor(q('.sheet .mx'));
    const t = await sheetTitle(), qt = await firstQuote();
    assert(t.startsWith(want[i][0]), `图表第 ${i + 1} 行标题：${t}`);
    assert(want[i][1].test(qt), `图表第 ${i + 1} 行摘录：${qt.slice(0, 70)}`);
    await b.key('Escape');
    await sleep(220);
  }
  const h = await b.ev(`Math.min(...[...document.querySelectorAll('.fig-hit')].map(r=>r.getBoundingClientRect().height))`);
  assert(h >= 40, `图表行热区过小：${h}`); // 42px 热区 + 行间距，整行 44px
});

await check('A05', '外链：新窗口打开、noopener、只有验证过的才写「打开原文定位」，并给检索关键词', async () => {
  await b.click(imCheck(2));
  await b.waitFor(q('.sheet .mx-open a'));
  const a = await b.ev(`(()=>{const a=document.querySelector('.sheet .mx-open a');return {href:a.href,t:a.target,rel:a.rel,txt:a.textContent}})()`);
  assert(a.t === '_blank' && /noopener/.test(a.rel) && /noreferrer/.test(a.rel), '外链属性不对');
  assert(a.href.startsWith('https://www.sec.gov/') && a.href.includes('#:~:text=Net%20cash%20provided'), '外链不是 SEC 文字片段：' + a.href);
  assert(await b.ev(`document.querySelector('.sheet .mx-search code').textContent.length > 10`), '没有检索关键词');
  assert(await b.ev(`document.querySelector('.sheet .mx-src').textContent.includes('不代表此刻原站在线')`), '没说明核对日期不代表在线');
  await b.key('Escape');
  await sleep(200);
  // 未验证定位的解释性引用：展开公司原话里不出现「定位」字样的按钮
  await b.ev(`document.querySelector('.insight-more').click()`);
  await sleep(200);
  assert(await b.ev(`document.querySelector('.insight-detail').textContent.includes('针对的是自由现金流')`), '口径说明没写清自由现金流与经营现金流的区别');
});

await check('A08', '关注这个问题：连点两次只有一张卡；旧卡笔记不丢；自己写的问题不被覆盖', async () => {
  await b.ev(`window.scrollTo(0,0)`);
  await b.click(`document.querySelector('.insight-actions .btn-primary')`);
  await sleep(300);
  let st = await store();
  assert(st.watches.length === 1 && st.watches[0].openQuestion === '后续经营现金流和相关投入如何变化？', '第一次关注不对');
  assert(st.watches[0].insightId === 'DI-BA-1' && st.watches[0].evidenceRefIds.includes('R-BA-OCF'), '没保存卡片与证据依赖');
  await b.click(`document.querySelector('.actionbar .btn')`); // 追问
  await sleep(200);
  await b.key('Escape');
  // 已有笔记 + 自己改过问题的旧卡
  const old = { schema: 5, watches: [{ watchId: 'w-old', eventId: 'baba-2506', savedVersion: 'v1', savedAt: '2026-09-20T00:00:00.000Z', ackVersion: 'v1', change: '', basis: '旧依据', openQuestion: '淘宝闪购什么时候能盈利？', nextCheck: '下一期季度公告中的经营现金流与资本开支', note: '我的私人笔记', paused: false, interpIds: ['I-BA-1'] }] };
  await fresh('#/e/baba-2506', { value: old });
  await b.waitFor(q('.insight'));
  await b.click(`document.querySelector('.insight-actions .btn')`);
  await sleep(300);
  await b.click(`document.querySelector('.insight-actions .btn')`); // 第二次：已关注时按钮变成「查看我的关注」
  await sleep(400);
  assert(await b.ev(`location.hash === '#/watch' && !!document.querySelector('.watch-suggest')`), '关注列表没给出「改用这个问题」');
  await go('#/e/baba-2506');
  st = await store();
  assert(st.watches.length === 1, `重复建卡：${st.watches.length}`);
  const w = st.watches[0];
  assert(w.note === '我的私人笔记' && w.savedAt === '2026-09-20T00:00:00.000Z', '笔记或保存时间被改');
  assert(w.openQuestion === '淘宝闪购什么时候能盈利？' && w.suggestedQuestion === '后续经营现金流和相关投入如何变化？', '自己写的问题被覆盖或没有给建议');
  assert(await b.ev(`!!document.querySelector('.insight-own')`), '卡片没提示可改用本卡问题');
  await shot('03-手机-保留自己的问题');
  await b.click(`document.querySelector('.insight-own button')`);
  await sleep(250);
  st = await store();
  assert(st.watches[0].openQuestion === '后续经营现金流和相关投入如何变化？' && !st.watches[0].suggestedQuestion && st.watches[0].note === '我的私人笔记', '采用本卡问题后状态不对');
});

await check('A09', '唯一必要来源不可用：主卡、图表、口径对照、解释、观察卡同步失效', async () => {
  await fresh('#/e/baba-2506');
  await b.click(`document.querySelector('.insight-actions .btn-primary')`);
  await sleep(250);
  await go('#/studio');
  await b.click(srcSwitch('S-BABA'));
  await sleep(250);
  assert(await b.ev(`[...document.querySelectorAll('.cov')].find(c=>c.textContent.includes('DI-BA-1')).textContent.includes('来源不可用')`), '工作台证据覆盖没有反映');
  await shot('04-工作台-来源不可用', true);
  await go('#/e/baba-2506');
  assert(await b.ev(`document.querySelectorAll('.insight .im.is-off').length === 3`), '主卡三项没有全部标为失效');
  assert(await b.ev(`document.querySelector('.insight .stopped')?.textContent.includes('停止')`), '解释没有停止');
  assert(!(await b.ev(`!!document.querySelector('.insight-explain')`)), '解释仍在显示');
  assert(await b.ev(`document.querySelectorAll('.fig-svg g.is-off').length === 5 && !!document.querySelector('.fig-off')`), '图表没有标出失效');
  await b.click(imCheck(2));
  await b.waitFor(q('.sheet .mx'));
  assert(await b.ev(`document.querySelector('.sheet .mx-st').textContent.includes('来源暂不可用')`), '证据里没标来源不可用');
  await shot('05-手机-来源不可用');
  await b.key('Escape');
  await go('#/watch');
  assert(await b.ev(`document.querySelector('.watch-state').textContent.includes('来源暂不可用')`), '观察卡没提示：' + (await b.ev(`document.querySelector('.watch-state')?.textContent`)));
  await go('#/studio');
  await b.click(srcSwitch('S-BABA'));
  await sleep(200);
});

await check('A10', '解释待复核：事实仍可核对，解释不显示；撤回后观察卡同步', async () => {
  await b.click(`${studioRow('I-BA-3')}.querySelector('.studio-actions .btn:nth-child(2)')`);
  await go('#/e/baba-2506');
  assert(await b.ev(`document.querySelectorAll('.insight .im.is-off').length === 0`), '待复核不应影响事实');
  assert(await b.ev(`document.querySelector('.insight .stopped').textContent.includes('待复核')`), '没显示待复核');
  await go('#/studio');
  await b.click(`${studioRow('I-BA-3')}.querySelector('.btn-danger')`);
  await go('#/watch');
  assert(await b.ev(`document.querySelector('.watch-state').textContent.includes('撤回')`), '观察卡没提示撤回');
});

await check('A11', '恢复来源但解释仍撤回：不会自动重新发布', async () => {
  await go('#/studio');
  await b.click(srcSwitch('S-BABA'));
  await sleep(150);
  await b.click(srcSwitch('S-BABA'));
  await sleep(150);
  await go('#/e/baba-2506');
  assert(await b.ev(`document.querySelector('.insight .stopped').textContent.includes('撤回')`), '撤回的解释被恢复了');
  assert(await b.ev(`document.querySelectorAll('.insight .im.is-off').length === 0`), '来源恢复后数字仍失效');
  await shot('06-手机-解释撤回');
});

await check('A09b', '可替代来源：核心 CPI 的解读稿不可用，数据表仍支持数字；依赖解读稿的解释停止', async () => {
  await fresh('#/studio');
  await b.click(srcSwitch('S-NBS-JD'));
  await sleep(150);
  await go('#/e/cpi-2508');
  assert(await b.ev(`document.querySelectorAll('.insight .im')[2].textContent.includes('部分来源不可用')`), '核心 CPI 没标部分来源不可用');
  assert(await b.ev(`document.querySelectorAll('.insight .im.is-off').length === 0`), '核心 CPI 不应失效');
  assert(!(await b.ev(`!!document.querySelector('.insight-explain')`)), '依赖翘尾的解释应停止');
  await b.click(imCheck(2));
  await b.waitFor(q('.sheet .mx'));
  assert(await b.ev(`document.querySelectorAll('.sheet .mx-ex').length === 2 && document.querySelectorAll('.sheet .mx-ex.is-off').length === 1`), '两条引用状态不对');
  assert((await b.ev(`document.querySelector('.sheet .mx-ex:not(.is-off) .ev-quote').textContent`)).includes('不包括食品和能源'), '有效引用应是数据表');
  await shot('07-手机-可替代来源');
  await b.key('Escape');
});

await check('A12', '更正（虚构示范公司 A）：旧观察卡提示新版本，采纳不抹掉笔记', async () => {
  await fresh('#/', { value: { schema: 5, demoMode: true, watches: [{ watchId: 'w-da', eventId: 'demo-a', savedVersion: 'v1', savedAt: '2026-09-20T00:00:00.000Z', ackVersion: 'v1', change: '', basis: '（虚构）', openQuestion: '分渠道收入没有书面披露。', nextCheck: '（虚构）分渠道收入的书面披露：尚未公布', note: '示范笔记', paused: false, interpIds: ['I-DA-1'] }] } });
  await go('#/studio');
  await b.click(byText('.studio-ver button', '发布演示更正'));
  await go('#/watch');
  assert(await b.ev(`document.querySelector('.watch-state').textContent.includes('v1 → v2')`), '没提示新版本');
  await b.click(byText('.watch-actions .btn', '查看变化'));
  await sleep(300);
  assert(await b.ev(`!!document.querySelector('.diff-del') && document.body.innerText.includes('示范笔记')`), '更新页没有旧值或笔记');
  await b.click(byText('.upd-actions .btn', '采纳'));
  const st = await store();
  assert(st.watches[0].savedVersion === 'v1' && st.watches[0].ackVersion === 'v2' && st.watches[0].note === '示范笔记', '采纳改了快照或笔记');
  await go('#/e/demo-a');
  assert(!(await b.ev(`!!document.querySelector('.insight')`)), '示范公司 A 不应出现差异卡');
});

await check('A15', '没有自然差异的文章：不出现差异卡或空壳', async () => {
  for (const id of ['pboc-2505', 'fomc-2509', 'teach-cost']) {
    await go('#/e/' + id);
    assert(!(await b.ev(`!!document.querySelector('.insight')`)) && !(await b.ev(`document.body.innerText.includes('差异卡暂不展示')`)), id + ' 出现了差异卡');
    assert(await b.ev(`!!document.querySelector('.answer') && !!document.querySelector('.gist-unknown')`), id + ' 原详情不完整');
  }
});

await check('A17', '旧版 localStorage（v4）迁移：观察卡与笔记保留，刷新不崩溃', async () => {
  const v4 = { schema: 4, demoMode: false, theme: 'system', review: {}, sourceMissing: {}, version: { 'demo-a': 'v1' }, demoUpdate: {}, conditions: {}, quiz: {}, depth: 'brief', topics: [], audit: [], track: [], reports: [], watches: [{ watchId: 'w-v4', eventId: 'cpi-2508', savedVersion: 'v1', savedAt: '2026-09-24T00:00:00.000Z', ackVersion: 'v1', change: 'x', basis: 'y', openQuestion: '剔除翘尾后的「新涨价因素」，这次材料没有单独给出完整数值，本页不自行推算。', nextCheck: '下一期 CPI 发布中的翘尾影响与核心 CPI', note: 'v4 时代的笔记', paused: false, interpIds: ['I-CPI-1'] }] };
  const before = b.problems.length;
  await fresh('#/watch', { key: 'jianwei.demo.v4', value: v4 });
  assert(await b.ev(`document.body.innerText.includes('v4 时代的笔记')`), '旧笔记没迁移过来');
  await b.send('Page.reload');
  await sleep(1200);
  assert(await b.ev(`document.body.innerText.includes('v4 时代的笔记')`), '刷新后丢失');
  assert(await b.ev(`localStorage.getItem('jianwei.demo.v4') !== null`), '旧键被改写或删除（旧版页面会受影响）');
  await go('#/e/cpi-2508');
  await b.click(`document.querySelector('.insight-actions .btn-primary')`);
  await sleep(250);
  const st = await store();
  assert(st.watches.length === 1 && st.watches[0].note === 'v4 时代的笔记' && st.watches[0].insightId === 'DI-CPI-1', '旧卡合并不对');
  assert(b.problems.length === before, '有脚本错误：' + b.problems.slice(before).join(' | '));
});

// ================= 375 / 390 / 1440，明暗 =================
for (const [w, h] of [[375, 812], [390, 844]]) {
  for (const theme of ['light', 'dark']) {
    await check('A16', `${w}px ${theme}：主卡、抽屉、图表无溢出，点击区 ≥ 44px`, async () => {
      await b.viewport(w, h);
      await fresh('#/e/baba-2506', { value: { schema: 5, theme, watches: [] } });
      await b.waitFor(q('.insight'));
      assert(await b.noOverflow(), '主卡页水平溢出');
      const small = await b.ev(`[...document.querySelectorAll('.insight .im-check, .insight-more, .insight-actions .btn')].map(e=>e.getBoundingClientRect()).filter(r=>r.height<44||r.width<44).length`);
      assert(small === 0, `有 ${small} 个点击区小于 44px`);
      await b.click(imCheck(0));
      await b.waitFor(q('.sheet .mx'));
      assert(await b.ev(`(()=>{const s=document.querySelector('.sheet-body');return s.scrollWidth<=s.clientWidth+1})()`), '抽屉内容横向溢出');
      const sw = await b.ev(`Math.min(...[...document.querySelectorAll('.sheet .mx-switch button, .sheet .mx-open .btn')].map(e=>e.getBoundingClientRect().height))`);
      assert(sw >= 44, '抽屉按钮小于 44px：' + sw);
      if (theme === 'dark') assert(await b.ev(`document.documentElement.dataset.theme === 'dark'`), '深色没生效');
      await shot(`08-${w}-${theme}-抽屉`);
      await b.key('Escape');
      await go('#/e/cpi-2508');
      assert(await b.noOverflow(), 'CPI 页水平溢出');
      if (w === 390) await shot(`09-${w}-${theme}-CPI`);
    });
  }
}

for (const [w, h] of [[375, 812], [390, 844]]) {
  await check('FLOW-m', `${w}px 主流程：阅读 → 核对 → 返回 → 关注 → 查看变化`, async () => {
    await b.viewport(w, h);
    await fresh('#/e/baba-2506');
    await b.waitFor(q('.insight'));
    await b.click(imCheck(2));
    await b.waitFor(q('.sheet .mx'));
    assert((await sheetTitle()).startsWith('经营现金流'), '核对的不是经营现金流');
    await b.key('Escape');
    await sleep(250);
    assert(await b.ev(`document.activeElement === ${imCheck(2)}`), '返回后焦点不在原数字');
    await b.click(`document.querySelector('.insight-actions .btn-primary')`);
    await sleep(250);
    await go('#/studio');
    await b.click(`${studioRow('I-BA-3')}.querySelector('.btn-danger')`);
    await go('#/watch');
    assert(await b.ev(`document.querySelector('.watch-state').textContent.includes('撤回')`), '观察卡没提示撤回');
    assert(await b.ev(`document.body.innerText.includes('后续经营现金流和相关投入如何变化')`), '观察卡没有保存的问题');
    await b.click(byText('.watch-actions .btn', '查看变化'));
    await sleep(300);
    assert(await b.ev(`document.body.innerText.includes('你关注时依据的数字')`), '变化页没有依据数字');
    assert(await b.noOverflow(), '溢出');
    await shot(`14-${w}-查看变化`, true);
  });
}

// ================= 桌面 1440 =================
await b.viewport(1440, 900, false, 1);
await check('A07-desk', '桌面：同一右栏切换三项指标，选中态同步，无遮罩；「回到正文」还焦点', async () => {
  await fresh('#/e/baba-2506');
  await b.waitFor(q('.insight'));
  for (let i = 0; i < 3; i++) {
    await b.click(imCheck(i));
    await sleep(250);
    const t = await b.ev(`document.querySelector('.panel .mx-title').textContent`);
    assert(t.startsWith(EXPECT[i][0]), `右栏标题：${t}`);
    assert(EXPECT[i][1].test(await b.ev(`document.querySelector('.panel .mx .ev-quote').textContent`)), '右栏摘录不对');
    assert(await b.ev(`document.querySelectorAll('.insight .im.is-focus').length === 1 && document.querySelectorAll('.insight .im')[${i}].classList.contains('is-focus')`), '主卡选中态不同步');
    assert(await b.ev(`document.querySelectorAll('.panel').length === 1 && !document.querySelector('.sheet-scrim')`), '出现遮罩或多个面板');
  }
  assert(await b.ev(`document.activeElement.matches('.mx-title')`), '焦点没移到右栏标题');
  await b.click(byText('.mx-panel-nav .panel-back', '回到正文'));
  assert(await b.ev(`document.activeElement === ${imCheck(2)}`), '「回到正文」没把焦点还给触发按钮');
  assert(await b.noOverflow(), '桌面水平溢出');
  await shot('10-桌面-右栏逐项核对');
  await b.ev(`document.querySelector('.fig').scrollIntoView({block:'center'})`);
  await sleep(1400);
  await b.click(figRow(1));
  await sleep(300);
  assert((await b.ev(`document.querySelector('.panel .mx-title').textContent`)).startsWith('收入（同口径）'), '桌面图表第 2 行不对');
  await shot('11-桌面-图表行引用');
});

await check('A16-desk', '桌面深色：主卡与右栏可读，无溢出', async () => {
  await fresh('#/e/cpi-2508', { value: { schema: 5, theme: 'dark', watches: [] } });
  await b.waitFor(q('.insight'));
  await b.click(imCheck(2));
  await sleep(300);
  assert(await b.ev(`document.documentElement.dataset.theme === 'dark'`), '深色没生效');
  assert(await b.noOverflow(), '溢出');
  await shot('12-桌面-深色-CPI');
});

await check('FLOW', '桌面主流程：阅读 → 核对 → 返回 → 关注 → 查看变化', async () => {
  await fresh('#/e/baba-2506');
  await b.click(imCheck(2));
  await b.click(byText('.mx-panel-nav .panel-back', '回到正文'));
  await b.click(`document.querySelector('.insight-actions .btn-primary')`);
  await sleep(250);
  await go('#/studio');
  await b.click(`${studioRow('I-BA-3')}.querySelector('.studio-actions .btn:nth-child(2)')`);
  await go('#/watch');
  assert(await b.ev(`document.querySelector('.watch-state').textContent.includes('待复核')`), '观察卡没提示待复核');
  await b.click(byText('.watch-actions .btn', '查看变化'));
  await sleep(300);
  assert(await b.ev(`document.body.innerText.includes('你关注时依据的数字') && document.body.innerText.includes('后续经营现金流和相关投入如何变化')`), '变化页没有依据数字或问题');
  await shot('13-桌面-查看变化', true);
});

const problems = b.problems.filter((p) => !/favicon/.test(p));
results.push({ id: 'console', name: '控制台无脚本错误', result: problems.length ? 'FAIL' : 'PASS', error: problems.join(' | ') || undefined });
const ver = await b.send('Browser.getVersion');
const summary = { base: BASE, browser: ver.product, at: new Date().toISOString(), pass: results.filter((r) => r.result === 'PASS').length, fail: results.filter((r) => r.result === 'FAIL').length, results };
console.log(`\n${summary.pass} passed, ${summary.fail} failed · ${ver.product}`);
if (RES) writeFileSync(RES, JSON.stringify(summary, null, 2));
b.close();
process.exit(summary.fail ? 1 : 0);
