import type { DifferenceInsight, EventItem, EvidenceRef, Fact, FigureRow, InsightMetric, Interpretation, Source } from './types';

/*
 * 2026 年 8–9 月的真实资讯（v0.7 扩充）
 * - 来源全部是一手官方发布：国家统计局「数据发布」与「最新发布与解读」、美联储官网声明。
 * - 2026-09-28 逐页抓取原文，数字与措辞逐句核对；摘录只取一句或一个表格格子。
 * - 「官方解读」是统计局首席统计师或新闻发言人的说法，页面标为「官方解释」，和见微的「编辑解释」分开。
 * - 住建部的二手房网签数据由统计局在发布稿中转引，口径里写明。
 * - 没有找到或没有核对过的数字一律不写；不做预测，不给买卖建议。
 */

const ACC = '2026-09-28';
const NBS = '国家统计局';
const nbs = (id: string, title: string, url: string, publishedAt: string, locator: string, excerpt: string, org = NBS): Source => ({
  id, kind: 'real', org, title, url, publishedAt, accessedAt: ACC, docVersion: '网页版',
  chain: org.includes('解读') || org.includes('发言人') ? '国家统计局「最新发布与解读」（官方解读）' : '国家统计局「数据发布」（一手）',
  locator, excerpt, excerptIsParaphrase: false, status: 'original', usageRight: '官方统计发布，短摘录 + 原文链接',
});

export const SOURCES_2026: Source[] = [
  nbs('S-26-PROFIT', '2026年1—8月份全国规模以上工业企业利润增长15.7%', 'https://www.stats.gov.cn/sj/zxfb/202609/t20260928_1965425.html', '2026-09-28 09:30（北京时间）',
    '正文第 1 段「1—8月份，全国规模以上工业企业实现利润总额」；倒数第 2 段「8月份，规模以上工业企业利润同比增长4.2%」', '1—8月份，全国规模以上工业企业实现利润总额52719.8亿元，同比增长15.7%'),
  nbs('S-26-PROFIT-JD', '国家统计局工业司首席统计师于卫宁解读2026年1—8月份工业企业利润数据', 'https://www.stats.gov.cn/sj/zxfbhjd/202609/t20260928_1965426.html', '2026-09-28（北京时间）',
    '「工业企业利润保持较快增长」一节；「电子行业对利润增长拉动明显」一节', '8月份，受去年同期较高基数影响，规模以上工业企业利润增速有所回落', '国家统计局（首席统计师解读）'),
  nbs('S-26-CPI', '2026年8月份居民消费价格同比上涨0.8%', 'https://www.stats.gov.cn/sj/zxfb/202609/t20260909_1965263.html', '2026-09-09 09:30（北京时间）',
    '正文第 1 段；文末数据表「其中：不包括食品和能源」一行', '2026年8月份，全国居民消费价格同比上涨0.8%。'),
  nbs('S-26-PPI', '2026年8月份工业生产者出厂价格同比上涨3.8% 环比上涨0.4%', 'https://www.stats.gov.cn/sj/zxfb/202609/t20260909_1965262.html', '2026-09-09 09:30（北京时间）',
    '正文第 1 段「全国工业生产者出厂价格同比上涨3.8%」', '2026年8月份，全国工业生产者出厂价格同比上涨3.8%，环比上涨0.4%。'),
  nbs('S-26-PRICE-JD', '国家统计局城市司首席统计师董莉娟解读2026年8月份CPI和PPI数据', 'https://www.stats.gov.cn/sj/zxfbhjd/202609/t20260909_1965261.html', '2026-09-09（北京时间）',
    '导语段；「一、CPI环比由降转涨，同比温和回升」中「从同比看」一段', '扣除食品和能源价格的核心CPI同比涨幅回升至1.0%', '国家统计局（首席统计师解读）'),
  nbs('S-26-IND', '2026年8月份规模以上工业增加值增长5.2%', 'https://www.stats.gov.cn/sj/zxfb/202609/t20260915_1965308.html', '2026-09-15 10:00（北京时间）',
    '正文第 1 段「规模以上工业增加值同比实际增长5.2%」', '8月份，规模以上工业增加值同比实际增长5.2%'),
  nbs('S-26-RETAIL', '2026年1—8月份社会消费品零售总额增长1.1%', 'https://www.stats.gov.cn/sj/zxfb/202609/t20260915_1965311.html', '2026-09-15 10:00（北京时间）',
    '正文第 2 段「8月份，社会消费品零售总额39824亿元」；数据表「汽车类」一行', '8月份，社会消费品零售总额39824亿元，同比增长0.4%。'),
  nbs('S-26-FAI', '2026年1—8月份全国固定资产投资基本情况', 'https://www.stats.gov.cn/sj/zxfb/202609/t20260915_1965309.html', '2026-09-15 10:00（北京时间）',
    '正文第 1 段「全国固定资产投资（不含农户）293092亿元」', '1—8月份，全国固定资产投资（不含农户）293092亿元，同比下降7.2%'),
  nbs('S-26-QA', '国家统计局新闻发言人就2026年8月份国民经济运行情况答记者问', 'https://www.stats.gov.cn/sj/zxfbhjd/202609/t20260915_1965332.html', '2026-09-15（北京时间）',
    '南华早报记者关于投资的提问及回答；CNBC 记者关于房地产的提问及回答', '一方面，夏季高温、台风、洪涝等极端天气频发，给部分地区的项目施工造成了不利影响', '国家统计局（新闻发言人答记者问）'),
  nbs('S-26-RE', '2026年1—8月份全国房地产市场基本情况', 'https://www.stats.gov.cn/sj/zxfb/202609/t20260915_1965310.html', '2026-09-15 10:00（北京时间）',
    '「一、房地产开发投资完成情况」与「二、商品房销售和待售情况」', '1—8月份，新建商品房销售面积49880万平方米，同比下降12.1%'),
  nbs('S-26-HP-JD', '国家统计局城市司高级统计师杨彩芳解读2026年8月份商品住宅销售价格变动情况统计数据', 'https://www.stats.gov.cn/sj/zxfbhjd/202609/t20260915_1965303.html', '2026-09-15（北京时间）',
    '「二、一二三线城市商品住宅销售价格同比降幅继续收窄」', '8月份，一线城市二手住宅销售价格同比下降2.7%，降幅比上月收窄1.0个百分点。', '国家统计局（高级统计师解读）'),
  nbs('S-26-PMI', '2026年8月中国采购经理指数运行情况', 'https://www.stats.gov.cn/sj/zxfb/202608/t20260831_1965154.html', '2026-08-31 09:30（北京时间）',
    '「一、中国制造业采购经理指数运行情况」第 1–2 段及分类指数段', '8月份，制造业采购经理指数（PMI）为49.8%，比上月上升0.6个百分点'),
  nbs('S-26-PMI-JD', '国家统计局服务业调查中心首席统计师霍丽慧解读2026年8月中国采购经理指数', 'https://www.stats.gov.cn/sj/zxfbhjd/202608/t20260831_1965155.html', '2026-08-31（北京时间）',
    '「（三）价格指数双双回升」', '受近期原油、有色金属价格上行等因素影响，制造业主要原材料购进价格指数和出厂价格指数分别为56.6%和50.4%', '国家统计局（首席统计师解读）'),
  {
    id: 'S-26-FED-SEP', kind: 'real', org: 'Board of Governors of the Federal Reserve System', title: 'Federal Reserve issues FOMC statement（2026-09-16）',
    url: 'https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a.htm', publishedAt: '2026-09-16 2:00 p.m. EDT（北京时间 2026-09-17 02:00）', accessedAt: ACC,
    docVersion: '网页版声明', chain: '美联储官网新闻稿（一手，英文）',
    locator: '声明第 1 句「approved the following statement for release by a 12 – 0 vote」；「decided to raise the target range」；「Inflation remains elevated」',
    excerpt: 'The Committee decided to raise the target range for the federal funds rate by 1/4 percentage point to 3-3/4 to 4 percent', excerptIsParaphrase: false, status: 'original', usageRight: '美国联邦政府公开文件，短摘录 + 链接',
  },
  {
    id: 'S-26-FED-JUL', kind: 'real', org: 'Board of Governors of the Federal Reserve System', title: 'Federal Reserve issues FOMC statement（2026-07-29）',
    url: 'https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm', publishedAt: '2026-07-29 2:00 p.m. EDT', accessedAt: ACC,
    docVersion: '网页版声明', chain: '美联储官网新闻稿（一手，英文）',
    locator: '「decided to maintain the target range」；投票段「Voting against the monetary policy action were」',
    excerpt: 'Voting against the monetary policy action were Beth M. Hammack, Neel Kashkari, and Lorie K. Logan, who preferred to raise the target range', excerptIsParaphrase: false, status: 'original', usageRight: '美国联邦政府公开文件，短摘录 + 链接',
  },
];

// ---------------- 事实 ----------------
const f = (x: Fact) => x;
export const FACTS_2026: Fact[] = [
  // 工业企业利润
  f({ id: 'F-PF-1', eventId: 'profit-2608', text: '2026 年 1—8 月，全国规模以上工业企业实现利润总额 52719.8 亿元，同比增长 15.7%（按可比口径计算）。', sourceIds: ['S-26-PROFIT'], subject: '规模以上工业企业利润总额', period: '2026 年 1—8 月（累计）', value: '52719.8 亿元 / +15.7%', caliber: '累计同比，可比口径', supports: '今年以来累计利润增长较快', notSupports: '最近一个月的增速；各企业的盈利状况' }),
  f({ id: 'F-PF-2', eventId: 'profit-2608', text: '2026 年 8 月单月，规模以上工业企业利润同比增长 4.2%；统计局解读称，受去年同期较高基数影响增速有所回落，同月毛利润增长 7.5%。', sourceIds: ['S-26-PROFIT', 'S-26-PROFIT-JD'], subject: '规模以上工业企业利润（当月）', period: '2026 年 8 月（当月）', value: '+4.2%', caliber: '当月同比', supports: '8 月单月利润增速明显低于累计增速', notSupports: '放缓会不会持续' }),
  f({ id: 'F-PF-3', eventId: 'profit-2608', text: '1—8 月，规模以上工业企业营业收入 93.09 万亿元，同比增长 6.6%；营业收入利润率为 5.66%，同比提高 0.44 个百分点；每百元营业收入中的成本为 85.07 元，同比减少 0.41 元。', sourceIds: ['S-26-PROFIT'], subject: '营业收入 / 利润率', period: '2026 年 1—8 月', value: '+6.6% / 5.66%', caliber: '累计同比', supports: '利润增速快于收入，利润率在提高', notSupports: '利润率提高的具体原因拆分' }),
  f({ id: 'F-PF-4', eventId: 'profit-2608', text: '1—8 月，电子行业利润同比增长 1.1 倍，对全部规模以上工业企业利润增长的贡献率达 62.0%；原材料制造业利润增长 47.3%。同期汽车制造业利润下降 16.0%，电力、热力生产和供应业下降 15.1%，黑色金属冶炼和压延加工业下降 62.4%。', sourceIds: ['S-26-PROFIT', 'S-26-PROFIT-JD'], subject: '分行业利润', period: '2026 年 1—8 月', value: null, caliber: '累计同比；电子行业贡献率为统计局解读口径', supports: '利润增长高度集中在少数行业', notSupports: '其他行业内企业的情况' }),
  // 价格
  f({ id: 'F-PR-1', eventId: 'price-2608', text: '2026 年 8 月，全国工业生产者出厂价格（PPI）同比上涨 3.8%，环比上涨 0.4%；工业生产者购进价格同比上涨 5.8%。', sourceIds: ['S-26-PPI'], subject: 'PPI', period: '2026 年 8 月', value: '+3.8%（同比）', caliber: '同比 / 环比', supports: '工业品出厂价格同比明显上涨', notSupports: '上涨能否传导到消费端' }),
  f({ id: 'F-PR-2', eventId: 'price-2608', text: '2026 年 8 月，全国居民消费价格（CPI）同比上涨 0.8%，环比上涨 0.4%；食品价格同比下降 1.4%，非食品价格上涨 1.2%。', sourceIds: ['S-26-CPI'], subject: 'CPI', period: '2026 年 8 月', value: '+0.8%（同比）', caliber: '同比 / 环比', supports: '居民消费价格温和上涨', notSupports: '各类商品价格走势的全部细节' }),
  f({ id: 'F-PR-3', eventId: 'price-2608', text: '扣除食品和能源价格的核心 CPI 同比上涨 1.0%（数据表「不包括食品和能源」一行，环比 0.1%）。', sourceIds: ['S-26-CPI', 'S-26-PRICE-JD'], subject: '核心 CPI', period: '2026 年 8 月', value: '+1.0%', caliber: '同比，剔除食品和能源', supports: '剔除食品和能源后价格仍温和上涨', notSupports: '整体 CPI 的方向' }),
  f({ id: 'F-PR-4', eventId: 'price-2608', text: '统计局解读：CPI 同比涨幅扩大主要受能源价格涨幅扩大影响（能源价格上涨 4.1%，其中汽油上涨 9.3%）；食品价格下降 1.4%，其中猪肉下降 11.8%，影响 CPI 同比下降约 0.24 个百分点。PPI 上涨受国际大宗商品价格上行传导等因素影响。', sourceIds: ['S-26-PRICE-JD'], subject: '官方对价格变动的解释', period: '2026 年 8 月', value: null, caliber: '官方解读', supports: '价格变动的主要来源', notSupports: '未来传导的幅度与时间' }),
  // 美联储
  f({ id: 'F-FD-1', eventId: 'fomc-2609', text: 'FOMC 以 12 比 0 通过，将联邦基金利率目标区间上调 25 个基点至 3.75%–4.00%。', sourceIds: ['S-26-FED-SEP'], subject: '联邦基金利率目标区间', period: '2026-09-16 决议', value: '3.75%–4.00%', caliber: '政策公布值', supports: '本次加息的幅度与投票结果', notSupports: '之后是否继续加息' }),
  f({ id: 'F-FD-2', eventId: 'fomc-2609', text: '声明称：通胀仍然偏高（Inflation remains elevated），此次政策行动将有助于更及时地回到 2% 的目标；经济活动稳健扩张，就业增长与劳动力增长大体同步，失业率变化不大。', sourceIds: ['S-26-FED-SEP'], subject: '声明措辞', period: '声明发布时', value: null, caliber: '声明原文措辞', supports: '委员会给出的加息理由', notSupports: '「通胀失控」「经济过热」等强化说法' }),
  f({ id: 'F-FD-3', eventId: 'fomc-2609', text: '上一次会议（2026-07-29）维持利率在 3.50%–3.75%，投票 9 比 3；三名反对者 Hammack、Kashkari、Logan 主张当时即加息 25 个基点。', sourceIds: ['S-26-FED-JUL'], subject: '上次会议', period: '2026-07-29 决议', value: '9–3', caliber: '声明原文', supports: '加息分歧在 7 月已公开出现', notSupports: '9 月全票的内部讨论细节' }),
  // 8 月经济
  f({ id: 'F-MC-1', eventId: 'macro-2608', text: '8 月，规模以上工业增加值同比实际增长 5.2%，比上月加快 0.7 个百分点；其中高技术制造业增加值增长 16.7%。', sourceIds: ['S-26-IND'], subject: '规模以上工业增加值', period: '2026 年 8 月（当月）', value: '+5.2%', caliber: '当月同比，实际增速（扣除价格因素）', supports: '工业生产加快', notSupports: '企业利润或需求的情况' }),
  f({ id: 'F-MC-2', eventId: 'macro-2608', text: '8 月，社会消费品零售总额 39824 亿元，同比增长 0.4%；除汽车以外的消费品零售额增长 2.5%，汽车类零售额下降 18.5%。', sourceIds: ['S-26-RETAIL'], subject: '社会消费品零售总额', period: '2026 年 8 月（当月）', value: '+0.4%', caliber: '当月同比，名义增速', supports: '商品消费增长偏弱，汽车类拖累明显', notSupports: '服务消费的全部情况（服务零售另有统计）' }),
  f({ id: 'F-MC-3', eventId: 'macro-2608', text: '1—8 月，全国固定资产投资（不含农户）293092 亿元，同比下降 7.2%；其中房地产开发投资下降 19.9%，扣除房地产开发的投资下降 4.2%，知识产权产品投资增长 9.2%。', sourceIds: ['S-26-FAI'], subject: '固定资产投资', period: '2026 年 1—8 月（累计）', value: '−7.2%', caliber: '累计同比，名义增速，可比口径', supports: '投资整体下降，结构分化', notSupports: '单月投资的变化' }),
  f({ id: 'F-MC-4', eventId: 'macro-2608', text: '统计局新闻发言人称，投资下降一方面因极端天气影响项目施工，另一方面外部环境复杂、企业投资决策较为谨慎。', sourceIds: ['S-26-QA'], subject: '官方对投资下降的解释', period: '2026-09-15 发布会', value: null, caliber: '官方解读', supports: '官方给出的主要原因', notSupports: '各原因的量化贡献' }),
  // 房地产
  f({ id: 'F-RE-1', eventId: 'realestate-2608', text: '1—8 月，新建商品房销售面积 49880 万平方米，同比下降 12.1%；销售额 47470 亿元，下降 13.0%。', sourceIds: ['S-26-RE'], subject: '新建商品房销售', period: '2026 年 1—8 月', value: '−12.1%（面积）', caliber: '累计同比', supports: '新房销售继续下降', notSupports: '二手房市场' }),
  f({ id: 'F-RE-2', eventId: 'realestate-2608', text: '统计局发布稿转引住房城乡建设部数据：1—8 月，二手房交易网签面积 54923 万平方米，同比增长 10.6%。', sourceIds: ['S-26-RE', 'S-26-QA'], subject: '二手房交易网签面积', period: '2026 年 1—8 月', value: '+10.6%', caliber: '住建部网签口径，由统计局转引', supports: '二手房成交面积增长', notSupports: '二手房价格上涨（价格仍在下降）' }),
  f({ id: 'F-RE-3', eventId: 'realestate-2608', text: '1—8 月，全国房地产开发投资 47979 亿元，同比下降 19.9%；8 月末新建商品房待售面积同比下降 1.1%。', sourceIds: ['S-26-RE'], subject: '房地产开发投资 / 待售面积', period: '2026 年 1—8 月 / 8 月末', value: '−19.9%', caliber: '累计同比，可比口径', supports: '开发投资大幅下降，库存小幅下降', notSupports: '市场何时企稳' }),
  f({ id: 'F-RE-4', eventId: 'realestate-2608', text: '统计局新闻发言人称，市场交易格局正从以新房交易为主逐步转向以存量房交易为主。', sourceIds: ['S-26-QA'], subject: '官方对交易结构的解释', period: '2026-09-15 发布会', value: null, caliber: '官方解读', supports: '新房与二手房反向变化的官方解释', notSupports: '交易总量已经企稳' }),
  f({ id: 'F-RE-5', eventId: 'realestate-2608', text: '统计局解读：8 月一线城市二手住宅销售价格同比下降 2.7%，降幅比上月收窄 1.0 个百分点；二、三线城市分别下降 4.9% 和 5.6%。', sourceIds: ['S-26-HP-JD'], subject: '二手住宅价格', period: '2026 年 8 月', value: '−2.7%（一线）', caliber: '70 个大中城市，同比', supports: '二手房价格仍在下降，但降幅收窄', notSupports: '单个城市或小区的价格' }),
  // PMI
  f({ id: 'F-PM-1', eventId: 'pmi-2608', text: '8 月，制造业采购经理指数（PMI）为 49.8%，比上月上升 0.6 个百分点，仍低于 50% 临界点。', sourceIds: ['S-26-PMI'], subject: '制造业 PMI', period: '2026 年 8 月', value: '49.8%', caliber: '扩散指数，50% 为荣枯线，经季节调整', supports: '制造业景气回升但整体仍处收缩区间', notSupports: '具体产量或利润的增减幅度' }),
  f({ id: 'F-PM-2', eventId: 'pmi-2608', text: '8 月，新订单指数为 50.6%，比上月上升 2.1 个百分点；生产指数为 50.4%。', sourceIds: ['S-26-PMI'], subject: '新订单 / 生产指数', period: '2026 年 8 月', value: '50.6% / 50.4%', caliber: '扩散指数', supports: '需求与生产分项回到扩张区间', notSupports: '订单增长的来源（内需或外需）' }),
  f({ id: 'F-PM-3', eventId: 'pmi-2608', text: '8 月，大型企业 PMI 为 50.6%，中型企业 49.4%，小型企业 47.9%。', sourceIds: ['S-26-PMI'], subject: '分规模 PMI', period: '2026 年 8 月', value: '50.6 / 49.4 / 47.9', caliber: '扩散指数', supports: '企业规模之间景气分化', notSupports: '单个企业经营状况' }),
  f({ id: 'F-PM-4', eventId: 'pmi-2608', text: '统计局解读：受原油、有色金属价格上行等影响，主要原材料购进价格指数和出厂价格指数分别为 56.6% 和 50.4%，比上月上升 3.4 个和 2.6 个百分点。', sourceIds: ['S-26-PMI-JD'], subject: '价格指数', period: '2026 年 8 月', value: '56.6% / 50.4%', caliber: '扩散指数，官方解读', supports: '企业面对的原材料价格上涨更快', notSupports: '企业利润率变化' }),
];

// ---------------- 解释（编辑解释与条件） ----------------
export const INTERPS_2026: Interpretation[] = [
  { id: 'I-PF-1', eventId: 'profit-2608', text: '累计增速和当月增速回答不同的问题：1—8 月 +15.7% 包含了前几个月的高增长，8 月单月只有 +4.2%，统计局解释为去年同期基数较高。利润增速快于收入（+6.6%），是因为利润率在提高。', factIds: ['F-PF-1', 'F-PF-2', 'F-PF-3'], conditions: ['三个数字来自同一份发布', '基数解释以统计局口径为准'], limitations: '编辑解释；一个月数据不足以判断利润增速是否转弱。' },
  { id: 'I-PF-2', eventId: 'profit-2608', text: '利润增长高度集中：电子行业一个行业贡献了约六成增量，原材料行业受价格上涨带动；汽车、电力、钢铁行业利润下降。总量数字不能代表多数行业的处境。', factIds: ['F-PF-4'], conditions: ['以统计局公布的分行业数据为准'], limitations: '不涉及具体公司；行业利润增长不等于该行业所有企业盈利改善。' },
  { id: 'I-PR-1', eventId: 'price-2608', text: 'PPI 和 CPI 衡量的是不同环节的价格：PPI 是工业品出厂价，受国际能源、有色金属价格影响更大；CPI 里食品占比较高，猪肉等食品价格下降抵消了能源上涨。所以上游涨 3.8%、消费端只涨 0.8% 可以同时成立。', factIds: ['F-PR-1', 'F-PR-2', 'F-PR-3', 'F-PR-4'], conditions: ['使用同一月份的官方发布', '价格传导按统计局解读的方向理解'], limitations: '上游涨价向消费端传导多少、多快，本期材料不能回答。' },
  { id: 'I-FD-1', eventId: 'fomc-2609', text: '加息的理由写在「通胀仍然偏高」和「更及时回到 2% 目标」上，同时声明说经济稳健扩张、就业稳定——这是在经济不弱的前提下优先压通胀，而不是对经济转差的反应。7 月已有三票主张加息，9 月变成全票。', factIds: ['F-FD-1', 'F-FD-2', 'F-FD-3'], conditions: ['按声明原文措辞理解，不引入会后发布会和经济预测摘要'], limitations: '本页未使用会后发布会与经济预测摘要（SEP），不讨论之后的利率路径。' },
  { id: 'I-MC-1', eventId: 'macro-2608', text: '三个数字衡量不同的环节，期间也不同：工业增加值是 8 月当月的实际增速，社零是 8 月当月的名义增速，固定资产投资是 1—8 月累计。生产加快、消费偏弱、投资下降可以同时成立；消费偏弱主要来自汽车类（−18.5%），投资下降中房地产开发拖累最大。', factIds: ['F-MC-1', 'F-MC-2', 'F-MC-3'], conditions: ['当月与累计口径分开比较', '名义与实际增速不直接相减'], limitations: '编辑解释；不据此判断全年增长。' },
  { id: 'I-RE-1', eventId: 'realestate-2608', text: '新房销售面积下降、二手房网签面积增长可以同时成立：两者是不同的市场，统计局认为交易正从新房转向存量房。但二手房成交增长不等于价格回升——同月一线城市二手住宅价格同比仍下降 2.7%。', factIds: ['F-RE-1', 'F-RE-2', 'F-RE-4', 'F-RE-5'], conditions: ['二手房数据为住建部网签口径，由统计局转引'], limitations: '成交面积不含价格信息；交易总量是否企稳需要更长时间观察。' },
  { id: 'I-PM-1', eventId: 'pmi-2608', text: 'PMI 是扩散指数，看的是「回答变好的企业是否多于变差的」，50% 是分界线。总指数 49.8% 仍在收缩区间，但新订单和生产两个分项已回到 50% 以上；大型企业在扩张，小型企业仍明显偏弱。', factIds: ['F-PM-1', 'F-PM-2', 'F-PM-3'], conditions: ['按统计局经季节调整后的指数理解'], limitations: 'PMI 反映的是方向和广度，不代表产量或利润的增减幅度。' },
];

// ---------------- 逐项证据 ----------------
const V = '网页版';
const r = (x: Omit<EvidenceRef, 'sourceVersion' | 'checkedAt' | 'verification' | 'excerptKind'> & Partial<EvidenceRef>): EvidenceRef => ({ sourceVersion: V, checkedAt: ACC, verification: 'verified', excerptKind: 'verbatim', ...x });
const tf = (target: string) => ({ method: 'textFragment' as const, target, result: 'notTested' as const });
// 2026-09-28 在有界面的 Chrome 里从单文件成品真实点击验证，每条 3 轮（tests/outlink-verify.mjs … v07，结果 research/v07/outlink-v07.json）
const TESTED = { testedBrowser: 'Chrome 153.0.8010.53（Windows，有界面窗口）', testedAt: '2026-09-28' };
const loc = (target: string) => ({ method: 'textFragment' as const, target, ...TESTED, result: 'located' as const });
/** 3 轮里有没落点的，不算定位成功：按钮写「打开原文」，并给检索关键词 */
const opened = (target: string) => ({ method: 'textFragment' as const, target, ...TESTED, result: 'openedOnly' as const });

export const REFS_2026: EvidenceRef[] = [
  r({ id: 'R-PF-YTD', factId: 'F-PF-1', sourceId: 'S-26-PROFIT', metricKey: 'profit.ytd.yoy', label: '1—8 月利润同比', section: '正文第 1 段',
    locator: { kind: 'text', exact: '1—8月份，全国规模以上工业企业实现利润总额52719.8亿元，同比增长15.7%' },
    excerpt: '1—8月份，全国规模以上工业企业实现利润总额52719.8亿元，同比增长15.7%（按可比口径计算，详见附注二）。', mark: '同比增长15.7%', searchText: '全国规模以上工业企业实现利润总额', link: loc('全国规模以上工业企业实现利润总额') }),
  r({ id: 'R-PF-AUG', factId: 'F-PF-2', sourceId: 'S-26-PROFIT', metricKey: 'profit.aug.yoy', label: '8 月利润同比', section: '正文倒数第 2 段',
    locator: { kind: 'text', exact: '8月份，规模以上工业企业利润同比增长4.2%。' },
    excerpt: '8月份，规模以上工业企业利润同比增长4.2%。', mark: '同比增长4.2%', searchText: '规模以上工业企业利润同比增长4.2%', link: loc('规模以上工业企业利润同比增长4.2%') }),
  r({ id: 'R-PF-AUG-WHY', factId: 'F-PF-2', sourceId: 'S-26-PROFIT-JD', metricKey: 'profit.aug.reason', label: '官方对 8 月回落的解释', section: '「工业企业利润保持较快增长」一节',
    locator: { kind: 'text', exact: '8月份，受去年同期较高基数影响，规模以上工业企业利润增速有所回落' },
    excerpt: '8月份，受去年同期较高基数影响，规模以上工业企业利润增速有所回落，同比增长4.2%；从营业收入扣减营业成本计算的毛利润看，规模以上工业企业毛利润增长7.5%，比上月加快1.9个百分点。', mark: '受去年同期较高基数影响', searchText: '受去年同期较高基数影响', link: tf('受去年同期较高基数影响') }),
  r({ id: 'R-PF-REV', factId: 'F-PF-3', sourceId: 'S-26-PROFIT', metricKey: 'revenue.ytd.yoy', label: '1—8 月营业收入同比', section: '正文「营业收入」一段',
    locator: { kind: 'text', exact: '1—8月份，规模以上工业企业实现营业收入93.09万亿元，同比增长6.6%' },
    excerpt: '1—8月份，规模以上工业企业实现营业收入93.09万亿元，同比增长6.6%；发生营业成本79.19万亿元，增长6.1%；营业收入利润率为5.66%，同比提高0.44个百分点。', mark: '同比增长6.6%', searchText: '规模以上工业企业实现营业收入', link: loc('规模以上工业企业实现营业收入') }),
  r({ id: 'R-PF-ELEC', factId: 'F-PF-4', sourceId: 'S-26-PROFIT-JD', metricKey: 'profit.sector.reason', label: '官方：电子行业贡献', section: '「电子行业对利润增长拉动明显」一节',
    locator: { kind: 'text', exact: '电子行业利润同比增长1.1倍，对全部规模以上工业企业利润增长的贡献率达62.0%' },
    excerpt: '1—8月份，电子行业利润同比增长1.1倍，对全部规模以上工业企业利润增长的贡献率达62.0%，是规模以上工业企业利润较快增长的重要支撑。', mark: '贡献率达62.0%', searchText: '电子行业利润同比增长1.1倍' }),

  r({ id: 'R-PR-PPI', factId: 'F-PR-1', sourceId: 'S-26-PPI', metricKey: 'ppi.yoy', label: 'PPI 同比', section: '正文第 1 段',
    locator: { kind: 'text', exact: '2026年8月份，全国工业生产者出厂价格同比上涨3.8%，环比上涨0.4%。' },
    excerpt: '2026年8月份，全国工业生产者出厂价格同比上涨3.8%，环比上涨0.4%。工业生产者购进价格同比上涨5.8%，环比上涨0.3%。', mark: '同比上涨3.8%', searchText: '全国工业生产者出厂价格同比上涨', link: loc('全国工业生产者出厂价格同比上涨') }),
  r({ id: 'R-PR-CPI', factId: 'F-PR-2', sourceId: 'S-26-CPI', metricKey: 'cpi.yoy', label: 'CPI 同比', section: '正文第 1 段',
    locator: { kind: 'text', exact: '2026年8月份，全国居民消费价格同比上涨0.8%。' },
    excerpt: '2026年8月份，全国居民消费价格同比上涨0.8%。其中，城市上涨0.8%，农村上涨0.7%；食品价格下降1.4%，非食品价格上涨1.2%。', mark: '同比上涨0.8%', searchText: '全国居民消费价格同比上涨', link: loc('全国居民消费价格同比上涨') }),
  r({ id: 'R-PR-CORE-T', factId: 'F-PR-3', sourceId: 'S-26-CPI', metricKey: 'core_cpi.yoy', label: '核心 CPI（数据表）', section: '2026年8月份居民消费价格主要数据（表）',
    locator: { kind: 'table', table: '2026年8月份居民消费价格主要数据', row: '其中：不包括食品和能源', column: '同比涨跌幅（%）', unit: '%' },
    excerpt: '其中：不包括食品和能源　环比 0.1　同比 1.0　1—8月 1.1', mark: '同比 1.0', translation: '发布稿的表格里没有「核心 CPI」这个名称，对应的是「不包括食品和能源」一行。', searchText: '不包括食品和能源' }),
  r({ id: 'R-PR-CORE-JD', factId: 'F-PR-3', sourceId: 'S-26-PRICE-JD', metricKey: 'core_cpi.yoy', label: '核心 CPI（解读稿）', section: '解读稿导语段',
    locator: { kind: 'text', exact: '扣除食品和能源价格的核心CPI同比涨幅回升至1.0%' },
    excerpt: '……扣除食品和能源价格的核心CPI同比涨幅回升至1.0%。', mark: '回升至1.0%', searchText: '扣除食品和能源价格的核心', link: loc('扣除食品和能源价格的核心') }),
  r({ id: 'R-PR-CPI-WHY', factId: 'F-PR-4', sourceId: 'S-26-PRICE-JD', metricKey: 'cpi.reason', label: '官方：CPI 上涨原因', section: '「一、CPI环比由降转涨，同比温和回升」',
    locator: { kind: 'text', exact: '从同比看，全国CPI上涨0.8%，涨幅比上月扩大0.3个百分点，主要是受能源价格涨幅扩大影响。' },
    excerpt: '从同比看，全国CPI上涨0.8%，涨幅比上月扩大0.3个百分点，主要是受能源价格涨幅扩大影响。', mark: '主要是受能源价格涨幅扩大影响', searchText: '主要是受能源价格涨幅扩大影响' }),
  r({ id: 'R-PR-FOOD', factId: 'F-PR-4', sourceId: 'S-26-PRICE-JD', metricKey: 'food.reason', label: '官方：食品价格下拉', section: '「一、CPI环比由降转涨，同比温和回升」',
    locator: { kind: 'text', exact: '食品价格下降1.4%，降幅比上月收窄0.1个百分点，影响CPI同比下降约0.24个百分点。' },
    excerpt: '食品价格下降1.4%，降幅比上月收窄0.1个百分点，影响CPI同比下降约0.24个百分点。食品中，猪肉价格下降11.8%……', mark: '影响CPI同比下降约0.24个百分点', searchText: '猪肉价格下降11.8%' }),
  r({ id: 'R-PR-PPI-WHY', factId: 'F-PR-4', sourceId: 'S-26-PRICE-JD', metricKey: 'ppi.reason', label: '官方：PPI 上涨原因', section: '解读稿导语段',
    locator: { kind: 'text', exact: '受国际大宗商品价格上行传导、国内产业转型升级带动部分行业需求增加等因素影响' },
    excerpt: '受国际大宗商品价格上行传导、国内产业转型升级带动部分行业需求增加等因素影响，工业生产者出厂价格指数（PPI）环比由上月下降0.7%转为上涨0.4%，同比涨幅扩大至3.8%。', mark: '受国际大宗商品价格上行传导', searchText: '受国际大宗商品价格上行传导' }),

  r({ id: 'R-MC-IND', factId: 'F-MC-1', sourceId: 'S-26-IND', metricKey: 'industrial_output.yoy', label: '工业增加值同比', section: '正文第 1 段',
    locator: { kind: 'text', exact: '8月份，规模以上工业增加值同比实际增长5.2%' },
    excerpt: '8月份，规模以上工业增加值同比实际增长5.2%（增加值增速均为扣除价格因素的实际增长率），增速比上月加快0.7个百分点。', mark: '同比实际增长5.2%', searchText: '规模以上工业增加值同比实际增长', link: loc('规模以上工业增加值同比实际增长') }),
  r({ id: 'R-MC-RET', factId: 'F-MC-2', sourceId: 'S-26-RETAIL', metricKey: 'retail.aug.yoy', label: '社零同比（8 月）', section: '正文第 2 段',
    locator: { kind: 'text', exact: '8月份，社会消费品零售总额39824亿元，同比增长0.4%。' },
    excerpt: '8月份，社会消费品零售总额39824亿元，同比增长0.4%。其中，除汽车以外的消费品零售额36545亿元，增长2.5%。', mark: '同比增长0.4%', searchText: '社会消费品零售总额39824亿元', link: loc('社会消费品零售总额39824亿元') }),
  r({ id: 'R-MC-AUTO', factId: 'F-MC-2', sourceId: 'S-26-RETAIL', metricKey: 'retail.auto.reason', label: '汽车类零售额（数据表）', section: '2026年8月份社会消费品零售总额主要数据（表）',
    locator: { kind: 'table', table: '2026年8月份社会消费品零售总额主要数据', row: '汽车类', column: '8月 同比增长（%）', unit: '%，名义增速' },
    excerpt: '汽车类　8月 3279亿元　同比 -18.5　1—8月 25805亿元　同比 -13.9', mark: '同比 -18.5', translation: '表中增速均为未扣除价格因素的名义增速；此行为限额以上单位口径。', searchText: '汽车类' }),
  r({ id: 'R-MC-FAI', factId: 'F-MC-3', sourceId: 'S-26-FAI', metricKey: 'fai.ytd.yoy', label: '固定资产投资同比（1—8 月）', section: '正文第 1 段',
    locator: { kind: 'text', exact: '1—8月份，全国固定资产投资（不含农户）293092亿元，同比下降7.2%' },
    excerpt: '1—8月份，全国固定资产投资（不含农户）293092亿元，同比下降7.2%（按可比口径计算，详见附注7）。其中，知识产权产品投资同比增长9.2%。', mark: '同比下降7.2%', searchText: '全国固定资产投资（不含农户）', link: loc('全国固定资产投资（不含农户）') }),
  r({ id: 'R-MC-FAI-WHY', factId: 'F-MC-4', sourceId: 'S-26-QA', metricKey: 'fai.reason', label: '发言人：投资下降原因', section: '南华早报记者提问的回答',
    locator: { kind: 'text', exact: '一方面，夏季高温、台风、洪涝等极端天气频发，给部分地区的项目施工造成了不利影响' },
    excerpt: '一方面，夏季高温、台风、洪涝等极端天气频发，给部分地区的项目施工造成了不利影响；另一方面，外部环境复杂多变，不确定、难预料因素增多，国内仍处在新旧动能接续转换的过程中，企业投资决策较为谨慎。', mark: '企业投资决策较为谨慎', searchText: '企业投资决策较为谨慎' }),

  r({ id: 'R-RE-SALES', factId: 'F-RE-1', sourceId: 'S-26-RE', metricKey: 'new_home_sales.ytd.yoy', label: '新建商品房销售面积同比', section: '「二、商品房销售和待售情况」',
    locator: { kind: 'text', exact: '1—8月份，新建商品房销售面积49880万平方米，同比下降12.1%' },
    excerpt: '1—8月份，新建商品房销售面积49880万平方米，同比下降12.1%；其中住宅销售面积下降13.0%。', mark: '同比下降12.1%', searchText: '新建商品房销售面积49880万平方米', link: loc('新建商品房销售面积49880万平方米') }),
  r({ id: 'R-RE-2ND', factId: 'F-RE-2', sourceId: 'S-26-RE', metricKey: 'resale_contracts.ytd.yoy', label: '二手房网签面积同比', section: '「二、商品房销售和待售情况」',
    locator: { kind: 'text', exact: '根据住房城乡建设部数据，1—8月份，二手房交易网签面积（见附注6）54923万平方米，同比增长10.6%。' },
    excerpt: '根据住房城乡建设部数据，1—8月份，二手房交易网签面积（见附注6）54923万平方米，同比增长10.6%。', mark: '同比增长10.6%', translation: '这是统计局发布稿转引的住建部网签数据，口径与统计局的新房销售不同。', searchText: '二手房交易网签面积', link: loc('二手房交易网签面积') }),
  r({ id: 'R-RE-INV', factId: 'F-RE-3', sourceId: 'S-26-RE', metricKey: 're_investment.ytd.yoy', label: '房地产开发投资同比', section: '「一、房地产开发投资完成情况」',
    locator: { kind: 'text', exact: '1—8月份，全国房地产开发投资47979亿元，同比下降19.9%' },
    excerpt: '1—8月份，全国房地产开发投资47979亿元，同比下降19.9%（按可比口径计算，详见附注5）；其中，住宅投资37017亿元，下降19.7%。', mark: '同比下降19.9%', searchText: '全国房地产开发投资47979亿元', link: loc('全国房地产开发投资47979亿元') }),
  r({ id: 'R-RE-WHY', factId: 'F-RE-4', sourceId: 'S-26-QA', metricKey: 'resale.reason', label: '发言人：交易结构变化', section: 'CNBC 记者提问的回答',
    locator: { kind: 'text', exact: '过去以新房交易居多正逐步转向以存量房交易居多，这是一个重要变化。' },
    excerpt: '……市场交易格局正在发生深刻调整，过去以新房交易居多正逐步转向以存量房交易居多，这是一个重要变化。', mark: '逐步转向以存量房交易居多', searchText: '过去以新房交易居多' }),

  r({ id: 'R-PM-M', factId: 'F-PM-1', sourceId: 'S-26-PMI', metricKey: 'pmi.level', label: '制造业 PMI', section: '「一、中国制造业采购经理指数运行情况」第 1 段',
    locator: { kind: 'text', exact: '8月份，制造业采购经理指数（PMI）为49.8%，比上月上升0.6个百分点，景气水平回升。' },
    excerpt: '8月份，制造业采购经理指数（PMI）为49.8%，比上月上升0.6个百分点，景气水平回升。', mark: '为49.8%', searchText: '制造业采购经理指数（PMI）为49.8%', link: opened('制造业采购经理指数（PMI）为49.8%') }),
  r({ id: 'R-PM-NO', factId: 'F-PM-2', sourceId: 'S-26-PMI', metricKey: 'pmi.new_orders', label: '新订单指数', section: '分类指数段',
    locator: { kind: 'text', exact: '新订单指数为50.6%，比上月上升2.1个百分点，表明制造业市场需求明显改善。' },
    excerpt: '新订单指数为50.6%，比上月上升2.1个百分点，表明制造业市场需求明显改善。', mark: '新订单指数为50.6%', searchText: '新订单指数为50.6%', link: opened('新订单指数为50.6%') }),
  r({ id: 'R-PM-SMALL', factId: 'F-PM-3', sourceId: 'S-26-PMI', metricKey: 'pmi.small', label: '小型企业 PMI', section: '「从企业规模看」一段',
    locator: { kind: 'text', exact: '小型企业PMI为47.9%，比上月上升0.5个百分点，低于临界点。' },
    excerpt: '……小型企业PMI为47.9%，比上月上升0.5个百分点，低于临界点。', mark: '小型企业PMI为47.9%', searchText: '小型企业PMI为47.9%', link: opened('小型企业PMI为47.9%') }),
  r({ id: 'R-PM-PRICE', factId: 'F-PM-4', sourceId: 'S-26-PMI-JD', metricKey: 'pmi.price.reason', label: '官方：价格指数回升', section: '「（三）价格指数双双回升」',
    locator: { kind: 'text', exact: '受近期原油、有色金属价格上行等因素影响' },
    excerpt: '受近期原油、有色金属价格上行等因素影响，制造业主要原材料购进价格指数和出厂价格指数分别为56.6%和50.4%，比上月上升3.4个和2.6个百分点，其中出厂价格指数重返扩张区间。', mark: '56.6%和50.4%', searchText: '受近期原油、有色金属价格上行' }),
];

// ---------------- 指标与差异卡 ----------------
export const METRICS_2026: InsightMetric[] = [
  { id: 'M-PF-YTD', eventId: 'profit-2608', factId: 'F-PF-1', evidenceRefIds: ['R-PF-YTD'], label: '利润（1—8 月）', display: '+15.7%', value: 15.7, period: '2026 年 1—8 月', unit: '%', basis: '累计同比', scope: '今年以来的累计利润，包含前几个月的高增长；按可比口径计算。' },
  { id: 'M-PF-AUG', eventId: 'profit-2608', factId: 'F-PF-2', evidenceRefIds: ['R-PF-AUG', 'R-PF-AUG-WHY'], label: '利润（8 月）', display: '+4.2%', value: 4.2, period: '2026 年 8 月', unit: '%', basis: '当月同比', scope: '只看 8 月一个月，受去年同月基数影响更直接。',
    notes: [{ kind: 'company', text: '官方解释：受去年同期较高基数影响增速回落；同月毛利润增长 7.5%，比上月加快 1.9 个百分点。', refId: 'R-PF-AUG-WHY' }] },
  { id: 'M-PF-REV', eventId: 'profit-2608', factId: 'F-PF-3', evidenceRefIds: ['R-PF-REV'], label: '营业收入（1—8 月）', display: '+6.6%', value: 6.6, period: '2026 年 1—8 月', unit: '%', basis: '累计同比', scope: '收入增速低于利润增速，差距来自利润率提高（5.66%，同比 +0.44 个百分点）。',
    notes: [{ kind: 'company', text: '官方解释：电子行业利润增长 1.1 倍，对利润增长的贡献率达 62.0%。', refId: 'R-PF-ELEC' }] },

  { id: 'M-PR-PPI', eventId: 'price-2608', factId: 'F-PR-1', evidenceRefIds: ['R-PR-PPI'], label: 'PPI', display: '+3.8%', value: 3.8, period: '2026 年 8 月', unit: '%', basis: '同比', scope: '工业生产者出厂价格，反映上游工业品价格；不直接等于居民买东西的价格。',
    notes: [{ kind: 'company', text: '官方解释：受国际大宗商品价格上行传导、部分行业需求增加等因素影响。', refId: 'R-PR-PPI-WHY' }] },
  { id: 'M-PR-CPI', eventId: 'price-2608', factId: 'F-PR-2', evidenceRefIds: ['R-PR-CPI'], label: 'CPI', display: '+0.8%', value: 0.8, period: '2026 年 8 月', unit: '%', basis: '同比', scope: '居民消费价格；食品占比较高，食品价格同比下降 1.4%。',
    notes: [
      { kind: 'company', text: '官方解释：同比涨幅扩大主要受能源价格涨幅扩大影响。', refId: 'R-PR-CPI-WHY' },
      { kind: 'company', text: '官方数据：食品价格下降 1.4%，其中猪肉下降 11.8%，影响 CPI 同比下降约 0.24 个百分点。', refId: 'R-PR-FOOD' },
    ] },
  { id: 'M-PR-CORE', eventId: 'price-2608', factId: 'F-PR-3', evidenceRefIds: ['R-PR-CORE-JD', 'R-PR-CORE-T'], label: '核心 CPI', display: '+1.0%', value: 1.0, period: '2026 年 8 月', unit: '%', basis: '同比，剔除食品和能源', scope: '剔除波动大的食品和能源后的价格；它不是「更真实的 CPI」，只回答另一个问题。' },

  { id: 'M-MC-IND', eventId: 'macro-2608', factId: 'F-MC-1', evidenceRefIds: ['R-MC-IND'], label: '工业增加值', display: '+5.2%', value: 5.2, period: '2026 年 8 月', unit: '%', basis: '当月同比，实际增速', scope: '衡量生产，扣除了价格因素；8 月当月。' },
  { id: 'M-MC-RET', eventId: 'macro-2608', factId: 'F-MC-2', evidenceRefIds: ['R-MC-RET', 'R-MC-AUTO'], label: '社会消费品零售总额', display: '+0.4%', value: 0.4, period: '2026 年 8 月', unit: '%', basis: '当月同比，名义增速', scope: '衡量商品零售和餐饮；除汽车外增长 2.5%，汽车类下降 18.5%。',
    notes: [{ kind: 'editor', text: '名义增速没有扣除价格，和实际增速的工业增加值不能直接比大小。' }] },
  { id: 'M-MC-FAI', eventId: 'macro-2608', factId: 'F-MC-3', evidenceRefIds: ['R-MC-FAI'], label: '固定资产投资', display: '−7.2%', value: -7.2, period: '2026 年 1—8 月', unit: '%', basis: '累计同比，名义增速', scope: '1—8 月累计；房地产开发投资下降 19.9%，扣除房地产开发后下降 4.2%。',
    notes: [{ kind: 'company', text: '发言人解释：极端天气影响施工，企业投资决策较为谨慎。', refId: 'R-MC-FAI-WHY' }] },

  { id: 'M-RE-NEW', eventId: 'realestate-2608', factId: 'F-RE-1', evidenceRefIds: ['R-RE-SALES'], label: '新房销售面积', display: '−12.1%', value: -12.1, period: '2026 年 1—8 月', unit: '%', basis: '累计同比', scope: '新建商品房（开发商卖出的新房），统计局口径。' },
  { id: 'M-RE-2ND', eventId: 'realestate-2608', factId: 'F-RE-2', evidenceRefIds: ['R-RE-2ND'], label: '二手房网签面积', display: '+10.6%', value: 10.6, period: '2026 年 1—8 月', unit: '%', basis: '累计同比', scope: '住建部网签口径，由统计局转引；只说明成交面积，不说明价格。',
    notes: [{ kind: 'company', text: '发言人解释：交易格局正从以新房为主转向以存量房为主。', refId: 'R-RE-WHY' }] },
  { id: 'M-RE-INV', eventId: 'realestate-2608', factId: 'F-RE-3', evidenceRefIds: ['R-RE-INV'], label: '房地产开发投资', display: '−19.9%', value: -19.9, period: '2026 年 1—8 月', unit: '%', basis: '累计同比', scope: '开发商的建设投资，按可比口径计算；不等于房价。' },

  { id: 'M-PM-M', eventId: 'pmi-2608', factId: 'F-PM-1', evidenceRefIds: ['R-PM-M'], label: '制造业 PMI', display: '49.8', value: 49.8, period: '2026 年 8 月', unit: '%', basis: '扩散指数，50 为荣枯线', scope: '回答「本月比上月好」的企业多于「差」的时，指数高于 50。' },
  { id: 'M-PM-NO', eventId: 'pmi-2608', factId: 'F-PM-2', evidenceRefIds: ['R-PM-NO'], label: '新订单指数', display: '50.6', value: 50.6, period: '2026 年 8 月', unit: '%', basis: '扩散指数', scope: '反映订单需求的方向；比上月上升 2.1 个百分点。' },
  { id: 'M-PM-SM', eventId: 'pmi-2608', factId: 'F-PM-3', evidenceRefIds: ['R-PM-SMALL'], label: '小型企业 PMI', display: '47.9', value: 47.9, period: '2026 年 8 月', unit: '%', basis: '扩散指数', scope: '同月大型企业为 50.6，企业规模之间分化明显。' },
];

export const INSIGHTS_2026: DifferenceInsight[] = [
  { id: 'DI-PF-1', eventId: 'profit-2608', version: 'v1', question: '利润增长 15.7%，为什么 8 月只增长 4.2%？', metricIds: ['M-PF-YTD', 'M-PF-AUG', 'M-PF-REV'], interpIds: ['I-PF-1'],
    boundary: '这期材料还不足以判断：8 月的放缓只是基数原因，还是利润增速开始转弱。', openQuestion: '9 月单月利润增速能否回升？', nextCheck: '10 月下旬发布的 1—9 月工业企业利润数据', factIds: ['F-PF-1', 'F-PF-2', 'F-PF-3'] },
  { id: 'DI-PR-1', eventId: 'price-2608', version: 'v1', question: '上游涨 3.8%，消费端只涨 0.8%？', metricIds: ['M-PR-PPI', 'M-PR-CPI', 'M-PR-CORE'], interpIds: ['I-PR-1'],
    boundary: '这期材料还不足以判断：上游涨价会传导多少到消费端、需要多久。', openQuestion: '下月 PPI 与 CPI 的差距会不会缩小？', nextCheck: '10 月中旬发布的 9 月 CPI 与 PPI', factIds: ['F-PR-1', 'F-PR-2', 'F-PR-3', 'F-PR-4'] },
  { id: 'DI-MC-1', eventId: 'macro-2608', version: 'v1', question: '生产加快、消费放缓、投资下降，怎么同时成立？', metricIds: ['M-MC-IND', 'M-MC-RET', 'M-MC-FAI'], interpIds: ['I-MC-1'],
    boundary: '这期材料还不足以判断：投资何时止跌，汽车消费的下滑会持续多久。', openQuestion: '9 月投资与汽车类消费会不会改善？', nextCheck: '10 月中旬发布的 9 月及前三季度国民经济数据', factIds: ['F-MC-1', 'F-MC-2', 'F-MC-3'] },
  { id: 'DI-RE-1', eventId: 'realestate-2608', version: 'v1', question: '新房卖得少了，二手房成交却在增加？', metricIds: ['M-RE-NEW', 'M-RE-2ND', 'M-RE-INV'], interpIds: ['I-RE-1'],
    boundary: '这期材料还不足以判断：新房加二手房的交易总量是否已经企稳。', openQuestion: '二手房成交增长能否带动价格降幅继续收窄？', nextCheck: '10 月中旬发布的 1—9 月房地产数据与 70 城房价', factIds: ['F-RE-1', 'F-RE-2', 'F-RE-3'] },
  { id: 'DI-PM-1', eventId: 'pmi-2608', version: 'v1', question: 'PMI 回升了，为什么还在收缩区间？', metricIds: ['M-PM-M', 'M-PM-NO', 'M-PM-SM'], interpIds: ['I-PM-1'],
    boundary: '这期材料还不足以判断：新订单回升能否延续到下个月，并带动小企业景气改善。', openQuestion: '9 月 PMI 能否回到 50% 以上？', nextCheck: '9 月 30 日发布的 9 月 PMI', factIds: ['F-PM-1', 'F-PM-2', 'F-PM-3'] },
];

const row = (id: string, label?: string): FigureRow => {
  const m = METRICS_2026.find((x) => x.id === id);
  if (!m) throw new Error('图表引用了不存在的指标：' + id);
  return { label: label ?? m.label, value: m.value, display: m.display, metricId: m.id };
};

// ---------------- 事件 ----------------
export const EVENTS_2026: EventItem[] = [
  {
    id: 'profit-2608', kind: 'real', topic: '宏观数据', type: '统计数据',
    title: '1—8 月工业企业利润增长 15.7%，8 月单月增长 4.2%',
    question: '利润增长 15.7%，为什么 8 月只增长 4.2%？',
    answer: '15.7% 是 1—8 月累计，8 月单月只有 4.2%，统计局解释为去年同期基数较高；利润增长高度集中在电子行业，汽车、电力、钢铁利润在下降。',
    sourceDate: '2026-09-28', sourceLabel: '国家统计局 · 数据发布与解读', interpUpdatedAt: '2026-09-28', newFacts: '电子行业贡献了约六成利润增量', readMins: 2,
    summary: {
      fact: { text: '2026 年 1—8 月规模以上工业企业利润同比增长 15.7%，8 月单月增长 4.2%。', factId: 'F-PF-1' },
      points: [
        { text: '利润增长高度集中：电子行业利润增长 1.1 倍，贡献约六成；汽车制造业利润下降 16.0%，黑色金属冶炼下降 62.4%。', interpId: 'I-PF-2' },
        { text: '单位成本在下降：每百元营业收入中的成本为 85.07 元，同比减少 0.41 元。', factId: 'F-PF-3' },
      ],
      unknown: '8 月放缓是基数原因还是趋势转弱，要看下个月数据。',
    },
    figure: {
      kind: 'bars', title: '1—8 月分行业利润同比（节选）', unit: '%', note: '2026 年 1—8 月 · 国家统计局', factIds: ['F-PF-4'],
      rows: [
        { label: '电子行业', value: 110, display: '+110%' },
        { label: '有色金属冶炼', value: 82.9, display: '+82.9%' },
        { label: '化学原料和制品', value: 51.0, display: '+51.0%' },
        { label: '汽车制造', value: -16.0, display: '−16.0%' },
        { label: '黑色金属冶炼', value: -62.4, display: '−62.4%' },
      ],
    },
    path: [
      { id: 'n1', stage: '事件', base: { title: '统计局发布 1—8 月工业企业利润', tone: 'supported' }, basisFactIds: ['F-PF-1', 'F-PF-2'], why: '官方统计发布。', breaksIf: '数据修订。' },
      { id: 'n2', stage: '经营变量', base: { title: '工业品价格上涨、电子行业需求扩大', tone: 'supported', note: '统计局解读给出的原因' }, basisFactIds: ['F-PF-4'], why: '解读称营业收入增长与工业品价格涨幅扩大共同推动利润增长。', breaksIf: '价格或需求回落。', interpId: 'I-PF-2' },
      { id: 'n3', stage: '财务表现', base: { title: '利润率提高，但行业间分化大', tone: 'supported', note: '营业收入利润率 5.66%，同比 +0.44 个百分点' }, basisFactIds: ['F-PF-3', 'F-PF-4'], why: '利润增速高于收入增速。', breaksIf: '成本上升快于售价。', interpId: 'I-PF-1' },
      { id: 'n4', stage: '待观察', base: { title: '9 月单月利润增速能否回升', tone: 'watch' }, basisFactIds: ['F-PF-2'], why: '一个月的回落不足以判断趋势。', breaksIf: '—' },
    ],
    qa: [
      { id: 'q1', q: '8 月利润为什么增长变慢？', aliases: ['利润为什么放缓', '8月利润为什么只增长4.2%'], a: '统计局解读称，8 月受去年同期较高基数影响，利润增速有所回落，同比增长 4.2%；同月毛利润增长 7.5%，比上月加快 1.9 个百分点。', factIds: ['F-PF-2'], interpIds: ['I-PF-1'] },
      { id: 'q2', q: '哪些行业利润增长最快？', aliases: ['哪个行业利润最好', '电子行业利润'], a: '1—8 月电子行业利润增长 1.1 倍，对全部利润增长的贡献率达 62.0%；有色金属冶炼增长 82.9%，化学原料和化学制品增长 51.0%。', factIds: ['F-PF-4'], interpIds: ['I-PF-2'] },
    ],
    terms: [
      { term: '基数效应', aliases: ['高基数', '基数'], text: '同比增速是和去年同期比。如果去年同月数字特别高，今年即使绝对值不差，同比增速也会显得低。', factIds: ['F-PF-2'] },
      { term: '营业收入利润率', aliases: ['利润率'], text: '利润总额占营业收入的比例。它上升，意味着同样的收入里留下的利润更多。', factIds: ['F-PF-3'] },
    ],
    watchSuggestions: ['10 月下旬发布的 1—9 月工业企业利润数据', '电子行业以外的行业利润能否改善'],
    deepNotes: ['累计增速与当月增速不能直接比较；本页把两者并列，是为了说明它们回答的问题不同。', '「增长 1.1 倍」即增长约 110%，图中按 110% 画出。'],
    signals: { scope: 'macro', magnitude: [4, '累计 +15.7% 与当月 +4.2% 明显背离'], policy: [2, '影响对企业盈利的判断，不直接触发政策'], heat: 76 },
    related: ['price-2608', 'macro-2608'],
  },
  {
    id: 'price-2608', kind: 'real', topic: '宏观数据', type: '统计数据',
    title: '8 月 PPI 同比上涨 3.8%，CPI 同比上涨 0.8%',
    question: '上游涨 3.8%，消费端只涨 0.8%？',
    answer: 'PPI 是工业品出厂价，受国际能源、有色金属价格推动；CPI 里食品价格在降（猪肉 −11.8%），抵消了能源上涨——两个数字衡量的环节不同，可以同时成立。',
    sourceDate: '2026-09-09', sourceLabel: '国家统计局 · 数据发布与解读', interpUpdatedAt: '2026-09-28', newFacts: 'PPI 同比涨幅扩大至 3.8%', readMins: 2,
    summary: {
      fact: { text: '2026 年 8 月 PPI 同比上涨 3.8%，CPI 同比上涨 0.8%，核心 CPI 上涨 1.0%。', factId: 'F-PR-1' },
      points: [
        { text: '统计局解读：CPI 同比涨幅扩大主要来自能源，汽油价格上涨 9.3%；食品价格下降 1.4%，猪肉下降 11.8%。', factId: 'F-PR-4' },
        { text: '工业生产者购进价格同比上涨 5.8%，高于出厂价格的 3.8%，中下游企业的成本压力更大。', factId: 'F-PR-1' },
      ],
      unknown: '上游涨价会传导多少到消费端、需要多久，本期材料不能回答。',
    },
    figure: { kind: 'dots', title: '同一个月，四个价格读数', unit: '%', note: '2026 年 8 月 · 国家统计局', factIds: ['F-PR-1', 'F-PR-2', 'F-PR-3'], min: -1, max: 6.5,
      rows: [row('M-PR-PPI', 'PPI 同比'), { label: '购进价格同比', value: 5.8, display: '+5.8%' }, row('M-PR-CPI', 'CPI 同比'), row('M-PR-CORE', '核心 CPI 同比')] },
    path: [
      { id: 'n1', stage: '事件', base: { title: '统计局发布 8 月 CPI 与 PPI', tone: 'supported' }, basisFactIds: ['F-PR-1', 'F-PR-2'], why: '官方统计发布。', breaksIf: '数据修订。' },
      { id: 'n2', stage: '经营变量', base: { title: '国际能源、有色金属价格上行推高上游价格', tone: 'supported', note: '统计局解读' }, basisFactIds: ['F-PR-4'], why: '解读称 PPI 上涨受国际大宗商品价格上行传导。', breaksIf: '国际大宗商品价格回落。', interpId: 'I-PR-1' },
      { id: 'n3', stage: '财务表现', base: { title: '中下游企业成本压力取决于能否提价', tone: 'conditional', note: '条件：下游需求能否承接涨价' }, basisFactIds: ['F-PR-1'], why: '购进价格涨幅（5.8%）高于出厂价格（3.8%）。', breaksIf: '企业能把成本顺利转嫁给下游。' },
      { id: 'n4', stage: '待观察', base: { title: '9 月 PPI 与 CPI 的差距是否缩小', tone: 'watch' }, basisFactIds: ['F-PR-1', 'F-PR-2'], why: '看传导是否发生。', breaksIf: '—' },
    ],
    qa: [
      { id: 'q1', q: 'CPI 为什么涨了？', aliases: ['物价为什么上涨', 'CPI上涨原因'], a: '统计局解读称，8 月 CPI 同比涨幅扩大主要受能源价格涨幅扩大影响：能源价格上涨 4.1%，其中汽油上涨 9.3%。食品价格仍在下降，拉低了 CPI。', factIds: ['F-PR-4'], interpIds: ['I-PR-1'] },
      { id: 'q2', q: '猪肉价格怎么样？', aliases: ['猪肉价格', '食品价格怎么样'], a: '8 月猪肉价格同比下降 11.8%，降幅比上月收窄 1.5 个百分点；食品价格整体下降 1.4%，影响 CPI 同比下降约 0.24 个百分点。', factIds: ['F-PR-4'], interpIds: [] },
    ],
    terms: [
      { term: 'PPI', aliases: ['工业生产者出厂价格'], text: '工业企业产品出厂时的价格指数，反映上游工业品价格的变化。', factIds: ['F-PR-1'] },
      { term: '购进价格', aliases: ['工业生产者购进价格'], text: '工业企业买入原材料、燃料等的价格。它比出厂价格涨得快时，企业的成本压力更大。', factIds: ['F-PR-1'] },
    ],
    watchSuggestions: ['10 月中旬发布的 9 月 CPI 与 PPI', '国际原油与有色金属价格走势'],
    deepNotes: ['PPI 与 CPI 覆盖的商品范围和权重不同，两者的差距不能直接理解为「企业利润被挤压的幅度」。'],
    signals: { scope: 'macro', magnitude: [4, 'PPI 与 CPI 差距拉大到 3 个百分点'], policy: [4, '价格走势影响货币政策预期'], heat: 82 },
    related: ['cpi-2508', 'profit-2608', 'pmi-2608'],
  },
  {
    id: 'fomc-2609', kind: 'real', topic: '海外官方', type: '央行声明',
    title: '美联储加息 25 个基点至 3.75%–4.00%，投票 12 比 0',
    question: '美联储加息，是因为经济过热吗？',
    answer: '声明给出的理由是「通胀仍然偏高」，希望更及时回到 2% 目标；同时说经济稳健扩张、就业稳定——这是在经济不弱时优先压通胀，并没有说经济过热。',
    sourceDate: '2026-09-16（美东）', sourceLabel: '美联储官网 · 英文原文', interpUpdatedAt: '2026-09-28', newFacts: '7 月三票主张加息，9 月变为全票', readMins: 2,
    summary: {
      fact: { text: 'FOMC 以 12 比 0 将联邦基金利率目标区间上调 25 个基点至 3.75%–4.00%。', factId: 'F-FD-1' },
      points: [
        { text: '声明的理由是通胀仍然偏高，此次行动有助于更及时回到 2% 目标；声明同时写到经济稳健扩张、失业率变化不大。', interpId: 'I-FD-1' },
        { text: '上次会议（7 月）维持利率不变，但已有三名委员投反对票，主张当时就加息。', factId: 'F-FD-3' },
      ],
      unknown: '之后是否继续加息，声明没有给出承诺。',
    },
    figure: { kind: 'range', title: '联邦基金利率目标区间', note: '美联储声明原文 · 2026 年 7 月与 9 月会议', factIds: ['F-FD-1', 'F-FD-3'],
      steps: [{ label: '2026-07', lo: 3.5, hi: 3.75 }, { label: '2026-09', lo: 3.75, hi: 4.0 }] },
    path: [
      { id: 'n1', stage: '事件', base: { title: '目标区间上调至 3.75%–4.00%', tone: 'supported' }, basisFactIds: ['F-FD-1'], why: '声明原文直接写明。', breaksIf: '声明更正（未见）。' },
      { id: 'n2', stage: '经营变量', base: { title: '美元短端融资成本上升', tone: 'conditional', note: '条件：市场利率跟随政策利率' }, basisFactIds: ['F-FD-1'], why: '联邦基金利率是美元短端利率的锚。', breaksIf: '市场已提前定价。', interpId: 'I-FD-1' },
      { id: 'n3', stage: '财务表现', base: { title: '对企业的影响取决于美元债务结构', tone: 'undetermined' }, basisFactIds: [], why: '浮动利率或近期需要再融资的美元债务受影响更快。', breaksIf: '以固定利率长债为主的企业受影响小。' },
      { id: 'n4', stage: '待观察', base: { title: '下一次声明是否仍写「通胀仍然偏高」', tone: 'watch' }, basisFactIds: ['F-FD-2'], why: '措辞变化比单次动作更能说明判断是否改变。', breaksIf: '—' },
    ],
    translations: [
      { original: 'Inflation remains elevated.', faithful: '通胀仍然偏高。', inflated: '通胀失控，美联储被迫紧急加息。', why: '「elevated」是「偏高」，声明没有「失控」「紧急」的意思；本次是常规议息会议。', factId: 'F-FD-2' },
      { original: 'Economic activity is expanding at a solid pace.', faithful: '经济活动稳健扩张。', inflated: '美国经济过热。', why: '「solid」是「稳健」，没有「过热」的判断。', factId: 'F-FD-2' },
    ],
    qa: [
      { id: 'q1', q: '为什么是全票通过？', aliases: ['投票结果', '有没有反对票'], a: '9 月声明投票 12 比 0，没有反对票。7 月会议维持利率时有三名委员反对，他们当时就主张加息 25 个基点。声明没有说明内部讨论细节。', factIds: ['F-FD-1', 'F-FD-3'], interpIds: [] },
      { id: 'q2', q: '北京时间什么时候公布的？', aliases: ['几点公布', '北京时间几点'], a: '声明于美国东部夏令时间 2026-09-16 下午 2:00 发布，对应北京时间 2026-09-17 凌晨 2:00。', factIds: ['F-FD-1'], interpIds: [] },
    ],
    timeNote: '以下观察项按 2026 年 9 月声明发布时的信息写成。',
    watchSuggestions: ['下一次 FOMC 声明中「通胀仍然偏高」的措辞是否变化', '美国后续通胀数据'],
    deepNotes: ['本页只用声明原文；会后发布会和经济预测摘要（SEP）没有纳入。'],
    signals: { scope: 'global', magnitude: [5, '从维持利率转为加息，且全票通过'], policy: [5, '直接的货币政策动作'], heat: 88 },
    related: ['fomc-2509', 'price-2608'],
  },
  {
    id: 'macro-2608', kind: 'real', topic: '宏观数据', type: '统计数据',
    title: '8 月工业增加值增长 5.2%，社零增长 0.4%，1—8 月投资下降 7.2%',
    question: '生产加快、消费放缓、投资下降，怎么同时成立？',
    answer: '三个数字衡量生产、消费、投资三个不同环节，期间和口径也不同；消费偏弱主要来自汽车（−18.5%），投资下降中房地产开发拖累最大。',
    sourceDate: '2026-09-15', sourceLabel: '国家统计局 · 数据发布与发布会', interpUpdatedAt: '2026-09-28', newFacts: '高技术制造业增加值增长 16.7%', readMins: 3,
    summary: {
      fact: { text: '8 月工业增加值同比增长 5.2%，社会消费品零售总额增长 0.4%；1—8 月固定资产投资下降 7.2%。', factId: 'F-MC-1' },
      points: [
        { text: '统计局发言人把投资下降归因于极端天气影响施工、企业投资决策谨慎；同期知识产权产品投资增长 9.2%。', factId: 'F-MC-4' },
        { text: '除汽车以外的消费品零售额增长 2.5%，汽车类下降 18.5%，是社零偏弱的主要原因。', factId: 'F-MC-2' },
      ],
      unknown: '投资何时止跌，本期材料无法判断。',
    },
    figure: { kind: 'bars', title: '生产、消费、投资：三个读数', unit: '%', note: '工业、社零为 8 月当月；投资为 1—8 月累计', factIds: ['F-MC-1', 'F-MC-2', 'F-MC-3'],
      rows: [row('M-MC-IND', '工业增加值（8 月）'), row('M-MC-RET', '社零（8 月）'), row('M-MC-FAI', '固定资产投资（1—8 月）')] },
    path: [
      { id: 'n1', stage: '事件', base: { title: '统计局发布 8 月国民经济数据', tone: 'supported' }, basisFactIds: ['F-MC-1', 'F-MC-2', 'F-MC-3'], why: '官方统计发布。', breaksIf: '数据修订。' },
      { id: 'n2', stage: '经营变量', base: { title: '高技术制造与出口带动生产', tone: 'supported', note: '高技术制造业增加值 +16.7%' }, basisFactIds: ['F-MC-1'], why: '统计局发布的分行业数据。', breaksIf: '外需回落。', interpId: 'I-MC-1' },
      { id: 'n3', stage: '财务表现', base: { title: '汽车与地产相关行业需求偏弱', tone: 'supported', note: '汽车类零售额 −18.5%，房地产开发投资 −19.9%' }, basisFactIds: ['F-MC-2', 'F-MC-3'], why: '分项数据。', breaksIf: '政策刺激见效。' },
      { id: 'n4', stage: '待观察', base: { title: '9 月投资与汽车消费能否改善', tone: 'watch' }, basisFactIds: ['F-MC-3'], why: '看弱项是否企稳。', breaksIf: '—' },
    ],
    qa: [
      { id: 'q1', q: '投资为什么下降？', aliases: ['固定资产投资下降原因', '投资为什么下降7.2%'], a: '统计局新闻发言人称，一方面夏季极端天气影响部分地区项目施工，另一方面外部环境复杂多变、企业投资决策较为谨慎。房地产开发投资下降 19.9%，扣除房地产开发后投资下降 4.2%。', factIds: ['F-MC-3', 'F-MC-4'], interpIds: ['I-MC-1'] },
      { id: 'q2', q: '消费为什么这么弱？', aliases: ['社零为什么只增长0.4%', '消费怎么样'], a: '8 月社会消费品零售总额增长 0.4%，其中汽车类零售额下降 18.5%；除汽车以外的消费品零售额增长 2.5%。', factIds: ['F-MC-2'], interpIds: ['I-MC-1'] },
    ],
    terms: [
      { term: '实际增速', aliases: ['名义增速'], text: '实际增速扣除了价格变化，名义增速没有扣除。工业增加值用实际增速，社零和投资用名义增速，两类数字不能直接比大小。', factIds: ['F-MC-1', 'F-MC-2'] },
      { term: '累计同比', aliases: ['当月同比'], text: '累计同比比较的是今年以来的总和，当月同比只比较这一个月。', factIds: ['F-MC-3'] },
    ],
    watchSuggestions: ['10 月中旬发布的前三季度国民经济数据', '汽车类消费与房地产开发投资'],
    deepNotes: ['工业增加值为实际增速，社零与投资为名义增速；当月与累计口径不同，图中已分别标注。'],
    signals: { scope: 'macro', magnitude: [4, '投资累计下降 7.2%，与生产加快背离'], policy: [4, '影响对稳增长政策力度的判断'], heat: 72 },
    related: ['profit-2608', 'realestate-2608'],
  },
  {
    id: 'realestate-2608', kind: 'real', topic: '房地产', type: '统计数据',
    title: '1—8 月新房销售面积下降 12.1%，二手房网签面积增长 10.6%',
    question: '新房卖得少了，二手房成交却在增加？',
    answer: '新房和二手房是两个市场：统计局认为交易正从新房转向存量房。但二手房成交面积增长不等于价格上涨——8 月一线城市二手住宅价格同比仍下降 2.7%。',
    sourceDate: '2026-09-15', sourceLabel: '国家统计局 · 数据发布与发布会', interpUpdatedAt: '2026-09-28', newFacts: '新建商品房待售面积连续 6 个月下降', readMins: 2,
    summary: {
      fact: { text: '1—8 月新建商品房销售面积同比下降 12.1%，二手房网签面积增长 10.6%（住建部数据），房地产开发投资下降 19.9%。', factId: 'F-RE-1' },
      points: [
        { text: '统计局发言人：市场交易正从以新房为主逐步转向以存量房为主。', factId: 'F-RE-4' },
        { text: '8 月末新建商品房待售面积同比下降 1.1%，库存小幅下降。', factId: 'F-RE-3' },
      ],
      unknown: '新房加二手房的交易总量是否已经企稳，需要更长时间观察。',
    },
    figure: { kind: 'bars', title: '1—8 月房地产主要读数', unit: '%', note: '二手房网签为住建部数据，由统计局转引', factIds: ['F-RE-1', 'F-RE-2', 'F-RE-3'],
      rows: [row('M-RE-NEW', '新房销售面积'), row('M-RE-2ND', '二手房网签面积'), row('M-RE-INV', '房地产开发投资')] },
    path: [
      { id: 'n1', stage: '事件', base: { title: '统计局发布 1—8 月房地产数据', tone: 'supported' }, basisFactIds: ['F-RE-1', 'F-RE-3'], why: '官方统计发布。', breaksIf: '数据修订。' },
      { id: 'n2', stage: '经营变量', base: { title: '交易从新房转向二手房', tone: 'supported', note: '统计局发言人的判断' }, basisFactIds: ['F-RE-2', 'F-RE-4'], why: '二手房网签面积增长、新房销售下降。', breaksIf: '二手房成交回落。', interpId: 'I-RE-1' },
      { id: 'n3', stage: '财务表现', base: { title: '开发商新开工与投资继续收缩', tone: 'supported', note: '开发投资 −19.9%' }, basisFactIds: ['F-RE-3'], why: '销售回款减少，开发投资下降。', breaksIf: '销售回升。' },
      { id: 'n4', stage: '待观察', base: { title: '价格降幅能否继续收窄', tone: 'watch' }, basisFactIds: ['F-RE-2'], why: '成交增长是否带动价格企稳。', breaksIf: '—' },
    ],
    qa: [
      { id: 'q1', q: '房价还在跌吗？', aliases: ['房价怎么样', '二手房价格'], a: '成交面积不含价格信息。统计局城市司解读显示，8 月一线城市二手住宅价格同比下降 2.7%，降幅比上月收窄 1.0 个百分点；二、三线城市分别下降 4.9% 和 5.6%。', factIds: ['F-RE-5'], interpIds: [] },
      { id: 'q2', q: '二手房数据是谁统计的？', aliases: ['二手房网签是什么', '网签数据来源'], a: '二手房交易网签面积是住房城乡建设部的数据，统计局在发布稿中转引，口径与统计局的新房销售不同。', factIds: ['F-RE-2'], interpIds: [] },
    ],
    terms: [
      { term: '网签', aliases: ['网签面积', '二手房网签'], text: '买卖双方在房管部门系统里签订合同备案。网签面积反映成交量，不包含价格信息。', factIds: ['F-RE-2'] },
    ],
    watchSuggestions: ['10 月中旬发布的 1—9 月房地产数据与 70 城房价', '二手房成交与价格是否同步改善'],
    deepNotes: ['房价数据来自统计局城市司解读稿（2026-09-15），本页只引用了一、二、三线城市的汇总数，没有逐城展开。'],
    signals: { scope: 'sector', magnitude: [3, '新房与二手房成交方向相反'], policy: [3, '关联房地产政策调整'], heat: 84 },
    related: ['macro-2608'],
  },
  {
    id: 'pmi-2608', kind: 'real', topic: '宏观数据', type: '统计数据',
    title: '8 月制造业 PMI 49.8%，比上月上升 0.6 个百分点',
    question: 'PMI 回升了，为什么还在收缩区间？',
    answer: 'PMI 以 50% 为分界：总指数 49.8% 仍低于 50%，但新订单（50.6%）和生产（50.4%）两个分项已回到扩张区间；大型企业在扩张，小型企业仍偏弱。',
    sourceDate: '2026-08-31', sourceLabel: '国家统计局 · 数据发布与解读', interpUpdatedAt: '2026-09-28', newFacts: '新订单指数上升 2.1 个百分点', readMins: 1,
    summary: {
      fact: { text: '8 月制造业 PMI 为 49.8%，比上月上升 0.6 个百分点；新订单指数 50.6%。', factId: 'F-PM-1' },
      points: [
        { text: '价格指数明显上升：原材料购进价格指数 56.6%，出厂价格指数 50.4%，统计局解读称受原油、有色金属价格上行影响。', factId: 'F-PM-4' },
      ],
      unknown: '新订单回升能否延续到下个月，本期材料无法判断。',
    },
    figure: { kind: 'dots', title: '8 月 PMI 分项（50 为荣枯线）', unit: '%', note: '2026 年 8 月 · 国家统计局', factIds: ['F-PM-1', 'F-PM-2', 'F-PM-3'], min: 46, max: 52, base: 50, baseLabel: '荣枯线',
      rows: [row('M-PM-M', '制造业 PMI'), row('M-PM-NO', '新订单指数'), row('M-PM-SM', '小型企业 PMI')] },
    path: [
      { id: 'n1', stage: '事件', base: { title: '统计局发布 8 月 PMI', tone: 'supported' }, basisFactIds: ['F-PM-1'], why: '官方统计发布。', breaksIf: '—' },
      { id: 'n2', stage: '经营变量', base: { title: '订单需求回升，原材料涨价', tone: 'supported' }, basisFactIds: ['F-PM-2', 'F-PM-4'], why: '新订单与价格分项上升。', breaksIf: '订单回落。', interpId: 'I-PM-1' },
      { id: 'n3', stage: '待观察', base: { title: '9 月 PMI 能否回到 50% 以上', tone: 'watch' }, basisFactIds: ['F-PM-1'], why: '单月回升需要延续才有意义。', breaksIf: '—' },
    ],
    qa: [
      { id: 'q1', q: 'PMI 低于 50 是什么意思？', aliases: ['荣枯线', 'PMI是什么'], a: 'PMI 是扩散指数：高于 50% 表示回答「比上月好」的企业多于「差」的，低于 50% 则相反。8 月为 49.8%，仍略低于分界线。', factIds: ['F-PM-1'], interpIds: ['I-PM-1'] },
    ],
    terms: [
      { term: '扩散指数', aliases: ['荣枯线', 'PMI'], text: '把企业「变好、不变、变差」的回答汇总成 0–100 的指数，50 是分界线。它反映方向和广度，不代表增长幅度。', factIds: ['F-PM-1'] },
    ],
    watchSuggestions: ['9 月 30 日发布的 9 月 PMI'],
    deepNotes: ['PMI 各项指数均经季节调整。'],
    signals: { scope: 'macro', magnitude: [2, '回升但仍低于 50'], policy: [2, '先行指标，影响对经济方向的判断'], heat: 58 },
    related: ['price-2608', 'profit-2608'],
  },
];
