import { metricRow } from './evidence';
import type { EventItem } from './types';
import { EVENTS_2026 } from './news2026';

/*
 * 事件内容。写作约束（来自 2026-09-24 审阅）：
 * - 先回答：answer 一句话，summary.points 两三句，unknown 一处「不能直接下结论」
 * - 影响路径、口径对照、原文对照、练习默认折叠，按需展开
 * - 历史案例的观察项按「当时」的信息写；后来的材料只写已核验过原文的（retro）
 */

const EVENTS_BASE: EventItem[] = [
  {
    id: 'baba-2506',
    kind: 'real',
    topic: '公司财报',
    type: '定期报告',
    title: '阿里巴巴 6 月季度：净利润增长 76%，经营现金流下降 39%',
    question: '净利润增长，为什么现金流反而下降？',
    answer: '净利润大涨主要来自投资市值变动和出售业务的收益；同一季度经营利润和经营现金流都在下降——三个数字衡量的不是同一件事。',
    sourceDate: '2025-08-29',
    sourceLabel: '公司公告 · SEC 6-K',
    interpUpdatedAt: '2026-09-24',
    newFacts: '自由现金流由上年同期流入转为流出 188 亿元',
    readMins: 2,
    summary: {
      fact: { text: '2025 年 4–6 月，净利润 423.82 亿元、同比 +76%；经营现金流 206.72 亿元、同比 −39%。', factId: 'F-BA-4' },
      points: [
        { text: '净利润增长主要来自股权投资的市值变动和出售 Trendyol 本地生活业务的收益，这类收益不代表经营变好。', interpId: 'I-BA-1' },
        { text: '经营利润同比 −3%；公司更常用的经调整 EBITA（非 GAAP）同比 −14%，降得更多。', factId: 'F-BA-2' },
        { text: '公司把自由现金流由正转负归因于云基础设施支出和「淘宝闪购」投入；公告没有单独解释经营现金流下降 39% 的原因。', interpId: 'I-BA-2' },
      ],
      unknown: '这些投入会持续多久、能否带来回报，这一期公告回答不了。',
    },
    figure: {
      kind: 'bars',
      title: '同一季度，各项指标的同比变化',
      unit: '%',
      note: '2025 年 4–6 月 · 公司公告（SEC 6-K）',
      factIds: ['F-BA-1', 'F-BA-2', 'F-BA-3', 'F-BA-4'],
      rows: [metricRow('M-BA-REV'), metricRow('M-BA-LFL'), metricRow('M-BA-OP'), metricRow('M-BA-NI'), metricRow('M-BA-OCF')],
    },
    path: [
      { id: 'n1', stage: '事件', base: { title: '公布 2025 年 6 月季度业绩', tone: 'supported' }, basisFactIds: ['F-BA-1'], why: '公司公告，经 SEC 6-K 报送。', breaksIf: '公告被更正。' },
      { id: 'n2', stage: '经营变量', base: { title: '云基础设施与即时零售投入增加', tone: 'supported', note: '公司对自由现金流下降的说明' }, basisFactIds: ['F-BA-4'], why: '公告把自由现金流（不是经营现金流）下降主要归因于这两项投入。', breaksIf: '后续披露显示投入口径变化。', interpId: 'I-BA-2' },
      { id: 'n3', stage: '财务表现', base: { title: '利润表与现金流量表走向分化', tone: 'supported', note: '净利润 ↑，经营利润 ↓，自由现金流由正转负' }, basisFactIds: ['F-BA-2', 'F-BA-3', 'F-BA-4'], why: '净利润含非经营性收益；现金流量表只记实际收付的现金。', breaksIf: '投资收益口径被重述。', interpId: 'I-BA-1' },
      { id: 'n4', stage: '待观察', base: { title: '下一季度经营现金流与资本开支是否回稳', tone: 'watch' }, basisFactIds: [], why: '一个季度的现金流出不足以判断趋势。', breaksIf: '—' },
    ],
    compare: {
      title: '同一季度，这几个收入、利润和现金数字为什么方向不同？',
      lead: '这些数字都来自同一份公告，它们衡量的东西不同。先比口径，再谈冲突。',
      dimLabels: ['衡量什么', '含投资收益？', '会计口径', '同比'],
      items: [
        { name: '收入（报告口径）', value: '2,476.52 亿元', factId: 'F-BA-1', dims: { '衡量什么': '全部业务收入，上年基数含已处置业务', '含投资收益？': '否', '会计口径': 'GAAP', '同比': '+2%' } },
        { name: '收入（同口径）', value: '仅给出增速', factId: 'F-BA-1', dims: { '衡量什么': '剔除已处置的高鑫零售与银泰后', '含投资收益？': '否', '会计口径': '公司调整口径', '同比': '+10%' } },
        { name: '经营利润', value: '349.88 亿元', factId: 'F-BA-2', dims: { '衡量什么': '利润表中的经营利润，不含投资市值变动', '含投资收益？': '否', '会计口径': 'GAAP', '同比': '−3%' } },
        { name: '净利润', value: '423.82 亿元', factId: 'F-BA-3', dims: { '衡量什么': '全部损益，含投资市值变动与处置收益', '含投资收益？': '是', '会计口径': 'GAAP', '同比': '+76%' } },
        { name: '经营现金流', value: '206.72 亿元', factId: 'F-BA-4', dims: { '衡量什么': '经营活动实际收付的现金', '含投资收益？': '否', '会计口径': '现金流量表', '同比': '−39%' } },
      ],
      coexist: '可以同时成立：收入增速的差异来自是否剔除已处置业务；净利润含投资收益，经营利润与现金流不含。',
      boundary: '不把这几个增速平均，也不挑一个「最真实」的数字；每个数字只回答它自己的问题。',
    },
    quiz: {
      q: '净利润同比增长 76%，是否说明经营现金流也改善了？',
      options: [
        { t: '是，利润增长就代表现金更多', correct: false },
        { t: '不一定，本期经营现金流反而下降了 39%', correct: true },
      ],
      explain: '净利润包含股权投资市值变动等非现金收益；经营现金流反映经营活动实际收付的现金，两者可以反向变化。',
      factIds: ['F-BA-3', 'F-BA-4'],
    },
    qa: [
      { id: 'q1', q: '净利润为什么涨了这么多？', aliases: ['净利润为什么大涨', '为什么净利润增长76%', '利润为什么涨'], a: '公告称主要由于股权投资按市值计价的变动，以及处置 Trendyol 本地生活业务的收益。', factIds: ['F-BA-3'], interpIds: ['I-BA-1'] },
      { id: 'q2', q: '自由现金流为什么变成负的？', aliases: ['现金流为什么下降', '为什么现金流变差', '自由现金流为什么是负的'], a: '公告称主要由于云基础设施支出增加和对「淘宝闪购」的投入。本期自由现金流流出 188.15 亿元，上年同期为流入 173.72 亿元。这是公司对自由现金流的解释；经营现金流同比 −39% 的原因，公告没有单独说明。', factIds: ['F-BA-4'], interpIds: ['I-BA-2'] },
      { id: 'q3', q: '收入只增长 2%，是不是增长很慢？', aliases: ['收入增长慢吗', '收入为什么只增长2%'], a: '报告口径增长 2%；剔除已处置的高鑫零售与银泰后，同口径增长 10%。引用时要说明用的是哪一个。', factIds: ['F-BA-1'], interpIds: [] },
      { id: 'q4', q: '原文在哪里能核对？', aliases: ['原文在哪', '怎么核对原文', '数据出处'], a: '在美国 SEC 网站的 6-K 附件 99.1，要点段落以「Revenue was RMB247,652 million」开头。点正文里每个数字旁的「核对原文」，可以看到这个数字对应的原句或表格行。', factIds: ['F-BA-1'], interpIds: [] },
    ],
    terms: [
      { term: '投资收益', aliases: ['市值变动', '按市值计价', '公允价值变动'], text: '公司持有其他公司的股权，股价或估值变化会计入利润表。这部分会让净利润上下波动，但并不是经营活动收到的现金。', factIds: ['F-BA-3'] },
      { term: '自由现金流', aliases: ['FCF'], text: '大致等于经营活动带来的现金，减去购买设备、建设基础设施等资本开支。阿里巴巴把它定义为非 GAAP 流动性指标，不同公司的算法可能不同。', factIds: ['F-BA-4'] },
      { term: '经营现金流', aliases: ['经营活动现金流'], text: '经营活动实际收到和付出的现金之差。它不受投资市值变动影响，常用来检验利润的「含金量」。', factIds: ['F-BA-4'] },
      { term: '同口径', aliases: ['like-for-like', '可比口径'], text: '把已经出售的业务从去年的基数里剔除，让两期在相同范围内比较。', factIds: ['F-BA-1'] },
      { term: 'EBITA', aliases: ['经调整EBITA'], text: '公司自定义的盈利指标，大致是扣除利息、税项和部分摊销前的经营利润，用来观察主营的盈利能力。它是非 GAAP 指标。', factIds: ['F-BA-2'] },
    ],
    retro: {
      asked: '当时的疑问：投入会持续多久？现金流会不会很快回稳？净利润的大涨能不能延续？',
      later: [
        { date: '2025-11-25', text: '下一季度经营现金流同比 −68%，自由现金流流出 218.40 亿元，原因仍是即时零售和云基础设施投入。', factId: 'F-BA-5' },
        { date: '2025-11-25', text: '同季度净利润同比 −53%。', factId: 'F-BA-6' },
        { date: '2025-11-25', text: '首席财务官称过去四个季度在 AI 与云上的资本开支约 1,200 亿元，近期盈利预计会波动。', factId: 'F-BA-7' },
      ],
      verdicts: [
        { label: '支持', text: '「自由现金流转负与主动投入一致」：下一季度投入继续，自由现金流流出扩大。' },
        { label: '支持', text: '「投资收益有波动性、不能外推」：净利润在下一季度转为下降。' },
        { label: '仍未知', text: '投入能否带来回报，截至这份公告仍无法判断。' },
      ],
    },
    timeNote: '以下观察项按 2025 年 8 月公告当时的信息写成。',
    watchSuggestions: ['下一期季度公告中的经营现金流与资本开支', '公司是否披露即时零售业务的单独经营数据'],
    deepNotes: [
      '自由现金流是公司定义的非 GAAP 指标，跨公司比较前要先核对定义。',
      '金额单位：原文为人民币百万元（RMB million），本页换算为亿元并保留两位小数。',
    ],
  },
  {
    id: 'cpi-2508',
    kind: 'real',
    topic: '行业数据',
    type: '统计数据',
    title: '8 月 CPI 同比 −0.4%、环比持平，核心 CPI 上涨 0.9%',
    question: '物价在跌，核心物价却在涨？',
    answer: '同比和去年比，环比和上个月比，核心 CPI 剔除了食品和能源——三个数字回答的是不同的问题，可以同时成立。',
    sourceDate: '2025-09-10',
    sourceLabel: '国家统计局 · 数据发布与解读',
    interpUpdatedAt: '2026-09-24',
    newFacts: '核心 CPI 涨幅连续第 4 个月扩大',
    readMins: 2,
    aggregated: '统计局发布稿与首席统计师解读是同一机构的两份材料，按一手来源分别标注。',
    summary: {
      fact: { text: '2025 年 8 月 CPI 同比下降 0.4%、环比持平；核心 CPI 同比上涨 0.9%。', factId: 'F-CPI-1' },
      points: [
        { text: '同比下降的约 0.9 个百分点来自去年的基数（翘尾因素），不全是今年新出现的降价。', interpId: 'I-CPI-1' },
        { text: '食品价格同比下降 4.3%，是整体 CPI 为负的主要拖累；剔除食品和能源后的核心 CPI 仍在上涨。', interpId: 'I-CPI-2' },
      ],
      unknown: '剔除翘尾后的「新涨价因素」，这次材料没有单独给出完整数值，本页不自行推算。',
    },
    figure: {
      kind: 'dots',
      title: '同一个月，三种读法',
      unit: '%',
      note: '2025 年 8 月 · 国家统计局',
      factIds: ['F-CPI-1', 'F-CPI-2', 'F-CPI-3'],
      min: -1,
      max: 1.2,
      rows: [metricRow('M-CPI-YOY', 'CPI 同比'), metricRow('M-CPI-MOM', 'CPI 环比'), metricRow('M-CPI-CORE', '核心 CPI 同比')],
    },
    path: [
      { id: 'n1', stage: '事件', base: { title: '统计局发布 8 月 CPI 与 PPI', tone: 'supported' }, basisFactIds: ['F-CPI-1', 'F-CPI-5'], why: '官方统计发布。', breaksIf: '数据修订（如有以公告为准）。' },
      { id: 'n2', stage: '经营变量', base: { title: '食品价格同比下降是主要拖累之一', tone: 'supported' }, basisFactIds: ['F-CPI-1', 'F-CPI-4'], why: '食品同比 −4.3%，叠加翘尾 −0.9 个百分点。', breaksIf: '—', interpId: 'I-CPI-2' },
      { id: 'n3', stage: '财务表现', base: { title: '对企业的含义因行业而异', tone: 'undetermined', note: '居民端价格与工业品价格走势不同' }, basisFactIds: ['F-CPI-5'], why: 'PPI 同比 −2.9% 但降幅收窄，上下游企业面对的价格环境不同。', breaksIf: '不能用 CPI 一个数字推断具体公司利润。' },
      { id: 'n4', stage: '待观察', base: { title: '下月翘尾影响变化与核心 CPI 是否继续扩大', tone: 'watch' }, basisFactIds: ['F-CPI-3', 'F-CPI-4'], why: '分清基数效应与新涨价因素。', breaksIf: '—' },
    ],
    compare: {
      title: '三种写法，都没错',
      lead: '下面是「示例标题写法」（非真实报道），它们引用的是同一份官方数据。',
      dimLabels: ['比较基期', '覆盖范围', '同比', '示例写法'],
      items: [
        { name: 'CPI 同比', value: '−0.4%', factId: 'F-CPI-1', dims: { '比较基期': '2024 年 8 月', '覆盖范围': '全部商品与服务', '同比': '−0.4%', '示例写法': '「8 月物价同比下降」' } },
        { name: 'CPI 环比', value: '0.0%', factId: 'F-CPI-2', dims: { '比较基期': '2025 年 7 月', '覆盖范围': '全部商品与服务', '同比': '（这是环比）持平', '示例写法': '「8 月物价与上月持平」' } },
        { name: '核心 CPI', value: '+0.9%', factId: 'F-CPI-3', dims: { '比较基期': '2024 年 8 月', '覆盖范围': '剔除食品和能源', '同比': '+0.9%', '示例写法': '「核心物价连续 4 个月涨幅扩大」' } },
      ],
      coexist: '可以同时成立：同比看一年，环比看一个月；核心 CPI 剔除了本月大幅下降的食品。',
      boundary: '「预计」与「已实现」不混用；多家报道援引同一份统计发布，不构成独立验证。',
    },
    quiz: {
      q: 'CPI 同比 −0.4%，同一个月环比持平。下面哪句话正确？',
      options: [
        { t: '两个数字互相矛盾，其中一个一定有误', correct: false },
        { t: '它们比较的基期不同，可以同时成立', correct: true },
      ],
      explain: '同比与去年同月比较，环比与上月比较；另外上年基数带来约 −0.9 个百分点的翘尾影响。',
      factIds: ['F-CPI-2', 'F-CPI-4'],
    },
    qa: [
      { id: 'q1', q: '同比下降有多少来自去年的基数？', aliases: ['翘尾影响有多大', '基数影响多少'], a: '统计局解读称，8 月翘尾影响约为 −0.9 个百分点，比上月的下拉作用扩大 0.4 个百分点。', factIds: ['F-CPI-4'], interpIds: ['I-CPI-1'] },
      { id: 'q2', q: 'PPI 怎么样？', aliases: ['工业品价格怎么样', 'PPI是多少'], a: '8 月 PPI 同比下降 2.9%，降幅比上月收窄 0.7 个百分点；环比由上月下降 0.2% 转为持平。', factIds: ['F-CPI-5'], interpIds: [] },
      { id: 'q3', q: '食品价格跌了多少？', aliases: ['食品价格怎么样', '猪肉价格怎么样'], a: '8 月食品价格同比下降 4.3%；环比上涨 0.5%。更细的分项请查看统计局原文。', factIds: ['F-CPI-1', 'F-CPI-2'], interpIds: [] },
    ],
    terms: [
      { term: '翘尾', aliases: ['翘尾因素', '翘尾影响', '基数效应'], text: '去年价格的变动会带进今年的同比读数里。即使今年价格没变，同比也可能因为去年的基数而上升或下降。', factIds: ['F-CPI-4'] },
      { term: '核心CPI', aliases: ['核心 CPI', '核心通胀'], text: '扣除食品和能源价格后的 CPI。食品和能源波动大，剔除后更容易看出其他商品和服务的价格走势。它不是「更真实的 CPI」，只是回答另一个问题。', factIds: ['F-CPI-3'] },
      { term: '同比', aliases: [], text: '和去年同一时期比较。', factIds: ['F-CPI-1'] },
      { term: '环比', aliases: [], text: '和上一个统计周期（这里是上个月）比较。', factIds: ['F-CPI-2'] },
      { term: 'PPI', aliases: ['工业生产者出厂价格'], text: '工业企业产品出厂时的价格指数，反映上游工业品价格的变化。', factIds: ['F-CPI-5'] },
    ],
    timeNote: '以下观察项按 2025 年 9 月发布当时的信息写成。之后各月的数据本页没有逐条核验，不断言结果。',
    watchSuggestions: ['下一期 CPI 发布中的翘尾影响与核心 CPI', 'PPI 环比能否持续持平或转正'],
    deepNotes: ['核心 CPI 是「扣除食品和能源价格」的 CPI，不是「更真实的 CPI」，只是回答不同的问题。'],
  },
  {
    id: 'fomc-2509',
    kind: 'real',
    topic: '海外官方',
    type: '央行声明',
    title: '美联储降息 25 个基点至 4.00%–4.25%，投票 11 比 1',
    question: '美联储降息，是因为经济变差了吗？',
    answer: '声明给出的降息理由是「就业下行风险上升」，同时写明通胀「仍略高」——这是在两种风险之间权衡，并没有宣布经济已经变差。',
    sourceDate: '2025-09-17（美东）',
    sourceLabel: '美联储官网 · 英文原文',
    interpUpdatedAt: '2026-09-24',
    newFacts: '一名理事反对，主张降 50 个基点',
    readMins: 2,
    aggregated: '同一事件的多家中文报道都援引这份声明，按来源链合并为 1 条证据，不算多份独立验证。',
    summary: {
      fact: { text: '美联储把政策利率目标区间下调 25 个基点至 4.00%–4.25%，11 票赞成、1 票反对。', factId: 'F-FED-1' },
      points: [
        { text: '声明的原话是失业率「小幅上升但仍处低位」、通胀「仍略高」——两边的措辞都很克制。', factId: 'F-FED-3' },
        { text: '降息理由落在「风险平衡变化」：委员会判断就业面临的下行风险上升了。这是对可能性的判断，不是事实陈述。', interpId: 'I-FED-1' },
      ],
      unknown: '声明本身没有承诺后续是否继续降息；本页也没有纳入会后发布会的内容。',
    },
    figure: {
      kind: 'range',
      title: '联邦基金利率目标区间',
      note: '美联储声明 · 决议前区间由「下调 1/4 个百分点」推算',
      factIds: ['F-FED-1', 'F-FED-5'],
      steps: [
        { label: '决议前', lo: 4.25, hi: 4.5, derived: true },
        { label: '9 月 17 日', lo: 4, hi: 4.25 },
        { label: '10 月 29 日', lo: 3.75, hi: 4 },
      ],
    },
    path: [
      { id: 'n1', stage: '事件', base: { title: '目标区间下调至 4.00%–4.25%', tone: 'supported' }, basisFactIds: ['F-FED-1', 'F-FED-2'], why: '声明原文直接写明。', breaksIf: '声明被更正（目前未见）。' },
      { id: 'n2', stage: '经营变量', base: { title: '美元短端融资成本随政策利率下移', tone: 'conditional', note: '条件：市场利率跟随政策利率' }, basisFactIds: ['F-FED-1'], why: '联邦基金利率是美元短端利率的锚。', breaksIf: '市场已提前定价，或期限溢价上升抵消。', interpId: 'I-FED-1' },
      { id: 'n3', stage: '财务表现', base: { title: '对企业利息支出的影响取决于债务结构', tone: 'undetermined', note: '浮动利率敞口不同，结论不同' }, basisFactIds: [], why: '只有浮动利率或需要再融资的债务才会较快受影响。', breaksIf: '以固定利率长债为主的企业几乎不受本次影响。' },
      { id: 'n4', stage: '待观察', base: { title: '下一次声明是否仍强调就业下行风险', tone: 'watch' }, basisFactIds: ['F-FED-4'], why: '措辞变化比单次动作更能说明判断是否改变。', breaksIf: '—' },
    ],
    translations: [
      { original: 'the unemployment rate has edged up but remains low', faithful: '失业率小幅上升，但仍处于低位', inflated: '失业率攀升，就业明显恶化', why: '“edged up” 是小幅，删掉 “but remains low” 后语气完全改变。', factId: 'F-FED-3' },
      { original: 'Inflation has moved up and remains somewhat elevated', faithful: '通胀有所上升，仍略高', inflated: '通胀再度抬头、居高不下', why: '“somewhat” 是限定词，译成「居高不下」强化了程度。', factId: 'F-FED-3' },
      { original: 'judges that downside risks to employment have risen', faithful: '判断就业面临的下行风险已经上升', inflated: '美联储承认就业正在下滑', why: '「风险上升」是对可能性的判断，不等于「已经下滑」。', factId: 'F-FED-4' },
    ],
    quiz: {
      q: '声明说 “downside risks to employment have risen”，哪种理解最贴近原文？',
      options: [
        { t: '美联储确认就业已经开始下滑', correct: false },
        { t: '美联储判断就业变差的可能性上升了', correct: true },
        { t: '美联储承诺还会继续降息', correct: false },
      ],
      explain: '原文是对风险的判断，没有陈述就业已经下滑，也没有承诺后续路径。',
      factIds: ['F-FED-4'],
    },
    qa: [
      { id: 'q1', q: '这次为什么有人投反对票？', aliases: ['谁投了反对票', '反对票是谁', '为什么有反对票'], a: '理事 Stephen I. Miran 投了反对票，他主张本次降 50 个基点而不是 25 个基点——他是嫌降得少，不是反对降息。声明没有展开他的理由。', factIds: ['F-FED-2'], interpIds: [] },
      { id: 'q2', q: '北京时间是什么时候公布的？', aliases: ['几点公布的', '北京时间几点'], a: '声明于美国东部夏令时间 2025-09-17 下午 2:00 发布，对应北京时间 2025-09-18 凌晨 2:00。', factIds: ['F-FED-1'], interpIds: [] },
      { id: 'q3', q: '降息的理由是什么？', aliases: ['为什么降息', '降息原因'], a: '声明写的是风险平衡发生变化：就业下行风险上升，而通胀仍略高。本页把它理解为风险权衡，而不是经济已经走弱。', factIds: ['F-FED-3', 'F-FED-4'], interpIds: ['I-FED-1'] },
    ],
    terms: [
      { term: '基点', aliases: ['bp', 'BP'], text: '1 个基点等于 0.01 个百分点。25 个基点就是 0.25 个百分点。', factIds: ['F-FED-1'] },
      { term: '联邦基金利率', aliases: ['联邦基金利率目标区间'], text: '美国银行之间隔夜拆借的利率，是美联储最主要的政策利率，美联储设定的是它的目标区间。', factIds: ['F-FED-1'] },
      { term: '双重使命', aliases: ['dual mandate'], text: '美联储的两个法定目标：最大化就业和物价稳定（长期通胀 2%）。', factIds: ['F-FED-4'] },
    ],
    retro: {
      asked: '当时的疑问：「风险权衡」的判断会不会维持？还会不会继续降息？',
      later: [
        { date: '2025-10-29', text: '美联储再次下调 25 个基点，目标区间降至 3.75%–4.00%。', factId: 'F-FED-5' },
        { date: '2025-10-29', text: '声明仍写「就业下行风险在近几个月上升」；这次有两票反对，一票主张多降、一票主张不降。', factId: 'F-FED-6' },
      ],
      verdicts: [
        { label: '支持', text: '「这是风险权衡」：下一次声明沿用了同样的风险表述，并继续降息。' },
        { label: '部分支持', text: '9 月的分歧只有「嫌降得少」一个方向；到 10 月，分歧变成两个方向，权衡变得更难。' },
      ],
    },
    timeNote: '以下观察项按 2025 年 9 月声明发布当时的信息写成。',
    watchSuggestions: ['下一次 FOMC 声明中对就业风险的措辞', '美国劳工部的月度就业数据'],
    deepNotes: [
      '时区：声明在美国东部时间下午 2 点发布，中文资讯在北京时间凌晨出现，日期相差一天。本页保留两种写法。',
      '「11 比 1」中唯一反对者主张更大幅度降息，而不是反对降息——转述时容易被写反。',
    ],
  },
  {
    id: 'pboc-2505',
    kind: 'real',
    topic: '宏观政策',
    type: '货币政策',
    title: '央行降准 0.5 个百分点、政策利率下调 0.1 个百分点',
    question: '降准降息后，企业借钱会更便宜吗？',
    answer: '降准降息让银行拿到的资金更便宜；企业借钱是否更便宜，要看贷款利率有没有跟着降。当时官方「预计」贷款利率下行约 0.1 个百分点。',
    sourceDate: '2025-05-07',
    sourceLabel: '新华社电稿 · 中国政府网转载',
    interpUpdatedAt: '2026-09-24',
    newFacts: '汽车金融与金融租赁公司准备金率降至 0%',
    readMins: 2,
    aggregated: '本条证据是新华社对发布会的报道（转述），人民银行正式公告原文尚待补充核对。',
    summary: {
      fact: { text: '5 月 15 日起降准 0.5 个百分点；5 月 8 日起 7 天期逆回购利率由 1.5% 降至 1.4%。', factId: 'F-PB-1' },
      points: [
        { text: '降准释放长期资金、政策利率下调降低边际成本，银行的资金变便宜了。', interpId: 'I-PB-1' },
        { text: '官方「预计」带动 LPR 下行约 0.1 个百分点——这是预期，不是已经发生的事实。', factId: 'F-PB-4' },
      ],
      unknown: '资金更便宜，不等于贷款一定更多：信贷需求跟不跟得上，公布当天无法知道。',
    },
    figure: {
      kind: 'slope',
      title: '政策公布前后',
      note: '新华社报道国新办发布会 · 2025-05-07',
      factIds: ['F-PB-2', 'F-PB-3'],
      rows: [
        { label: '7 天期逆回购利率', from: 1.5, to: 1.4, unit: '%' },
        { label: '平均存款准备金率', from: 6.6, to: 6.2, unit: '%' },
      ],
    },
    toggles: [
      { id: 'passThrough', label: '银行把成本下降让渡给贷款利率', hint: '若银行选择保留利差，传导会打折扣', default: true },
      { id: 'weakDemand', label: '企业贷款需求疲弱', hint: '资金更便宜，但未必有人借', default: false },
    ],
    path: [
      { id: 'n1', stage: '事件', base: { title: '降准 0.5 个百分点 + 政策利率下调 0.1 个百分点', tone: 'supported' }, basisFactIds: ['F-PB-1', 'F-PB-2'], why: '发布会公布，新华社报道。', breaksIf: '正式公告与报道不一致（尚待核对原文）。' },
      { id: 'n2', stage: '经营变量', base: { title: '银行负债成本下降、可贷资金增加', tone: 'supported' }, basisFactIds: ['F-PB-1', 'F-PB-3'], why: '准备金率下降释放长期资金；政策利率下降降低边际融资成本。', breaksIf: '银行负债端其他成本（如存款利率）没有同步变化。', interpId: 'I-PB-1' },
      {
        id: 'n3', stage: '财务表现', base: { title: '企业融资成本可能下降', tone: 'conditional' }, basisFactIds: ['F-PB-4'], why: '官方预计 LPR 下行约 0.1 个百分点。', breaksIf: '银行不传导，或信贷需求同步走弱。', interpId: 'I-PB-1',
        resolve: (c) => {
          if (!c.passThrough) return { title: '融资成本变化不确定', tone: 'undetermined', note: '银行不传导时，政策利率下调未必体现在贷款利率上' };
          if (c.weakDemand) return { title: '贷款利率可能下降，但贷款量未必增加', tone: 'conditional', note: '需求疲弱时，价格下降不等于信贷扩张' };
          return { title: '企业融资成本可能下降', tone: 'conditional', note: '在银行传导、需求不弱的条件下' };
        },
      },
      {
        id: 'n4', stage: '待观察', base: { title: '下一次 LPR 报价与月度信贷数据', tone: 'watch' }, basisFactIds: ['F-PB-4'], why: '把「预计」变成「已实现」需要后续数据。', breaksIf: '—',
        resolve: (c) => (c.weakDemand ? { title: '重点看信贷数据：贷款余额增速是否回升', tone: 'watch' } : { title: '下一次 LPR 报价与月度信贷数据', tone: 'watch' }),
      },
    ],
    quiz: {
      q: '官方「预计带动 LPR 下行约 0.1 个百分点」，这句话属于？',
      options: [
        { t: '已经发生的事实', correct: false },
        { t: '官方的预期，需要后续报价验证', correct: true },
      ],
      explain: '「预计」和「已经实现」不能混用。后来的报价见本页「后来发生了什么」。',
      factIds: ['F-PB-4'],
    },
    qa: [
      { id: 'q1', q: '这次降准释放多少资金？', aliases: ['释放多少流动性', '降准释放多少钱'], a: '人民银行负责人表示，预计向市场提供长期流动性约 1 万亿元。这是官方估计值，不是已经进入实体经济的金额。', factIds: ['F-PB-3'], interpIds: [] },
      { id: 'q2', q: '贷款利率后来降了多少？', aliases: ['贷款利率会降多少', 'LPR降了多少', 'LPR后来怎么样'], a: '5 月 20 日公布的 1 年期和 5 年期以上 LPR 均下降 10 个基点，分别为 3.0% 和 3.5%（来源为人民日报报道，属于转述）。', factIds: ['F-PB-5'], interpIds: ['I-PB-1'] },
      { id: 'q3', q: '房贷利率会受影响吗？', aliases: ['房贷会降吗', '房贷利率'], a: '5 年期以上 LPR 是房贷利率的主要参考，后来下降了 10 个基点至 3.5%。具体到每笔房贷，还取决于合同的定价方式和重定价日，本页无法替你判断。', factIds: ['F-PB-5'], interpIds: [] },
    ],
    terms: [
      { term: '降准', aliases: ['存款准备金率', '准备金率'], text: '降低银行必须存放在央行的存款比例，银行可以用来放贷的长期资金因此增加。', factIds: ['F-PB-1'] },
      { term: 'LPR', aliases: ['贷款市场报价利率'], text: '由报价行按公开市场操作利率加点形成的贷款参考利率，每月公布。1 年期多用于企业贷款，5 年期以上多用于房贷。', factIds: ['F-PB-4'] },
      { term: '逆回购', aliases: ['7天期逆回购', '公开市场操作利率'], text: '央行向银行短期投放资金的操作。7 天期逆回购利率目前是主要的政策利率。', factIds: ['F-PB-2'] },
      { term: '基点', aliases: ['bp'], text: '1 个基点等于 0.01 个百分点。10 个基点就是 0.1 个百分点。', factIds: ['F-PB-5'] },
    ],
    retro: {
      asked: '当时的疑问：「预计 LPR 下行约 0.1 个百分点」会不会兑现？银行负债成本会不会一起降？',
      later: [
        { date: '2025-05-20', text: '1 年期和 5 年期以上 LPR 均下降 10 个基点，分别为 3.0% 和 3.5%。', factId: 'F-PB-5' },
        { date: '2025-05-20', text: '同一天，主要银行下调了存款挂牌利率。', factId: 'F-PB-5' },
      ],
      verdicts: [
        { label: '支持', text: '贷款利率的价格传导按预期发生了。' },
        { label: '支持', text: '「负债成本也要降」这一失效条件没有触发：存款利率同步下调。' },
        { label: '仍未知', text: '贷款数量是否增加，本页没有核验后续信贷数据。' },
      ],
    },
    timeNote: '以下观察项按 2025 年 5 月政策公布当时的信息写成。',
    watchSuggestions: ['下一次 LPR 报价公告（以全国银行间同业拆借中心公布为准）', '人民银行正式公告原文（替代转述来源）'],
    deepNotes: ['证据状态为「仅有转述」：新华社报道了发布会内容，本 Demo 尚未核对人民银行正式公告原文。这不影响事实展示，但会在依据里明确提示。'],
  },
  {
    id: 'teach-cost',
    kind: 'hypothetical',
    topic: '教学案例',
    type: '机制教学',
    title: '假设：原材料市场报价下降（切换条件看推论）',
    question: '原材料降价，毛利率一定会改善吗？',
    answer: '要采购价真的跟着降、售价又不变，才能推出毛利率可能改善；如果售价也降，就得比较两者降了多少。',
    sourceDate: '无（教学设定）',
    sourceLabel: '见微编辑部 · 假设教学案例',
    interpUpdatedAt: '2026-09-24',
    newFacts: '教学案例，不对应任何真实公司或行业',
    readMins: 2,
    summary: {
      fact: { text: '假设前提：某制造企业主要原材料的市场报价下降。', factId: 'F-T-1' },
      points: [
        { text: '市场报价下降，企业的采购价不一定立刻跟着降，比如签了长期锁价合同。', interpId: 'I-T-1' },
        { text: '毛利率 =（售价 − 成本）/ 售价。只看成本一端，无法得出结论。', interpId: 'I-T-1' },
      ],
      unknown: '采购合同、售价、其他成本，只要一个条件变了，结论就要重写。',
    },
    toggles: [
      { id: 'procureSync', label: '采购价已跟随市场报价下降', hint: '有采购合同或采购数据支持时才打开', default: true },
      { id: 'priceDown', label: '产品售价也下降', hint: '下游压价或竞争加剧', default: false },
    ],
    path: [
      { id: 'n1', stage: '事件', base: { title: '原材料市场报价下降（假设）', tone: 'supported' }, basisFactIds: ['F-T-1'], why: '教学设定。', breaksIf: '—' },
      {
        id: 'n2', stage: '经营变量', base: { title: '单位成本可能下降', tone: 'conditional' }, basisFactIds: ['F-T-1'], why: '原材料是成本的一部分，但成本取决于实际采购价，而不是市场报价。', breaksIf: '采购价被长协锁定，或原材料占成本比重很低。', interpId: 'I-T-1',
        resolve: (c) => (c.procureSync
          ? { title: '单位成本可能下降', tone: 'conditional', note: '条件：采购价已跟随市场报价下降' }
          : { title: '单位成本短期未必下降', tone: 'undetermined', note: '采购价没有跟随，市场报价下降传不到成本' }),
      },
      {
        id: 'n3', stage: '财务表现', base: { title: '毛利率可能改善', tone: 'conditional' }, basisFactIds: [], why: '毛利率 =（售价 − 成本）/ 售价。', breaksIf: '售价同步或更大幅度下降。', interpId: 'I-T-1',
        resolve: (c) => {
          if (!c.procureSync) return { title: '无法判断毛利率变化', tone: 'undetermined', note: '成本端没有变化的依据' };
          if (c.priceDown) return { title: '需比较售价与成本下降幅度', tone: 'undetermined', note: '无法仅凭成本变化判断毛利率' };
          return { title: '毛利率可能改善', tone: 'conditional', note: '条件：售价与其他条件不变' };
        },
      },
      {
        id: 'n4', stage: '待观察', base: { title: '下一期的毛利率与采购价格披露', tone: 'watch' }, basisFactIds: [], why: '只有披露数据能验证推论。', breaksIf: '—',
        resolve: (c) => (c.priceDown ? { title: '对比售价降幅与单位成本降幅', tone: 'watch' } : { title: '下一期的毛利率与采购价格披露', tone: 'watch' }),
      },
    ],
    quiz: {
      q: '原材料降价、售价也降价时，毛利率会怎样？',
      options: [
        { t: '一定改善', correct: false },
        { t: '一定恶化', correct: false },
        { t: '需要比较两者下降幅度，无法直接判断', correct: true },
      ],
      explain: '毛利率同时受售价和成本影响。只知道其中一个方向时，无法得出结论。',
      factIds: ['F-T-1'],
    },
    qa: [
      { id: 'q1', q: '为什么不直接给出毛利率提高多少？', aliases: ['毛利率会提高多少', '能算出毛利率吗'], a: '这是机制教学，不是预测模型。没有真实的价格和成本结构数据，给出具体数值就是编造。', factIds: ['F-T-1'], interpIds: ['I-T-1'] },
    ],
    terms: [
      { term: '毛利率', aliases: ['毛利'], text: '（营业收入 − 营业成本）/ 营业收入。反映每卖出 1 元产品，扣掉直接成本后还剩多少。', factIds: ['F-T-1'] },
      { term: '长协', aliases: ['长期协议', '锁价'], text: '买卖双方事先约定一段时间内的价格或定价公式。市场价格变化时，长协价格可能不会立刻跟着变。', factIds: ['F-T-1'] },
    ],
    watchSuggestions: ['（练习）找一家你关注的公司，查它是否披露原材料成本占比'],
    deepNotes: ['路径箭头表示分析关系，不等于已经证明因果。切换条件只改变推论节点，不改变「假设前提」这一事实层。'],
  },
  {
    id: 'demo-a',
    kind: 'hypothetical',
    demoOnly: true,
    topic: '教学案例',
    type: '异常场景演示',
    title: '示范公司 A：收入数字被更正后，原解释怎么办？',
    question: '来源更正、来源缺失时，解读如何停止、如何恢复？',
    answer: '（虚构）解释依赖的数字一旦被更正，解释本身就要复核，而不是只改一个数字。',
    sourceDate: '演示时钟 · 第 1 天',
    sourceLabel: '虚构示范公司 · 模拟公告',
    interpUpdatedAt: '演示时钟',
    newFacts: '更正公告可在「我的观察」或内容工作台触发',
    readMins: 1,
    summary: {
      fact: { text: '（虚构）示范公司 A 公告季度收入 12.0 亿元，同比增长 8%。', factId: 'F-DA-1' },
      points: [{ text: '（虚构）管理层称增长主要来自新增线上渠道——只有口头表述支持。', interpId: 'I-DA-1' }],
      unknown: '分渠道收入没有书面披露。',
    },
    path: [
      { id: 'n1', stage: '事件', base: { title: '（虚构）季度收入公告', tone: 'supported' }, basisFactIds: ['F-DA-1'], why: '示范公告 v1。', breaksIf: '公告被更正。' },
      { id: 'n2', stage: '经营变量', base: { title: '（虚构）新增线上渠道贡献增量', tone: 'conditional', note: '仅有管理层口头表述' }, basisFactIds: ['F-DA-2'], why: '业绩说明会纪要。', breaksIf: '纪要缺失或收入数字被更正。', interpId: 'I-DA-1' },
      { id: 'n3', stage: '待观察', base: { title: '分渠道收入的书面披露', tone: 'watch' }, basisFactIds: [], why: '把口头表述变成可核对的数据。', breaksIf: '—' },
    ],
    revisions: {
      v2: {
        summary: {
          fact: { text: '（虚构）更正后：季度收入 10.2 亿元，同比下降 8%；原公告误将含税收入计入。', factId: 'F-DA-1B' },
          points: [{ text: '（虚构）收入实际是下降的，原「增长来自新渠道」的解释失去了数字前提；新渠道贡献要等分渠道披露。', interpId: 'I-DA-2' }],
          unknown: '更正公告没有披露分渠道数据。',
        },
        path: [
          { id: 'n1', stage: '事件', base: { title: '（虚构）更正公告：收入 10.2 亿元，同比 −8%', tone: 'supported' }, basisFactIds: ['F-DA-1B'], why: '示范更正公告 v2。', breaksIf: '再次更正。' },
          { id: 'n2', stage: '经营变量', base: { title: '（虚构）新渠道贡献待复核', tone: 'undetermined', note: '原解释的数字前提已被更正' }, basisFactIds: ['F-DA-1B', 'F-DA-2'], why: '收入方向改变后，口头表述不足以支撑原结论。', breaksIf: '—', interpId: 'I-DA-2' },
          { id: 'n3', stage: '待观察', base: { title: '分渠道收入的书面披露', tone: 'watch' }, basisFactIds: [], why: '把口头表述变成可核对的数据。', breaksIf: '—' },
        ],
      },
    },
    qa: [
      { id: 'q1', q: '增长来自哪里？', aliases: ['收入增长来自哪里'], a: '（虚构）管理层称新增线上渠道贡献了大部分增量收入；这是口头表述，没有书面分渠道数据。', factIds: ['F-DA-2'], interpIds: ['I-DA-1'] },
      { id: 'q2', q: '更正后收入是多少？', aliases: ['收入更正了多少'], a: '（虚构）更正后季度收入 10.2 亿元，同比下降 8%。', factIds: ['F-DA-1B'], interpIds: ['I-DA-2'] },
    ],
    watchSuggestions: ['（虚构）分渠道收入的书面披露：尚未公布'],
    deepNotes: ['这是虚构示范公司。真实机构不会在本 Demo 中被虚构公告、冲突或更正。'],
    versions: [
      { id: 'v1', label: 'v1 · 原公告', note: '收入 12.0 亿元，同比 +8%' },
      { id: 'v2', label: 'v2 · 更正公告（演示更新）', note: '收入更正为 10.2 亿元，同比 −8%' },
    ],
  },
];

/*
 * 旧样本的排序信号（v0.7）。2025 年的历史案例时效分低，会自然排在 2026 年新资讯之后。
 */
const SIGNALS: Record<string, EventItem['signals']> = {
  'baba-2506': { scope: 'company', magnitude: [4, '净利润 +76% 与经营现金流 −39% 方向相反'], policy: [1, '公司层面事件'], heat: 60 },
  'cpi-2508': { scope: 'macro', magnitude: [3, '同比、环比、核心三个读数方向不同'], policy: [3, '价格数据影响政策预期'], heat: 52 },
  'fomc-2509': { scope: 'global', magnitude: [4, '年内首次降息'], policy: [5, '直接的货币政策动作'], heat: 62 },
  'pboc-2505': { scope: 'macro', magnitude: [4, '降准与降息同时公布'], policy: [5, '直接的货币政策动作'], heat: 58 },
  'teach-cost': { scope: 'teaching', magnitude: [0, '教学设定，不是新闻'], policy: [0, '无'], heat: 30 },
  'demo-a': { scope: 'teaching', magnitude: [0, '虚构示范公司'], policy: [0, '无'], heat: 10 },
};
const RELATED: Record<string, string[]> = { 'cpi-2508': ['price-2608'], 'fomc-2509': ['fomc-2609'], 'baba-2506': ['profit-2608'] };

export const EVENTS: EventItem[] = [
  ...EVENTS_2026,
  ...EVENTS_BASE.map((e) => ({ ...e, signals: e.signals ?? SIGNALS[e.id], related: e.related ?? RELATED[e.id] })),
];
