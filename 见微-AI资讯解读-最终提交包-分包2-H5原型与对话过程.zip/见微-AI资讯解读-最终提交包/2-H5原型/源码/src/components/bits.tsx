import { AlertTriangle, ChevronDown, Moon, Sun } from 'lucide-react';
import { setTheme, useStore } from '../logic/store';
import { useMedia } from '../logic/hooks';
import { type CSSProperties, type ElementType, type ReactNode, useEffect, useId, useRef, useState } from 'react';
import { useReveal } from '../logic/hooks';
import type { EventItem, NodeTone, ReviewStatus } from '../data/types';

/* 颜色从不单独承担信息：每个状态都带文字 */

export function KindBadge({ ev }: { ev: EventItem }) {
  // 资讯池更新日（2026-09-28）前 90 天内发布的算「近期资讯」，更早的是历史案例
  if (ev.kind === 'real') return /^2026-(0[7-9]|1[0-2])/.test(ev.sourceDate) ? <span className="tag tag-real tag-recent">近期资讯</span> : <span className="tag tag-real">历史案例</span>;
  return <span className="tag tag-hypo">{ev.demoOnly ? '虚构示范' : '假设教学'}</span>;
}

export function AiBadge() {
  return <span className="tag tag-ai">AI 辅助整理</span>;
}

const TONE: Record<NodeTone, string> = {
  supported: '有依据',
  conditional: '有条件',
  undetermined: '无法判断',
  watch: '待观察',
};
export function ToneTag({ tone }: { tone: NodeTone }) {
  return <span className={`tone tone-${tone}`}>{TONE[tone]}</span>;
}

const STATUS: Record<ReviewStatus | 'hidden', string> = {
  draft: '草稿',
  needs_review: '待复核',
  published: '已发布（模拟审核）',
  blocked: '已阻断',
  superseded: '已被更正替代',
  withdrawn: '已撤回',
  hidden: '未到版本',
};
export function StatusTag({ status }: { status: ReviewStatus | 'hidden' }) {
  return <span className={`status status-${status}`}>{STATUS[status]}</span>;
}

export function Stopped({ children }: { children: ReactNode }) {
  return (
    <div className="stopped" role="status">
      <AlertTriangle size={16} strokeWidth={2} aria-hidden="true" />
      <div>{children}</div>
    </div>
  );
}

export function Cite({ n, onClick, missing }: { n: number | string; onClick: () => void; missing?: boolean }) {
  return (
    <button className={`cite${missing ? ' cite-missing' : ''}`} onClick={onClick} aria-label={`查看依据 ${n}${missing ? '（来源暂不可用）' : ''}`}>
      {n}
    </button>
  );
}

/** 品牌字标：朱红印章，全页唯一的暖色 */
export function Seal({ size = 34 }: { size?: number }) {
  return (
    <svg className="seal" width={size} height={size} viewBox="0 0 40 40" aria-hidden="true">
      <rect x="1" y="1" width="38" height="38" rx="7" fill="var(--seal)" />
      <rect x="4.5" y="4.5" width="31" height="31" rx="4.5" fill="none" stroke="rgba(255,255,255,.55)" strokeWidth="1" />
      <text x="20" y="21" textAnchor="middle" dominantBaseline="middle" fill="#fff" fontFamily="var(--serif)" fontWeight="600" fontSize="17">微</text>
    </svg>
  );
}

/** 按需展开：标题 + 一句预告，展开后才出现完整内容 */
export function Disclosure({ title, preview, badge, open: openProp, children, id }: { title: string; preview?: ReactNode; badge?: ReactNode; open?: boolean; children: ReactNode; id?: string }) {
  const [open, setOpen] = useState(!!openProp);
  const rid = useId();
  useEffect(() => setOpen(!!openProp), [openProp]);
  return (
    <section className={`disc${open ? ' is-open' : ''}`} id={id}>
      <h2 className="disc-h">
        <button className="disc-btn" aria-expanded={open} aria-controls={rid} onClick={() => setOpen((v) => !v)}>
          <span className="disc-text">
            <span className="disc-title">{title}{badge}</span>
            {preview && <span className="disc-preview">{preview}</span>}
          </span>
          <ChevronDown className="disc-chev" size={20} strokeWidth={1.75} aria-hidden="true" />
        </button>
      </h2>
      {/* 用 grid 行高 0fr → 1fr 做平滑展开；收起时 inert，读屏和 Tab 都跳过 */}
      <div className="disc-panel" id={rid} role="region" aria-label={title} {...(open ? {} : { inert: '' as unknown as boolean, 'aria-hidden': true })}>
        <div className="disc-clip"><div className="disc-inner">{children}</div></div>
      </div>
    </section>
  );
}

/** 轻提示：不打断阅读，可附一个后续动作 */
export function Toast({ text, action, onDone }: { text: string; action?: { label: string; href: string }; onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 5200);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div className="toast glass" role="status">
      <span>{text}</span>
      {action && <a href={action.href} className="toast-act">{action.label}</a>}
    </div>
  );
}

// 可选封面：把图片放进 src/assets/covers/<事件 id>.jpg|webp|png，构建时自动收录；没有图时页面照常成立
const covers = import.meta.glob('../assets/covers/*.{jpg,jpeg,png,webp,avif}', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
export function coverOf(id: string): string | undefined {
  const k = Object.keys(covers).find((p) => p.replace(/^.*\//, '').replace(/\.\w+$/, '') === id);
  return k ? covers[k] : undefined;
}

/** 滚动进入视口时淡入上移一次；默认可见，脚本失败或减少动态效果时不隐藏 */
export function Reveal({ as: Tag = 'div', className = '', delay = 0, children, ...rest }: { as?: ElementType; className?: string; delay?: number; children: ReactNode } & Record<string, unknown>) {
  const ref = useRef<HTMLElement>(null);
  const state = useReveal(ref);
  return (
    <Tag ref={ref} className={`reveal ${className}`} data-anim={state} style={{ ['--d' as string]: `${delay}ms` } as CSSProperties} {...rest}>
      {children}
    </Tag>
  );
}

/** 当前实际生效的主题 */
export function useDark() {
  const theme = useStore((s) => s.theme);
  const sys = useMedia('(prefers-color-scheme: dark)');
  return theme === 'dark' || (theme === 'system' && sys);
}

/** 顶部的一键切换：在浅色与深色之间切换（明确选择后不再跟随系统） */
export function ThemeToggle({ className = '' }: { className?: string }) {
  const dark = useDark();
  return (
    <button className={`icon-btn theme-toggle ${className}`} onClick={() => setTheme(dark ? 'light' : 'dark')} aria-label={dark ? '切换到浅色' : '切换到深色夜间模式'} title={dark ? '浅色' : '深色'}>
      <span className="tt-icon" key={dark ? 'd' : 'l'}>{dark ? <Sun size={19} strokeWidth={1.7} /> : <Moon size={19} strokeWidth={1.7} />}</span>
    </button>
  );
}

/** 页脚：跟随系统 / 浅色 / 深色 */
export function ThemeSelect() {
  const theme = useStore((s) => s.theme);
  const opts: [typeof theme, string][] = [['system', '跟随系统'], ['light', '浅色'], ['dark', '深色']];
  return (
    <div className="theme-select" role="radiogroup" aria-label="外观">
      <span className="dim">外观</span>
      {opts.map(([v, l]) => <button key={v} role="radio" aria-checked={theme === v} className={theme === v ? 'on' : ''} onClick={() => setTheme(v)}>{l}</button>)}
    </div>
  );
}
