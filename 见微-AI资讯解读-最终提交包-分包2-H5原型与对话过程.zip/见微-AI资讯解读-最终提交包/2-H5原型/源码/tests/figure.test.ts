import { describe, expect, it } from 'vitest';
import { EVENTS } from '../src/data/content';

describe('图表：不画出图外', () => {
  it('点图的基准线与所有读数都落在坐标范围内（PMI 基准线是 50，不是 0）', () => {
    let n = 0;
    for (const ev of EVENTS) {
      const f = ev.figure;
      if (f?.kind !== 'dots') continue;
      n++;
      const base = f.base ?? 0;
      expect(base >= f.min && base <= f.max, `${ev.id} 基准线 ${base} 不在 [${f.min}, ${f.max}]`).toBe(true);
      for (const r of f.rows) expect(r.value >= f.min && r.value <= f.max, `${ev.id} ${r.label}=${r.value}`).toBe(true);
    }
    expect(n).toBeGreaterThanOrEqual(3);
  });
});
