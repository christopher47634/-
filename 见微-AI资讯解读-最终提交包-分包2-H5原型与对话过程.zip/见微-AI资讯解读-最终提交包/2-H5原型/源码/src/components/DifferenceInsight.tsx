import { Bookmark, BookmarkCheck, ChevronDown, ListTree } from 'lucide-react';
import { useEffect, useId, useState } from 'react';
import type { EventItem } from '../data/types';
import type { InsightView, MetricState } from '../logic/evidence';
import { adoptSuggestedQuestion, track, useStore } from '../logic/store';
import { Stopped } from './bits';
import { noteLabel } from './MetricEvidence';
import { refById } from '../data/content';

/*
 * 看懂这处差异：问题 → 最多三项数字（各自一个「核对原文」）→ 一句解释 → 一处边界 → 关注这个问题。
 * 详细口径与公司原话按需展开；完整对照在下方「口径对照」。
 * 数字不用红绿，正负号自己说话；焦点指标只用细边线和淡底。
 */

const OFF: Partial<Record<MetricState['status'], string>> = {
  unavailable: '来源暂不可用 · 历史值仅供对照',
  invalid: '引用无效',
  corrected: '已更正 · 旧值仅供对照',
  weak: '仅有转述，未作为已核验数字',
};

export default function DifferenceInsight({
  ev,
  iv,
  focus,
  onCheck,
  onFollow,
  onMoreCaliber,
}: {
  ev: EventItem;
  iv: Extract<InsightView, { kind: 'card' }>;
  focus: string | null;
  onCheck: (metricId: string, ids: string[]) => void;
  onFollow: () => void;
  onMoreCaliber?: () => void;
}) {
  const s = useStore((x) => x);
  const [open, setOpen] = useState(false);
  const rid = useId();
  const ins = iv.insight;
  const ids = ins.metricIds;
  const watch = s.watches.find((w) => w.eventId === ev.id);
  const following = !!watch && watch.insightId === ins.id;
  const ownQuestion = !!watch && !!watch.suggestedQuestion;
  const interp = iv.interps[0]?.interp;
  const srcCount = new Set(iv.metrics.flatMap((m) => m.refs.map((r) => r.ref?.sourceId)).filter(Boolean)).size;
  const sameSource = srcCount === 1;

  useEffect(() => { track('insight_view', `${ev.id}:${ins.id}:${iv.version}`); }, [ev.id, ins.id, iv.version]);

  return (
    <section className={`insight${iv.degraded ? ' is-degraded' : ''}`} aria-labelledby={`${rid}-h`}>
      <header className="insight-head">
        <h2 id={`${rid}-h`} className="insight-k">看懂这处差异</h2>
        <span className="insight-period">{iv.metrics[0]?.metric?.period} · {sameSource ? '同一份材料' : `${srcCount} 份官方材料`}</span>
      </header>

      <ul className="im-list">
        {iv.metrics.map((m) => {
          const mt = m.metric!;
          const on = focus === m.id;
          return (
            <li key={m.id} className={`im${on ? ' is-focus' : ''}${m.usable ? '' : ' is-off'}`}>
              <div className="im-main">
                <span className="im-label">{mt.label}</span>
                <span className="im-basis">{mt.basis}</span>
                {OFF[m.status] && <span className="im-state">{OFF[m.status]}</span>}
                {m.status === 'partial' && <span className="im-state">部分来源不可用</span>}
              </div>
              <span className={`im-value num${m.usable ? '' : ' is-historic'}`}>{mt.display}</span>
              <button className="im-check" aria-pressed={on} onClick={() => onCheck(m.id, ids)} aria-label={`核对原文：${mt.label}，${mt.basis}，${mt.display}`}>
                核对原文
              </button>
            </li>
          );
        })}
      </ul>

      {iv.explain.live && interp ? (
        <p className="insight-explain"><span className="insight-tag">编辑解释</span>{interp.text}</p>
      ) : (
        <Stopped>{iv.interps[0] && !iv.interps[0].live ? <><strong>解释已停止展示。</strong>{iv.explain.reason}</> : iv.explain.reason}</Stopped>
      )}
      <p className="insight-bound"><span className="insight-tag">还不能判断</span>{ins.boundary.replace(/^这期材料还不足以判断：/, '')}</p>

      <button className="insight-more" aria-expanded={open} aria-controls={`${rid}-more`} onClick={() => setOpen((v) => !v)}>
        <span>{open ? '收起口径说明' : '展开口径说明'}</span>
        <ChevronDown size={18} strokeWidth={1.75} aria-hidden="true" />
      </button>
      {open && (
        <div id={`${rid}-more`} className="insight-detail">
          {iv.metrics.map((m) => m.metric && (
            <div key={m.id} className="insight-row">
              <p className="insight-row-h">{m.metric.label} <span className="num">{m.metric.display}</span></p>
              <p className="small">{m.metric.scope}</p>
              {m.metric.notes?.map((n, i) => (
                <p key={i} className={`small note-${n.kind}`}><span className="insight-tag">{noteLabel(n, n.refId ? refById(n.refId)?.sourceId : undefined)}</span>{n.text}</p>
              ))}
            </div>
          ))}
          <p className="small dim">「公司披露 / 官方披露」是原文的转述，「编辑解释」是见微的理解，二者分开写。</p>
        </div>
      )}

      <div className="insight-actions">
        {following ? (
          <a className="btn btn-done" href="#/watch">
            <BookmarkCheck size={18} strokeWidth={1.75} aria-hidden="true" /> 已关注这个问题
          </a>
        ) : (
          <button className="btn btn-primary" onClick={onFollow} disabled={!iv.explain.live && iv.metrics.every((m) => !m.usable)}>
            <Bookmark size={18} strokeWidth={1.75} aria-hidden="true" /> 关注这个问题
          </button>
        )}
        {onMoreCaliber && (
          <button className="btn btn-ghost" onClick={onMoreCaliber}>
            <ListTree size={18} strokeWidth={1.75} aria-hidden="true" /> 更多口径
          </button>
        )}
      </div>
      <p className="insight-q"><span className="insight-tag">关注后会记下</span>{ins.openQuestion}</p>
      {ownQuestion && (
        <div className="insight-own">
          <p className="small">你的关注里保留了自己写的问题：「{watch!.openQuestion}」</p>
          <button className="btn btn-ghost btn-sm" onClick={() => adoptSuggestedQuestion(watch!.watchId)}>改用本卡问题</button>
        </div>
      )}
    </section>
  );
}
