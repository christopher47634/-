import { useEffect, useRef } from 'react';

/*
 * 桌面首屏的指针流体（Stam stable fluids，原生 WebGL，零依赖）。
 * 参考 noomo「The Power of Storytelling」的首屏：深海军蓝底上，指针划过带出淡蓝与紫的光流。
 * 只放在首屏里，不铺在正文背后；滚出首屏、页面隐藏、或「减少动态效果」时停帧。
 * 不支持浮点纹理时画布隐藏，CSS 渐变兜底。
 */

const VS = `attribute vec2 aPos; varying vec2 vUv, vL, vR, vT, vB; uniform vec2 texel;
void main(){ vUv = aPos*0.5+0.5; vL=vUv-vec2(texel.x,0.); vR=vUv+vec2(texel.x,0.); vT=vUv+vec2(0.,texel.y); vB=vUv-vec2(0.,texel.y); gl_Position=vec4(aPos,0.,1.); }`;
const P = 'precision highp float; varying vec2 vUv, vL, vR, vT, vB;';
const FS = {
  splat: `${P} uniform sampler2D uTarget; uniform float aspect, radius; uniform vec3 color; uniform vec2 point;
    void main(){ vec2 p=vUv-point; p.x*=aspect; gl_FragColor=vec4(texture2D(uTarget,vUv).xyz+exp(-dot(p,p)/radius)*color,1.); }`,
  advect: `${P} uniform sampler2D uVelocity, uSource; uniform vec2 texel; uniform float dt, dissipation;
    void main(){ gl_FragColor=dissipation*texture2D(uSource, vUv-dt*texture2D(uVelocity,vUv).xy*texel); }`,
  divergence: `${P} uniform sampler2D uVelocity;
    void main(){ float L=texture2D(uVelocity,vL).x,R=texture2D(uVelocity,vR).x,T=texture2D(uVelocity,vT).y,B=texture2D(uVelocity,vB).y; gl_FragColor=vec4(.5*(R-L+T-B),0.,0.,1.); }`,
  curl: `${P} uniform sampler2D uVelocity;
    void main(){ float L=texture2D(uVelocity,vL).y,R=texture2D(uVelocity,vR).y,T=texture2D(uVelocity,vT).x,B=texture2D(uVelocity,vB).x; gl_FragColor=vec4(.5*(R-L-T+B),0.,0.,1.); }`,
  vorticity: `${P} uniform sampler2D uVelocity, uCurl; uniform float strength, dt;
    void main(){ float L=texture2D(uCurl,vL).x,R=texture2D(uCurl,vR).x,T=texture2D(uCurl,vT).x,B=texture2D(uCurl,vB).x,C=texture2D(uCurl,vUv).x;
      vec2 f=.5*vec2(abs(T)-abs(B),abs(R)-abs(L)); f/=length(f)+1e-4; f*=strength*C; f.y*=-1.;
      gl_FragColor=vec4(texture2D(uVelocity,vUv).xy+f*dt,0.,1.); }`,
  pressure: `${P} uniform sampler2D uPressure, uDivergence;
    void main(){ float L=texture2D(uPressure,vL).x,R=texture2D(uPressure,vR).x,T=texture2D(uPressure,vT).x,B=texture2D(uPressure,vB).x; gl_FragColor=vec4((L+R+B+T-texture2D(uDivergence,vUv).x)*.25,0.,0.,1.); }`,
  gradient: `${P} uniform sampler2D uPressure, uVelocity;
    void main(){ float L=texture2D(uPressure,vL).x,R=texture2D(uPressure,vR).x,T=texture2D(uPressure,vT).x,B=texture2D(uPressure,vB).x; gl_FragColor=vec4(texture2D(uVelocity,vUv).xy-vec2(R-L,T-B),0.,1.); }`,
  clear: `${P} uniform sampler2D uTexture; uniform float value; void main(){ gl_FragColor=value*texture2D(uTexture,vUv); }`,
  display: `${P} uniform sampler2D uDye; uniform float t;
    float h(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }
    void main(){
      vec3 bg = mix(vec3(0.020,0.043,0.110), vec3(0.047,0.078,0.180), smoothstep(0.0,1.0,vUv.y));
      vec3 d = texture2D(uDye,vUv).rgb;
      vec3 c = bg + (1.0 - exp(-d*2.4)) * 0.85;
      c *= mix(0.78, 1.0, smoothstep(1.2, 0.2, length(vUv-vec2(0.62,0.55))));
      c += (h(vUv*743.0+t)-0.5)*0.018;
      gl_FragColor = vec4(c,1.0);
    }`,
};

type GL = WebGLRenderingContext | WebGL2RenderingContext;
interface FBO { tex: WebGLTexture; fb: WebGLFramebuffer; w: number; h: number }
interface Double { read: FBO; write: FBO; swap(): void }

// 发光色（加色）：品牌蓝、淡蓝、紫
const TONES: [number, number, number][] = [[0.22, 0.42, 1.0], [0.55, 0.72, 1.0], [0.42, 0.28, 0.9]];

export default function HeroInk() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const host = canvas.parentElement!;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const opts = { alpha: false, antialias: false, depth: false, stencil: false, preserveDrawingBuffer: false };
    let gl: GL | null = canvas.getContext('webgl2', opts) as WebGL2RenderingContext | null;
    const gl2 = !!gl;
    if (!gl) gl = canvas.getContext('webgl', opts) as WebGLRenderingContext | null;
    const off = () => canvas.classList.add('is-off');
    if (!gl) return off();
    const g = gl;
    let internal: number, format: number, type: number;
    if (gl2) {
      const x = g as WebGL2RenderingContext;
      x.getExtension('EXT_color_buffer_float'); x.getExtension('OES_texture_float_linear');
      internal = x.RGBA16F; format = x.RGBA; type = x.HALF_FLOAT;
    } else {
      const hf = g.getExtension('OES_texture_half_float'); g.getExtension('OES_texture_half_float_linear');
      if (!hf) return off();
      internal = g.RGBA; format = g.RGBA; type = hf.HALF_FLOAT_OES;
    }
    const compile = (t: number, src: string) => {
      const s = g.createShader(t)!; g.shaderSource(s, src); g.compileShader(s);
      if (!g.getShaderParameter(s, g.COMPILE_STATUS)) throw new Error(g.getShaderInfoLog(s) || 'shader');
      return s;
    };
    let progs: Record<keyof typeof FS, { p: WebGLProgram; u: Record<string, WebGLUniformLocation | null> }>;
    try {
      const vs = compile(g.VERTEX_SHADER, VS);
      progs = Object.fromEntries(Object.entries(FS).map(([k, src]) => {
        const p = g.createProgram()!; g.attachShader(p, vs); g.attachShader(p, compile(g.FRAGMENT_SHADER, src));
        g.bindAttribLocation(p, 0, 'aPos'); g.linkProgram(p);
        const u: Record<string, WebGLUniformLocation | null> = {};
        for (let i = 0; i < g.getProgramParameter(p, g.ACTIVE_UNIFORMS); i++) { const n = g.getActiveUniform(p, i)!.name; u[n] = g.getUniformLocation(p, n); }
        return [k, { p, u }];
      })) as typeof progs;
    } catch { return off(); }

    g.bindBuffer(g.ARRAY_BUFFER, g.createBuffer());
    g.bufferData(g.ARRAY_BUFFER, new Float32Array([-1, -1, -1, 1, 1, 1, 1, -1]), g.STATIC_DRAW);
    g.bindBuffer(g.ELEMENT_ARRAY_BUFFER, g.createBuffer());
    g.bufferData(g.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), g.STATIC_DRAW);
    g.vertexAttribPointer(0, 2, g.FLOAT, false, 0, 0); g.enableVertexAttribArray(0);

    const fbo = (w: number, h: number): FBO => {
      const tex = g.createTexture()!; g.bindTexture(g.TEXTURE_2D, tex);
      for (const [k, v] of [[g.TEXTURE_MIN_FILTER, g.LINEAR], [g.TEXTURE_MAG_FILTER, g.LINEAR], [g.TEXTURE_WRAP_S, g.CLAMP_TO_EDGE], [g.TEXTURE_WRAP_T, g.CLAMP_TO_EDGE]]) g.texParameteri(g.TEXTURE_2D, k, v);
      g.texImage2D(g.TEXTURE_2D, 0, internal, w, h, 0, format, type, null);
      const fb = g.createFramebuffer()!; g.bindFramebuffer(g.FRAMEBUFFER, fb);
      g.framebufferTexture2D(g.FRAMEBUFFER, g.COLOR_ATTACHMENT0, g.TEXTURE_2D, tex, 0);
      g.viewport(0, 0, w, h); g.clearColor(0, 0, 0, 1); g.clear(g.COLOR_BUFFER_BIT);
      return { tex, fb, w, h };
    };
    const dbl = (w: number, h: number): Double => { const d = { read: fbo(w, h), write: fbo(w, h), swap() { const t = d.read; d.read = d.write; d.write = t; } }; return d; };
    const probe = fbo(4, 4); g.bindFramebuffer(g.FRAMEBUFFER, probe.fb);
    if (g.checkFramebufferStatus(g.FRAMEBUFFER) !== g.FRAMEBUFFER_COMPLETE) return off();

    let vel: Double, dye: Double, div: FBO, curl: FBO, pres: Double;
    const res = (base: number) => { const a = canvas.width / canvas.height; return a > 1 ? { w: Math.round(base * a), h: base } : { w: base, h: Math.round(base / a) }; };
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5) * 0.7;
      const w = Math.max(2, Math.floor(host.clientWidth * dpr)), h = Math.max(2, Math.floor(host.clientHeight * dpr));
      if (canvas.width === w && canvas.height === h && vel) return false;
      canvas.width = w; canvas.height = h;
      const s = res(112), d = res(448);
      vel = dbl(s.w, s.h); dye = dbl(d.w, d.h); div = fbo(s.w, s.h); curl = fbo(s.w, s.h); pres = dbl(s.w, s.h);
      return true;
    };
    const blit = (t: FBO | null) => {
      if (t) { g.viewport(0, 0, t.w, t.h); g.bindFramebuffer(g.FRAMEBUFFER, t.fb); } else { g.viewport(0, 0, g.drawingBufferWidth, g.drawingBufferHeight); g.bindFramebuffer(g.FRAMEBUFFER, null); }
      g.drawElements(g.TRIANGLES, 6, g.UNSIGNED_SHORT, 0);
    };
    let unit = 0;
    const bind = (t: FBO) => { g.activeTexture(g.TEXTURE0 + unit); g.bindTexture(g.TEXTURE_2D, t.tex); return unit++; };
    const use = (k: keyof typeof FS, texel: [number, number]) => { unit = 0; const pr = progs[k]; g.useProgram(pr.p); if (pr.u.texel) g.uniform2f(pr.u.texel, texel[0], texel[1]); return pr.u; };
    const splat = (x: number, y: number, dx: number, dy: number, c: [number, number, number], r = 0.0024) => {
      const a = canvas.width / canvas.height;
      let u = use('splat', [1 / vel.read.w, 1 / vel.read.h]);
      g.uniform1i(u.uTarget, bind(vel.read)); g.uniform1f(u.aspect, a); g.uniform2f(u.point, x, y); g.uniform3f(u.color, dx, dy, 0); g.uniform1f(u.radius, r); blit(vel.write); vel.swap();
      u = use('splat', [1 / dye.read.w, 1 / dye.read.h]);
      g.uniform1i(u.uTarget, bind(dye.read)); g.uniform1f(u.aspect, a); g.uniform2f(u.point, x, y); g.uniform3f(u.color, c[0], c[1], c[2]); g.uniform1f(u.radius, r * 1.15); blit(dye.write); dye.swap();
    };
    const step = (dt: number) => {
      const st: [number, number] = [1 / vel.read.w, 1 / vel.read.h];
      let u = use('curl', st); g.uniform1i(u.uVelocity, bind(vel.read)); blit(curl);
      u = use('vorticity', st); g.uniform1i(u.uVelocity, bind(vel.read)); g.uniform1i(u.uCurl, bind(curl)); g.uniform1f(u.strength, 22); g.uniform1f(u.dt, dt); blit(vel.write); vel.swap();
      u = use('divergence', st); g.uniform1i(u.uVelocity, bind(vel.read)); blit(div);
      u = use('clear', st); g.uniform1i(u.uTexture, bind(pres.read)); g.uniform1f(u.value, 0.8); blit(pres.write); pres.swap();
      u = use('pressure', st); g.uniform1i(u.uDivergence, bind(div));
      for (let i = 0; i < 16; i++) { unit = 1; g.uniform1i(u.uPressure, bind(pres.read)); blit(pres.write); pres.swap(); }
      u = use('gradient', st); g.uniform1i(u.uPressure, bind(pres.read)); g.uniform1i(u.uVelocity, bind(vel.read)); blit(vel.write); vel.swap();
      u = use('advect', st); g.uniform1i(u.uVelocity, bind(vel.read)); g.uniform1i(u.uSource, bind(vel.read)); g.uniform1f(u.dt, dt); g.uniform1f(u.dissipation, 0.985); blit(vel.write); vel.swap();
      u = use('advect', st); g.uniform1i(u.uVelocity, bind(vel.read)); g.uniform1i(u.uSource, bind(dye.read)); g.uniform1f(u.dt, dt); g.uniform1f(u.dissipation, 0.993); blit(dye.write); dye.swap();
    };
    let t = 0;
    const draw = () => { const u = use('display', [0, 0]); g.uniform1i(u.uDye, bind(dye.read)); g.uniform1f(u.t, t); blit(null); };
    const k = (c: [number, number, number], s: number): [number, number, number] => [c[0] * s, c[1] * s, c[2] * s];
    const seed = () => {
      splat(0.78, 0.38, -520, 300, k(TONES[0], 1.4), 0.016);
      splat(0.93, 0.74, -320, -260, k(TONES[2], 1.3), 0.012);
      splat(0.62, 0.14, 220, 420, k(TONES[1], 0.9), 0.009);
      splat(0.86, 0.12, -120, 360, k(TONES[0], 0.8), 0.008);
    };

    resize(); seed();
    // 软件渲染（无 GPU）下流体会拖垮主线程：只画一帧静态画面
    const dbg = g.getExtension('WEBGL_debug_renderer_info');
    const renderer = dbg ? String(g.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : '';
    const software = /swiftshader|llvmpipe|software|basic render/i.test(renderer);
    const still = () => { for (let i = 0; i < 60; i++) step(0.016); draw(); canvas.classList.add('is-still'); };
    if (reduce || software) { still(); return; }

    let last: { x: number; y: number } | null = null;
    let queue: { x: number; y: number; dx: number; dy: number; c: [number, number, number]; r?: number }[] = [];
    let tone = 0;
    const onMove = (e: PointerEvent) => {
      const r = host.getBoundingClientRect();
      if (e.clientY > r.bottom || e.clientY < r.top) { last = null; return; }
      const x = (e.clientX - r.left) / r.width, y = 1 - (e.clientY - r.top) / r.height;
      if (last) {
        const dx = (x - last.x) * 6200, dy = (y - last.y) * 6200;
        if (Math.abs(dx) + Math.abs(dy) > 0.6) { tone = (tone + 0.004) % TONES.length; queue.push({ x, y, dx, dy, c: k(TONES[Math.floor(tone)], Math.min(0.9, 0.14 + Math.hypot(dx, dy) / 4200)) }); }
      }
      last = { x, y };
    };
    window.addEventListener('pointermove', onMove, { passive: true });

    let visible = true;
    const io = new IntersectionObserver((es) => { visible = es[0].isIntersecting; }, { threshold: 0 });
    io.observe(host);

    let raf = 0, prev = performance.now(), nextAmb = prev + 1400;
    let slow = 0, frames = 0;
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (document.hidden || !visible) { prev = now; return; }
      const spent = now - prev;
      // 帧耗时持续过长（低端设备）：停在当前画面
      if (++frames > 20 && spent > 48) { if (++slow > 24) { cancelAnimationFrame(raf); window.removeEventListener('pointermove', onMove); canvas.classList.add('is-still'); return; } } else slow = Math.max(0, slow - 1);
      const dt = Math.min(spent / 1000, 0.0167); prev = now; t = (t + 0.37) % 100;
      if (resize()) seed();
      if (now > nextAmb) {
        nextAmb = now + 2400 + Math.random() * 1800;
        const x = 0.55 + Math.random() * 0.4, y = Math.random() < 0.5 ? 0.06 : 0.94;
        queue.push({ x, y, dx: (Math.random() - 0.5) * 300, dy: (0.5 - y) * 420, c: k(TONES[Math.floor(Math.random() * 3)], 0.8), r: 0.005 });
      }
      // 常驻光源：在右侧缓慢游走，保证没有鼠标时首屏也在呼吸
      const s = now / 1000;
      const ax = 0.74 + Math.sin(s * 0.23) * 0.14, ay = 0.5 + Math.sin(s * 0.31 + 1.2) * 0.3;
      queue.push({ x: ax, y: ay, dx: Math.cos(s * 0.5) * 60, dy: Math.sin(s * 0.43) * 60, c: k(TONES[Math.floor((s / 6) % 3)], 0.05), r: 0.006 });
      for (const q of queue) splat(q.x, q.y, q.dx, q.dy, q.c, q.r);
      queue = [];
      step(dt); draw();
    };
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); io.disconnect(); window.removeEventListener('pointermove', onMove); };
  }, []);

  return <canvas ref={ref} className="hero-ink" aria-hidden="true" />;
}
