import { FACTS, INTERPS, SOURCES, eventById, factById, interpById, sourceById } from '../data/content';
import type { EvidenceStatus, Fact, Interpretation, ReviewStatus } from '../data/types';
import type { State } from './store';

/*
 * 发布与失效规则（方案 7.4）
 * - 来源缺失：保留能核实的内容，停止依赖缺失材料的解释
 * - 来源更正：旧版本保留更正提示，所有依赖解释转为待复核
 * - 撤回：详情、观察卡、追问同步停止引用
 */

const vnum = (v: string | undefined) => (v ? Number(v.replace(/\D/g, '')) || 0 : 0);

export function currentVersion(s: State, eventId: string) {
  return s.version[eventId] ?? 'v1';
}

export type FactState = 'active' | 'corrected' | 'hidden' | 'missing';

export function factState(s: State, f: Fact): FactState {
  const v = vnum(currentVersion(s, f.eventId));
  if (f.introducedIn && v < vnum(f.introducedIn)) return 'hidden';
  if (f.supersededIn && v >= vnum(f.supersededIn)) return 'corrected';
  if (f.sourceIds.length === 0 || f.sourceIds.every((id) => s.sourceMissing[id] || !sourceById(id))) return 'missing';
  return 'active';
}

export type Effective = {
  status: ReviewStatus | 'hidden';
  reason: string;
};

export function interpEffective(s: State, i: Interpretation): Effective {
  const v = vnum(currentVersion(s, i.eventId));
  if (i.introducedIn && v < vnum(i.introducedIn)) return { status: 'hidden', reason: '尚未发布的版本' };
  const review = s.review[i.id] ?? 'published';
  if (review === 'withdrawn') return { status: 'withdrawn', reason: '该解释已被撤回（模拟审核），不再作为依据展示。' };
  if (i.supersededIn && v >= vnum(i.supersededIn))
    return { status: 'superseded', reason: `来源已更正（${currentVersion(s, i.eventId)}），原解释被替代，依赖它的结论需要复核。` };
  const facts = i.factIds.map(factById).filter(Boolean) as Fact[];
  const missing = facts.filter((f) => factState(s, f) === 'missing');
  if (missing.length)
    return {
      status: 'blocked',
      reason: `依赖的来源暂不可用（${missing.flatMap((f) => f.sourceIds).join('、')}），已停止展示这条解释。`,
    };
  if (facts.some((f) => factState(s, f) === 'corrected'))
    return { status: 'needs_review', reason: '所依赖的事实已被更正，解释待复核。' };
  if (review !== 'published') return { status: review, reason: review === 'needs_review' ? '解释待复核（模拟审核）。' : '未通过发布门禁。' };
  return { status: 'published', reason: '' };
}

export const isLive = (e: Effective) => e.status === 'published';

export function interpLive(s: State, id: string) {
  const i = interpById(id);
  return i ? isLive(interpEffective(s, i)) : false;
}

/** 证据抽屉显示的状态标签：有原文支持 / 仅有转述 / 待核实 / 已更正 */
export function evidenceLabel(st: EvidenceStatus): string {
  return { original: '有原文支持', relayed: '仅有转述', unverified: '待核实', corrected: '已更正' }[st];
}

// ---------- 发布门禁（方案 7.4 审核通过条件） ----------

const TRADE_RE = /(买入|卖出|加仓|减仓|仓位|目标价|抄底|止损|满仓|必涨|稳赚|保本|收益率将)/;

export interface GateCheck {
  label: string;
  ok: boolean;
  detail: string;
}

export function publishGate(s: State, i: Interpretation): GateCheck[] {
  const facts = i.factIds.map(factById).filter(Boolean) as Fact[];
  const srcs = facts.flatMap((f) => f.sourceIds.map(sourceById)).filter(Boolean);
  const missing = facts.filter((f) => factState(s, f) === 'missing');
  const corrected = facts.filter((f) => factState(s, f) === 'corrected');
  const ev = eventById(i.eventId);
  return [
    { label: '关键事实均有可核对来源', ok: facts.length > 0 && missing.length === 0, detail: missing.length ? `缺失：${missing.map((f) => f.id).join('、')}` : `${facts.length} 条事实 / ${new Set(srcs.map((x) => x!.id)).size} 个来源` },
    { label: '单位和期间一致，无被更正事实', ok: corrected.length === 0, detail: corrected.length ? `已更正：${corrected.map((f) => f.id).join('、')}` : '期间字段齐全' },
    { label: '事实与分析分层，条件与局限不缺失', ok: i.conditions.length > 0 && i.limitations.length > 0, detail: `${i.conditions.length} 个条件` },
    { label: '无交易指令或收益承诺', ok: !TRADE_RE.test(i.text), detail: '关键词与人工双检（模拟）' },
    { label: 'AI 标识及来源时间齐全', ok: srcs.every((x) => !!x!.publishedAt) && !!ev, detail: '标识由页面模板统一输出' },
  ];
}

export const gatePasses = (s: State, i: Interpretation) => publishGate(s, i).every((c) => c.ok);

// ---------- 汇总：工作台概览 ----------

export function overview(s: State) {
  const eff = INTERPS.map((i) => interpEffective(s, i)).filter((e) => e.status !== 'hidden');
  return {
    live: eff.filter(isLive).length,
    stopped: eff.filter((e) => !isLive(e)).length,
    facts: FACTS.length,
    sources: SOURCES.length,
    realSources: SOURCES.filter((x) => x.kind === 'real').length,
  };
}
