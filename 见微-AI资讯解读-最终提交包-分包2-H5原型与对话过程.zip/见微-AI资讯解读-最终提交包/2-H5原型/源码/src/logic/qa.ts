import { eventById, factById } from '../data/content';
import type { EventItem, QA, Term } from '../data/types';
import { factState, interpLive } from './gate';
import type { State } from './store';

/*
 * 受限追问：预设问答演示。
 * 1. 预设问题及其明确的同义问法 → 已核对答案
 * 2. 「X 是什么意思」且 X 是本篇的术语 → 编辑部撰写的术语解释
 * 3. 明确的交易意图（买卖、仓位、目标价、推荐个股…）→ 边界反馈
 * 4. 其他 → 当前离线样本未覆盖，不编造
 * 审阅 C：旧版把「收益」当作交易词，「投资收益是什么意思」被误拒。现在只认「动作 + 对象」形式的交易意图。
 * 用户输入只作为数据处理；输入里的「忽略规则」之类文字不改变任何处理权限。
 */

export type Answer =
  | { kind: 'answer'; qa: QA }
  | { kind: 'term'; term: Term }
  | { kind: 'stopped'; qa: QA; reason: string }
  | { kind: 'boundary' }
  | { kind: 'uncovered' };

const ADVICE_RE = new RegExp(
  [
    '(该|要|能|可以|值得|适合|现在|何时|什么时候|是否).{0,6}(买入?|卖出?|加仓|减仓|清仓|抄底|建仓|入场|上车|梭哈|止损|止盈)',
    '(买|卖)(哪|什么|吗|不)',
    '(推荐|荐).{0,4}(股|票|基金)',
    '哪(只|个|支).{0,4}(股|票|基金)',
    '目标价', '仓位', '会不会涨', '能不能涨', '还能涨', '会涨吗', '能涨吗', '涨到多少', '跌到多少', '稳赚', '收益率能到',
  ].join('|'),
);

const MEANING_RE = /(是什么意思|什么意思|是什么|指什么|怎么理解|啥意思|是啥|的含义|解释一下|说明一下)/;

export const normalize = (t: string) => t.replace(/[\s？?。！!，,、“”"'：:]/g, '').toLowerCase();

export const isAdvice = (text: string) => ADVICE_RE.test(normalize(text));

/** 当前版本下可以出现的预设问题（依赖事实不属于当前版本的问题不出现） */
export function visibleQA(s: State, ev: EventItem): QA[] {
  return ev.qa.filter((q) => q.factIds.every((id) => {
    const f = factById(id);
    return f && factState(s, f) !== 'hidden';
  }));
}

function findTerm(ev: EventItem, n: string): Term | undefined {
  for (const t of ev.terms ?? []) {
    const names = [t.term, ...(t.aliases ?? [])].map(normalize).filter(Boolean);
    const hit = names.find((x) => n.includes(x));
    if (!hit) continue;
    const rest = n.replace(hit, '');
    if (rest === '' || MEANING_RE.test(rest)) return t;
  }
  return undefined;
}

export function ask(s: State, eventId: string, text: string): Answer {
  const ev = eventById(eventId);
  if (!ev) return { kind: 'uncovered' };
  const n = normalize(text);
  if (!n) return { kind: 'uncovered' };
  const hit = visibleQA(s, ev).find((q) => [q.q, ...(q.aliases ?? [])].some((x) => normalize(x) === n));
  if (hit) return resolveQA(s, hit);
  if (isAdvice(text)) return { kind: 'boundary' };
  const term = findTerm(ev, n);
  if (term) return { kind: 'term', term };
  return { kind: 'uncovered' };
}

export function resolveQA(s: State, qa: QA): Answer {
  const deadInterp = qa.interpIds.find((id) => !interpLive(s, id));
  if (deadInterp) return { kind: 'stopped', qa, reason: '这条回答依赖的解释已被撤回、暂停或待复核，暂不提供。' };
  const deadFact = qa.factIds.map(factById).find((f) => f && factState(s, f) !== 'active');
  if (deadFact) return { kind: 'stopped', qa, reason: '这条回答依赖的事实已被更正或来源暂不可用，暂不提供。' };
  return { kind: 'answer', qa };
}
