import { type CuratedCompany, type FinLine, type FinMetric, FIN_METRIC_LABEL } from '../data/earnings2026';

/*
 * 财报对比（v0.8）：这一期比上一期（环比）、比去年同期（同比），变好了还是变差了。
 *
 * 口径规则，全部写在页面上：
 * - A 股定期报告是累计数。单季 = 本期累计 − 上期累计（一季度就是一季报本身），属于推算值。
 * - 「改善 / 变差」只看同比：环比受季节影响大（春节、年末集中确认收入），单独看环比容易误判。
 * - 同比变动在 ±3% 以内算「基本持平」；分母为负（去年亏损）时不算百分比，改写成「扭亏」「亏损收窄」等文字。
 * - 解释差异的规则都是确定性的：用了哪些数、阈值是多少，页面上都能看到，不让模型自由发挥。
 */

export const FLAT = 3; // ±3% 以内算基本持平
export const METRICS: FinMetric[] = ['rev', 'np', 'kf'];

export interface Quarter {
  year: number;
  q: 1 | 2 | 3 | 4;
  /** 单季值（元）；缺数据为 null */
  v: Record<FinMetric, number | null>;
  /** 累计值（元），即报告原文的数 */
  cum: Record<FinMetric, number | null>;
  /** 单季是否由累计相减推算 */
  derived: boolean;
  noticeDate?: string;
}

export const qLabel = (year: number, q: number) => `${year} 年${['一', '二', '三', '四'][q - 1]}季度`;
export const qShort = (year: number, q: number) => `${String(year).slice(2)}Q${q}`;
export const cumLabel = (q: number) => ['一季度', '上半年', '前三季度', '全年'][q - 1];

export interface Change {
  /** 百分比；分母≤0 时为 null，改看 note */
  pct: number | null;
  note?: '扭亏为盈' | '由盈转亏' | '亏损收窄' | '亏损扩大' | '无可比数据';
  dir: 'up' | 'down' | 'flat' | 'na';
}

export function change(cur: number | null, base: number | null): Change {
  if (cur == null || base == null) return { pct: null, note: '无可比数据', dir: 'na' };
  if (base > 0 && cur < 0) return { pct: null, note: '由盈转亏', dir: 'down' };
  if (base > 0) {
    const pct = ((cur - base) / base) * 100;
    return { pct, dir: Math.abs(pct) < FLAT ? 'flat' : pct > 0 ? 'up' : 'down' };
  }
  if (base < 0 && cur >= 0) return { pct: null, note: '扭亏为盈', dir: 'up' };
  if (base < 0) return { pct: null, note: cur > base ? '亏损收窄' : '亏损扩大', dir: cur > base ? 'up' : 'down' };
  if (cur < 0) return { pct: null, note: '由盈转亏', dir: 'down' };
  return { pct: null, note: '无可比数据', dir: 'na' };
}

export const fmtPct = (c: Change) => (c.pct == null ? c.note ?? '—' : `${c.pct > 0 ? '+' : c.pct < 0 ? '−' : ''}${Math.abs(c.pct).toFixed(1)}%`);
export const fmtYi = (v: number | null, d = 1) => (v == null ? '—' : `${(v / 1e8).toFixed(Math.abs(v) >= 1e10 ? d : 2)} 亿`);
export const VERDICT: Record<Change['dir'], string> = { up: '改善', down: '变差', flat: '基本持平', na: '无法比较' };

// ---------- 由累计数得到单季 ----------

export interface CumRow {
  year: number;
  q: 1 | 2 | 3 | 4;
  rev: number | null;
  np: number | null;
  kf: number | null;
  noticeDate?: string;
}

/** 累计 → 单季。一季度直接用；其他季度需要同一年上一期的累计数，缺了就是 null（不硬凑） */
export function toQuarters(rows: CumRow[]): Quarter[] {
  const key = (y: number, q: number) => `${y}-${q}`;
  const m = new Map(rows.map((r) => [key(r.year, r.q), r]));
  const out: Quarter[] = [];
  for (const r of [...rows].sort((a, b) => a.year - b.year || a.q - b.q)) {
    const prev = r.q > 1 ? m.get(key(r.year, r.q - 1)) : undefined;
    const v = {} as Record<FinMetric, number | null>;
    for (const k of METRICS) {
      const c = r[k];
      v[k] = c == null ? null : r.q === 1 ? c : prev && prev[k] != null ? c - prev[k]! : null;
    }
    out.push({ year: r.year, q: r.q, v, cum: { rev: r.rev, np: r.np, kf: r.kf }, derived: r.q > 1, noticeDate: r.noticeDate });
  }
  return out;
}

export const findQ = (qs: Quarter[], year: number, q: number) => qs.find((x) => x.year === year && x.q === q);
export const prevOf = (year: number, q: number): [number, number] => (q === 1 ? [year - 1, 4] : [year, q - 1]);

// ---------- 一组对比 ----------

export interface MetricCompare {
  metric: FinMetric;
  cur: number | null;
  prevQ: number | null;
  sameQ: number | null;
  qoq: Change;
  yoy: Change;
  /** 累计同比（报告原文口径） */
  cumCur: number | null;
  cumPrev: number | null;
  cumYoy: Change;
  /** 去年同一季度的环比，用来判断季节性 */
  lastYearQoq: Change;
  /** 上一季度的同比，用来判断增速拐点 */
  prevYoy: Change;
}

export interface Comparison {
  year: number;
  q: number;
  metrics: Record<FinMetric, MetricCompare>;
}

export function compare(qs: Quarter[], year: number, q: number): Comparison | null {
  const cur = findQ(qs, year, q);
  if (!cur) return null;
  const [py, pq] = prevOf(year, q);
  const prev = findQ(qs, py, pq);
  const same = findQ(qs, year - 1, q);
  const [lpy, lpq] = prevOf(year - 1, q);
  const lastPrev = findQ(qs, lpy, lpq);
  const prevSame = findQ(qs, py - 1, pq);
  const metrics = {} as Record<FinMetric, MetricCompare>;
  for (const k of METRICS) {
    metrics[k] = {
      metric: k,
      cur: cur.v[k],
      prevQ: prev?.v[k] ?? null,
      sameQ: same?.v[k] ?? null,
      qoq: change(cur.v[k], prev?.v[k] ?? null),
      yoy: change(cur.v[k], same?.v[k] ?? null),
      cumCur: cur.cum[k],
      cumPrev: same?.cum[k] ?? null,
      cumYoy: change(cur.cum[k], same?.cum[k] ?? null),
      lastYearQoq: change(same?.v[k] ?? null, lastPrev?.v[k] ?? null),
      prevYoy: change(prev?.v[k] ?? null, prevSame?.v[k] ?? null),
    };
  }
  return { year, q, metrics };
}

/** 最新一期：有单季值的最后一个季度 */
export function latest(qs: Quarter[]): [number, number] | null {
  const ok = qs.filter((x) => x.v.rev != null);
  const l = ok[ok.length - 1];
  return l ? [l.year, l.q] : null;
}

// ---------- 看懂这处差异：确定性规则 ----------

export type FininsightKind = 'seasonal' | 'lowBase' | 'divergence' | 'nonRecurring' | 'turn';

export interface FinInsight {
  kind: FininsightKind;
  title: string;
  text: string;
  /** 用到的数（给页面展示依据） */
  uses: string[];
}

const p = (c: Change) => fmtPct(c);

export function explain(c: Comparison): FinInsight[] {
  const out: FinInsight[] = [];
  const { rev, np, kf } = c.metrics;
  const ql = qLabel(c.year, c.q);

  // 1. 季节性：环比和同比方向相反或差得很远，而去年同一季度的环比也是同方向
  const s = rev;
  if (s.qoq.pct != null && s.yoy.pct != null && s.lastYearQoq.pct != null) {
    // 环比会误导：方向和同比相反，或幅度≥20% 且同比不到它的一半
    const misleading = (s.qoq.dir !== s.yoy.dir && s.qoq.dir !== 'flat') || (Math.abs(s.qoq.pct) >= 20 && Math.abs(s.yoy.pct) < Math.abs(s.qoq.pct) / 2);
    const sameSign = Math.sign(s.qoq.pct) === Math.sign(s.lastYearQoq.pct);
    if (misleading && sameSign && Math.abs(s.lastYearQoq.pct) >= 10) {
      out.push({
        kind: 'seasonal',
        title: '环比大起大落，多半是季节性',
        text: `${ql}营业收入环比 ${p(s.qoq)}，但去年同一季度环比也是 ${p(s.lastYearQoq)}——每年这个时候都这样。判断好坏应看同比：${p(s.yoy)}。`,
        uses: ['本季环比', '去年同季环比', '本季同比'],
      });
    }
  }

  // 2. 低基数：同比涨幅很大，而去年同季本身比去年上一季明显偏低
  for (const m of [np, rev]) {
    if (m.yoy.pct != null && m.yoy.pct >= 50 && m.lastYearQoq.pct != null && m.lastYearQoq.pct <= -20) {
      out.push({
        kind: 'lowBase',
        title: `${FIN_METRIC_LABEL[m.metric]}同比大涨，一部分是去年基数低`,
        text: `去年同季的${FIN_METRIC_LABEL[m.metric]}比它的上一季少了 ${Math.abs(m.lastYearQoq.pct).toFixed(1)}%，是个低点；拿今年和这个低点比，同比才会到 ${p(m.yoy)}。和上一季比是 ${p(m.qoq)}。`,
        uses: ['本季同比', '去年同季环比', '本季环比'],
      });
      break;
    }
  }

  // 3. 收入和利润走势不一致
  if (rev.yoy.pct != null && np.yoy.pct != null) {
    const diff = np.yoy.pct - rev.yoy.pct;
    if (rev.yoy.dir !== np.yoy.dir && rev.yoy.dir !== 'flat' && np.yoy.dir !== 'flat') {
      out.push({
        kind: 'divergence',
        title: np.yoy.dir === 'up' ? '收入降、利润升' : '收入升、利润降',
        text: `${ql}营业收入同比 ${p(rev.yoy)}，归母净利润同比 ${p(np.yoy)}，方向相反。利润变化不是靠卖得更多，要去看成本、费用或一次性收益。`,
        uses: ['收入同比', '利润同比'],
      });
    } else if (rev.yoy.dir === 'up' && diff <= -10) {
      out.push({
        kind: 'divergence',
        title: '增收不同步增利',
        text: `${ql}营业收入同比 ${p(rev.yoy)}，归母净利润只增长 ${p(np.yoy)}，比收入慢了 ${Math.abs(diff).toFixed(1)} 个百分点：多卖的部分没有等比例变成利润。`,
        uses: ['收入同比', '利润同比'],
      });
    } else if (diff >= 30) {
      out.push({
        kind: 'divergence',
        title: '利润增速远高于收入',
        text: `${ql}营业收入同比 ${p(rev.yoy)}，归母净利润同比 ${p(np.yoy)}。利润跑得比收入快很多，通常来自毛利率提升、费用下降、低基数或一次性收益，要逐项看。`,
        uses: ['收入同比', '利润同比'],
      });
    }
  }

  // 4. 非经常性损益：归母和扣非的同比差得远
  if (np.yoy.pct != null && kf.yoy.pct != null && Math.abs(np.yoy.pct - kf.yoy.pct) >= 10) {
    const nr = (x: MetricCompare, y: MetricCompare) => (x.cur != null && y.cur != null ? x.cur - y.cur : null);
    const nrNow = nr(np, kf);
    const nrLast = np.sameQ != null && kf.sameQ != null ? np.sameQ - kf.sameQ : null;
    out.push({
      kind: 'nonRecurring',
      title: '一次性收益在左右利润增速',
      text: `归母净利润同比 ${p(np.yoy)}，扣除非经常性损益后是 ${p(kf.yoy)}。${nrNow != null && nrLast != null ? `非经常性损益（归母 − 扣非）本季约 ${fmtYi(nrNow, 2)}，去年同季约 ${fmtYi(nrLast, 2)}。` : ''}看主业，扣非更可靠。`,
      uses: ['归母同比', '扣非同比'],
    });
  }

  // 5. 增速拐点：上一季同比为正、这一季转负（或反过来）
  if (rev.prevYoy.dir !== 'na' && rev.yoy.dir !== 'na' && rev.prevYoy.dir !== 'flat' && rev.yoy.dir !== 'flat' && rev.prevYoy.dir !== rev.yoy.dir) {
    out.push({
      kind: 'turn',
      title: rev.yoy.dir === 'down' ? '收入同比由增转降' : '收入同比由降转增',
      text: `上一季营业收入同比 ${p(rev.prevYoy)}，这一季 ${p(rev.yoy)}。单看一个季度不能说明趋势，下一期要看是否延续。`,
      uses: ['上季同比', '本季同比'],
    });
  }
  return out.sort((a, b) => PRIORITY.indexOf(a.kind) - PRIORITY.indexOf(b.kind));
}

/** 多条差异同时出现时，先说最能回答「变好还是变差」的那条 */
export const PRIORITY: FininsightKind[] = ['lowBase', 'divergence', 'seasonal', 'nonRecurring', 'turn'];

/** 一句话结论：先说同比（改善/变差），再点最重要的一条差异 */
export function headline(c: Comparison, ins: FinInsight[]): string {
  const { rev, np } = c.metrics;
  const part = (label: string, m: MetricCompare) => `${label}同比${m.yoy.pct == null ? m.yoy.note : m.yoy.dir === 'flat' ? `基本持平（${fmtPct(m.yoy)}）` : `${m.yoy.dir === 'up' ? '增长' : '下降'} ${Math.abs(m.yoy.pct).toFixed(1)}%`}`;
  const first = `${qLabel(c.year, c.q)}单季${part('收入', rev)}，${part('利润', np)}`;
  const key = ins[0];
  return key ? `${first}；${key.title}。` : `${first}。`;
}

// ---------- 核对过的公司：原文行 → 累计数 ----------

/** 原文里的半年报 + 一季报 → 四个累计点（今年 Q1、H1，去年 Q1、H1） */
export function cumFromCurated(c: CuratedCompany): CumRow[] {
  const get = (kind: 'H1' | 'Q1', m: FinMetric): FinLine | undefined => {
    const r = c.reports.find((x) => x.kind === kind);
    return c.lines.find((l) => l.reportId === r?.id && l.metric === m);
  };
  const row = (year: number, q: 1 | 2, which: 'cur' | 'prev'): CumRow => {
    const kind = q === 1 ? 'Q1' : 'H1';
    const r = c.reports.find((x) => x.kind === kind);
    return { year, q, rev: get(kind, 'rev')?.[which] ?? null, np: get(kind, 'np')?.[which] ?? null, kf: get(kind, 'kf')?.[which] ?? null, noticeDate: which === 'cur' ? r?.noticeDate : undefined };
  };
  return [row(2025, 1, 'prev'), row(2025, 2, 'prev'), row(2026, 1, 'cur'), row(2026, 2, 'cur')];
}

// ---------- 数据接口（东方财富 F10 主要指标）→ 累计数 ----------

export interface ApiFinRow {
  SECUCODE: string;
  SECURITY_NAME_ABBR: string;
  REPORT_DATE: string;
  REPORT_DATE_NAME?: string;
  NOTICE_DATE?: string;
  TOTALOPERATEREVE: number | null;
  PARENTNETPROFIT: number | null;
  KCFJCXSYJLR: number | null;
  DJD_TOI_YOY?: number | null;
  DJD_TOI_QOQ?: number | null;
  DJD_DPNP_YOY?: number | null;
  DJD_DPNP_QOQ?: number | null;
  XSMLL?: number | null;
}

export function cumFromApi(rows: ApiFinRow[]): CumRow[] {
  const out: CumRow[] = [];
  for (const r of rows) {
    const m = /^(\d{4})-(\d{2})/.exec(r.REPORT_DATE);
    if (!m) continue;
    const q = (Number(m[2]) / 3) as 1 | 2 | 3 | 4;
    if (![1, 2, 3, 4].includes(q)) continue;
    out.push({ year: Number(m[1]), q, rev: r.TOTALOPERATEREVE ?? null, np: r.PARENTNETPROFIT ?? null, kf: r.KCFJCXSYJLR ?? null, noticeDate: r.NOTICE_DATE?.slice(0, 10) });
  }
  return out;
}

/**
 * 自检：自己由累计数推算的单季同比 / 环比，和接口直接给的单季字段（DJD_*）比一比。
 * 差距超过 0.5 个百分点就提示，说明两边口径或数据有出入。
 */
export function selfCheck(rows: ApiFinRow[], qs: Quarter[]): { ok: number; bad: string[] } {
  let ok = 0;
  const bad: string[] = [];
  for (const r of rows) {
    const m = /^(\d{4})-(\d{2})/.exec(r.REPORT_DATE);
    if (!m) continue;
    const year = Number(m[1]);
    const q = Number(m[2]) / 3;
    const c = compare(qs, year, q);
    if (!c) continue;
    const pairs: [string, Change, number | null | undefined][] = [
      ['收入同比', c.metrics.rev.yoy, r.DJD_TOI_YOY],
      ['收入环比', c.metrics.rev.qoq, r.DJD_TOI_QOQ],
      ['利润同比', c.metrics.np.yoy, r.DJD_DPNP_YOY],
    ];
    for (const [label, mine, theirs] of pairs) {
      if (mine.pct == null || theirs == null) continue;
      if (Math.abs(mine.pct - theirs) <= 0.5) ok++;
      else bad.push(`${qShort(year, q)} ${label}：推算 ${mine.pct.toFixed(1)}%，接口 ${theirs.toFixed(1)}%`);
    }
  }
  return { ok, bad };
}

/** 原文与接口的累计数对照：差异 ≤0.01% 视为一致 */
export function crossCheck(c: CuratedCompany, rows: ApiFinRow[]) {
  const api = cumFromApi(rows);
  const mine = cumFromCurated(c);
  const res: { label: string; metric: FinMetric; mine: number; api: number; same: boolean }[] = [];
  for (const r of mine) {
    const a = api.find((x) => x.year === r.year && x.q === r.q);
    if (!a) continue;
    for (const k of METRICS) {
      if (r[k] == null || a[k] == null) continue;
      res.push({ label: `${r.year} ${cumLabel(r.q)}`, metric: k, mine: r[k]!, api: a[k]!, same: Math.abs(r[k]! - a[k]!) / Math.abs(r[k]!) < 0.0001 });
    }
  }
  return res;
}
