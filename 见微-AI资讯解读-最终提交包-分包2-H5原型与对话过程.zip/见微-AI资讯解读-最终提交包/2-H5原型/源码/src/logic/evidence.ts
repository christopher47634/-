import { EVIDENCE_REFS, INSIGHTS, METRICS, factById, interpById, sourceById } from '../data/content';
import type { DifferenceInsight, EventItem, EvidenceRef, InsightMetric, Interpretation } from '../data/types';
import { type Effective, currentVersion, factState, interpEffective, isLive } from './gate';
import type { State } from './store';

/*
 * 逐项证据的状态判断（v0.6）
 * 原则：先按事件当前版本选卡，再逐条检查声明过的依赖。
 * 任何一条找不到都算问题——不能先 filter(Boolean) 再说「依据齐全」。
 * 来源可用性（模拟缺失）、编辑审核状态、外链定位能力三件事分开：
 * 外链不能定位不影响已核验的事实；事实失效也不只是藏起跳转按钮。
 */

// ---------- 单条引用 ----------

export type RefStatus = 'verified' | 'paraphrase' | 'pending' | 'sourceMissing' | 'versionMismatch' | 'notFound';

export interface RefState {
  id: string;
  ref?: EvidenceRef;
  status: RefStatus;
  /** 可以作为这个数字的有效证据 */
  usable: boolean;
  reason: string;
}

export function refState(s: State, id: string, expectFactId?: string): RefState {
  const ref = EVIDENCE_REFS.find((r) => r.id === id);
  if (!ref) return { id, status: 'notFound', usable: false, reason: `引用 ${id} 不存在` };
  const src = sourceById(ref.sourceId);
  if (!src) return { id, ref, status: 'notFound', usable: false, reason: `来源 ${ref.sourceId} 不存在` };
  if (expectFactId && ref.factId !== expectFactId) return { id, ref, status: 'notFound', usable: false, reason: `引用属于 ${ref.factId}，不是这个数字的事实` };
  if (s.sourceMissing[ref.sourceId]) return { id, ref, status: 'sourceMissing', usable: false, reason: '来源暂不可用（模拟）' };
  if (ref.sourceVersion !== src.docVersion) return { id, ref, status: 'versionMismatch', usable: false, reason: `摘录核对的是「${ref.sourceVersion}」，与当前来源版本「${src.docVersion}」不一致` };
  if (ref.verification !== 'verified' || !ref.checkedAt) return { id, ref, status: 'pending', usable: false, reason: '摘录尚未核对' };
  if (ref.excerptKind === 'paraphrase') return { id, ref, status: 'paraphrase', usable: false, reason: '只有转述，没有原文摘录' };
  return { id, ref, status: 'verified', usable: true, reason: '' };
}

export const REF_LABEL: Record<RefStatus, string> = {
  verified: '已核对原文摘录',
  paraphrase: '仅有转述',
  pending: '待核对',
  sourceMissing: '来源暂不可用',
  versionMismatch: '版本不一致',
  notFound: '引用无效',
};

// ---------- 单个指标 ----------

export type MetricStatus = 'verified' | 'partial' | 'weak' | 'corrected' | 'unavailable' | 'invalid';

export interface MetricState {
  metric?: InsightMetric;
  id: string;
  status: MetricStatus;
  /** 可以作为有效事实展示 */
  usable: boolean;
  refs: RefState[];
  reason: string;
}

/** 只认「说明这个数字」的引用：metricKey 以 .reason 结尾的是解释性引用，不单独支撑数字 */
const isValueRef = (r?: EvidenceRef) => !!r && !r.metricKey.endsWith('.reason');

export function metricState(s: State, id: string, eventId?: string): MetricState {
  const metric = METRICS.find((m) => m.id === id);
  if (!metric) return { id, status: 'invalid', usable: false, refs: [], reason: `指标 ${id} 不存在` };
  if (eventId && metric.eventId !== eventId) return { id, metric, status: 'invalid', usable: false, refs: [], reason: '指标不属于这条解读' };
  const fact = factById(metric.factId);
  if (!fact) return { id, metric, status: 'invalid', usable: false, refs: [], reason: `事实 ${metric.factId} 不存在` };
  if (fact.eventId !== metric.eventId) return { id, metric, status: 'invalid', usable: false, refs: [], reason: '事实不属于这条解读' };
  const refs = metric.evidenceRefIds.map((r) => refState(s, r, metric.factId));
  const fs = factState(s, fact);
  if (fs === 'hidden') return { id, metric, status: 'invalid', usable: false, refs, reason: '这项数字不属于当前版本' };
  if (fs === 'corrected') return { id, metric, status: 'corrected', usable: false, refs, reason: '这项数字已被更正，旧值只作对照' };
  const broken = refs.filter((r) => r.status === 'notFound');
  if (broken.length) return { id, metric, status: 'invalid', usable: false, refs, reason: broken.map((b) => b.reason).join('；') };
  const valueRefs = refs.filter((r) => isValueRef(r.ref));
  const ok = valueRefs.filter((r) => r.usable);
  if (valueRefs.length === 0) return { id, metric, status: 'invalid', usable: false, refs, reason: '没有直接支撑这个数字的引用' };
  if (ok.length === 0) {
    if (valueRefs.some((r) => r.status === 'paraphrase' || r.status === 'pending'))
      return { id, metric, status: 'weak', usable: false, refs, reason: '只有转述或未核对的材料，不作为已核验数字展示' };
    return { id, metric, status: 'unavailable', usable: false, refs, reason: valueRefs.map((r) => r.reason).filter(Boolean)[0] ?? '没有可用来源' };
  }
  if (ok.length < valueRefs.length) return { id, metric, status: 'partial', usable: true, refs, reason: `${valueRefs.length - ok.length} 条来源不可用，其余来源仍支持这个数字` };
  return { id, metric, status: 'verified', usable: true, refs, reason: '' };
}

// ---------- 卡片 ----------

export interface InterpView {
  id: string;
  interp?: Interpretation;
  eff: Effective;
  live: boolean;
}

export type InsightView =
  | { kind: 'none' }
  | { kind: 'unavailable'; insight?: DifferenceInsight; version: string; reason: string; problems: string[] }
  | {
      kind: 'card';
      insight: DifferenceInsight;
      version: string;
      metrics: MetricState[];
      interps: InterpView[];
      /** 解释是否可以显示：解释本身在线，且它依赖的指标都有效 */
      explain: { live: boolean; reason: string };
      degraded: boolean;
    };

/** 静态校验：声明的每个依赖都要存在、属于同一事件。返回问题清单（空 = 通过） */
export function validateInsight(ins: DifferenceInsight): string[] {
  const p: string[] = [];
  if (ins.metricIds.length === 0) p.push('没有指标');
  if (ins.metricIds.length > 3) p.push('默认可见指标超过 3 项');
  for (const id of ins.metricIds) {
    const m = METRICS.find((x) => x.id === id);
    if (!m) { p.push(`指标 ${id} 不存在`); continue; }
    if (m.eventId !== ins.eventId) p.push(`指标 ${id} 不属于 ${ins.eventId}`);
  }
  for (const id of ins.interpIds) {
    const i = interpById(id);
    if (!i) p.push(`解释 ${id} 不存在`);
    else if (i.eventId !== ins.eventId) p.push(`解释 ${id} 不属于 ${ins.eventId}`);
  }
  for (const id of ins.factIds) {
    const f = factById(id);
    if (!f) p.push(`事实 ${id} 不存在`);
    else if (f.eventId !== ins.eventId) p.push(`事实 ${id} 不属于 ${ins.eventId}`);
  }
  return p;
}

/** 静态校验全部证据：摘录标记、引用归属、指标引用、衍生计算输入 */
export function validateEvidence(refs = EVIDENCE_REFS, metrics = METRICS, insights = INSIGHTS): string[] {
  const p: string[] = [];
  const ids = new Set<string>();
  for (const r of refs) {
    if (ids.has(r.id)) p.push(`引用 ${r.id} 重复`);
    ids.add(r.id);
    const f = factById(r.factId);
    if (!f) p.push(`${r.id}：事实 ${r.factId} 不存在`);
    const src = sourceById(r.sourceId);
    if (!src) p.push(`${r.id}：来源 ${r.sourceId} 不存在`);
    else if (src.docVersion !== r.sourceVersion) p.push(`${r.id}：来源版本不一致`);
    if (r.mark && !r.excerpt.includes(r.mark)) p.push(`${r.id}：标记文字不在摘录里`);
    if (r.verification === 'verified' && !r.checkedAt) p.push(`${r.id}：标为已核对但没有核对日期`);
    if (r.link?.result === 'located' && (!r.link.testedBrowser || !r.link.testedAt)) p.push(`${r.id}：标为定位成功但没有浏览器验证记录`);
    if (src?.url && !/^https?:\/\//.test(src.url)) p.push(`${r.id}：来源链接协议不安全`);
  }
  for (const m of metrics) {
    for (const id of m.evidenceRefIds) {
      const r = refs.find((x) => x.id === id);
      if (!r) p.push(`${m.id}：引用 ${id} 不存在`);
      else if (r.factId !== m.factId) p.push(`${m.id}：引用 ${id} 属于 ${r.factId}，不是 ${m.factId}`);
    }
    if (!m.evidenceRefIds.some((id) => isValueRef(refs.find((x) => x.id === id)))) p.push(`${m.id}：没有直接支撑数字的引用`);
    for (const id of m.derivation?.inputRefIds ?? []) if (!m.evidenceRefIds.includes(id)) p.push(`${m.id}：衍生计算输入 ${id} 不在引用里`);
    for (const n of m.notes ?? []) if (n.refId && !refs.find((x) => x.id === n.refId)) p.push(`${m.id}：说明引用 ${n.refId} 不存在`);
  }
  for (const ins of insights) p.push(...validateInsight(ins).map((x) => `${ins.id}：${x}`));
  return p;
}

/**
 * 当前应显示的差异卡。
 * - 事件没有卡片 → none（沿用原详情，不显示空壳）
 * - 有卡片但不是当前版本的 → unavailable（不回退显示旧版本卡片）
 * - 配置错误 → unavailable 并给出原因
 */
export function insightView(s: State, ev: EventItem, list = INSIGHTS): InsightView {
  const all = list.filter((i) => i.eventId === ev.id);
  if (all.length === 0) return { kind: 'none' };
  const version = currentVersion(s, ev.id);
  const insight = all.find((i) => i.version === version);
  if (!insight) return { kind: 'unavailable', version, reason: `当前版本（${version}）还没有审核过的差异卡，旧版本卡片不再展示。`, problems: [] };
  const problems = validateInsight(insight);
  if (problems.length) return { kind: 'unavailable', insight, version, reason: '这张卡的依赖声明不完整，暂不展示。', problems };

  const metrics = insight.metricIds.map((id) => metricState(s, id, ev.id));
  const interps: InterpView[] = insight.interpIds.map((id) => {
    const interp = interpById(id)!;
    const eff = interpEffective(s, interp);
    return { id, interp, eff, live: isLive(eff) };
  });
  const deadMetric = metrics.find((m) => !m.usable);
  const deadInterp = interps.find((i) => !i.live);
  const explain = deadInterp
    ? { live: false, reason: deadInterp.eff.reason || '解释未通过发布门禁。' }
    : deadMetric
      ? { live: false, reason: `「${deadMetric.metric?.label ?? deadMetric.id}」${deadMetric.reason}，依赖它的解释已停止展示。` }
      : { live: true, reason: '' };
  return { kind: 'card', insight, version, metrics, interps, explain, degraded: !!deadMetric || metrics.some((m) => m.status === 'partial') };
}

/** 卡片当前依赖的全部解释、事实、引用（给观察卡保存） */
export function insightDeps(ins: DifferenceInsight) {
  const metrics = ins.metricIds.map((id) => METRICS.find((m) => m.id === id)).filter((m): m is InsightMetric => !!m);
  return {
    interpIds: [...ins.interpIds],
    factIds: [...new Set([...ins.factIds, ...metrics.map((m) => m.factId)])],
    evidenceRefIds: [...new Set(metrics.flatMap((m) => m.evidenceRefIds))],
  };
}

// ---------- 外链 ----------

/** 文字片段按 MDN 规则编码：逗号、连字符、& 等都要转义，否则会被当成语法 */
export function encodeFragmentText(t: string) {
  return encodeURIComponent(t).replace(/-/g, '%2D').replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

/** 只允许 http/https；拒绝 javascript:、data: 等可执行链接 */
export function safeUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  try {
    const u = new URL(url);
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.href : null;
  } catch {
    return null;
  }
}

export interface OutLink {
  href: string;
  /** 只有真实浏览器验证过定位的，才叫「打开原文定位」 */
  locates: boolean;
  label: string;
}

export function outLink(ref: EvidenceRef): OutLink | null {
  const src = sourceById(ref.sourceId);
  const base = safeUrl(src?.url);
  if (!base) return null;
  const l = ref.link;
  if (l?.method === 'textFragment') {
    const href = `${base.split('#')[0]}#:~:text=${encodeFragmentText(l.target)}`;
    return l.result === 'located' ? { href, locates: true, label: '打开原文定位' } : { href, locates: false, label: '打开原文' };
  }
  if (l?.method === 'element') return { href: `${base.split('#')[0]}#${encodeURIComponent(l.target)}`, locates: l.result === 'located', label: l.result === 'located' ? '打开原文定位' : '打开原文' };
  if (l?.method === 'pdfPage') return { href: `${base.split('#')[0]}#page=${Number(l.target) || 1}`, locates: l.result === 'located', label: l.result === 'located' ? '打开原文定位' : '打开原文' };
  return { href: base, locates: false, label: '打开原文' };
}

/** 图表里当前不能作为有效事实的行（首页预览图也要标出来） */
export function offMetricIds(s: State, ev: EventItem): Set<string> {
  const f = ev.figure;
  if (!f || (f.kind !== 'bars' && f.kind !== 'dots')) return new Set();
  return new Set(f.rows.map((r) => r.metricId).filter((id): id is string => !!id && !metricState(s, id, ev.id).usable));
}
