// v0.7 资讯扩充 + 重要程度 / 用户关注度排序：浏览器验收（本机 Chrome headless + CDP 真实点击）
//   node tests/rank-e2e.mjs <http://localhost:4186 | file:///…/index.html> <截图目录> [结果 json]
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { byText, launch, q, sleep } from './cdp.mjs';

const BASE = process.argv[2] || 'http://localhost:4186';
const OUT = process.argv[3] || join(process.cwd(), 'rank-shots');
const RES = process.argv[4];
mkdirSync(OUT, { recursive: true });
const URL0 = BASE.endsWith('.html') ? BASE : BASE + '/';
const KEY = 'jianwei.demo.v5';
const b = await launch();
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
const shot = (n, full) => b.shot(join(OUT, n + '.png'), full);
async function check(id, name, fn) {
  try { await fn(); results.push({ id, name, result: 'PASS' }); console.log('PASS', id, name); }
  catch (e) { results.push({ id, name, result: 'FAIL', error: e.message }); console.log('FAIL', id, name, '—', e.message); }
}
async function fresh(hash, state) {
  await b.send('Page.navigate', { url: URL0 + hash }); await sleep(900);
  await b.ev(`localStorage.clear(); ${state ? `localStorage.setItem('${KEY}', ${JSON.stringify(JSON.stringify(state))})` : ''}`);
  await b.send('Page.reload'); await sleep(1500);
}
const go = async (h) => { await b.ev(`location.hash = ${JSON.stringify(h)}`); await sleep(800); };
/** 首页卡片：[资讯 id, 名次, 重要程度, 关注度] */
const cards = () => b.ev(`[...document.querySelectorAll('.lead, .feed > li, .dk-lead, .dk-card')].map(c=>{const a=c.querySelector('a[href^="#/e/"]');const n=[...c.querySelectorAll('.sc-item b')].map(x=>+x.textContent);return [a.getAttribute('href').slice(4), +c.querySelector('.sc-rank').textContent, n[0], n[1]]})`);
const seg = (label) => byText('.sort-seg button', label);

const NEW = ['profit-2608', 'price-2608', 'fomc-2609', 'macro-2608', 'realestate-2608', 'pmi-2608'];
const CARDS = { 'profit-2608': '利润（1—8 月）', 'price-2608': 'PPI', 'macro-2608': '工业增加值', 'realestate-2608': '新房销售面积', 'pmi-2608': '制造业 PMI' };

await b.viewport(390, 844);

await check('R1', '首页 11 条真实与教学资讯，每条都有名次、重要程度、关注度；名次连续', async () => {
  await fresh('#/');
  await b.waitFor(q('.sc'));
  const c = await cards();
  assert(c.length === 11, '条数：' + c.length);
  assert(c.every((x, i) => x[1] === i + 1), '名次不连续');
  assert(c.every((x) => x[2] >= 0 && x[2] <= 100 && x[3] >= 0 && x[3] <= 100), '分数越界');
  for (const id of NEW) assert(c.some((x) => x[0] === id), '缺少新资讯 ' + id);
  assert(await b.ev(`document.querySelector('.lead .tag-recent')?.textContent === '近期资讯'`), '头条没标近期资讯');
  assert(await b.noOverflow(), '水平溢出');
  await shot('01-首页-综合排序');
});

await check('R2', '头条护栏：三种排序下头条的重要程度都 ≥ 70；「重要程度」排序按分数降序', async () => {
  for (const label of ['综合', '重要程度', '与我相关']) {
    await b.click(seg(label)); await sleep(300);
    const c = await cards();
    assert(c[0][2] >= 70, `${label} 头条重要程度 ${c[0][2]}`);
    if (label === '重要程度') assert(c.every((x, i) => i === 0 || c[i - 1][2] >= x[2]), '重要程度没有降序');
  }
  await b.click(seg('综合')); await sleep(200);
});

await check('R3', '排序说明写清公式、护栏与「模拟热度」；选择关心的主题后，「与我相关」里房地产上升', async () => {
  await b.click(q('.sort-why')); await sleep(250);
  const t = await b.ev(`document.querySelector('.sort-explain').textContent`);
  assert(/0\.65/.test(t) && /70/.test(t) && /模拟/.test(t) && /不代表投资价值/.test(t), '说明不完整');
  await shot('02-排序说明');
  await b.click(seg('与我相关')); await sleep(250);
  const before = (await cards()).findIndex((x) => x[0] === 'realestate-2608');
  const attnBefore = (await cards()).find((x) => x[0] === 'realestate-2608')[3];
  await b.click(byText('.sort-topics .chip-sm', '房地产')); await sleep(300);
  const c = await cards();
  const after = c.findIndex((x) => x[0] === 'realestate-2608');
  assert(c.find((x) => x[0] === 'realestate-2608')[3] > attnBefore, '关注度没有上升');
  assert(after <= before, `名次没有上升：${before + 1} → ${after + 1}`);
  const st = await b.ev(`JSON.parse(localStorage.getItem('${KEY}'))`);
  assert(st.topics.includes('房地产') && st.sort === 'attention', '偏好没有保存在本机');
  await shot('03-与我相关-关心房地产');
});

await check('R4', '关注 2025 年 CPI 解读后，2026 年价格资讯的关注度上升（相关资讯联动）', async () => {
  await fresh('#/');
  const a0 = (await cards()).find((x) => x[0] === 'price-2608')[3];
  await go('#/e/cpi-2508');
  await b.click(`document.querySelector('.insight-actions .btn-primary')`); await sleep(300);
  await go('#/');
  const a1 = (await cards()).find((x) => x[0] === 'price-2608')[3];
  assert(a1 > a0, `关注度 ${a0} → ${a1}`);
  await go('#/e/price-2608');
  await b.ev(`document.querySelector('.rk-head').scrollIntoView({block:'center'})`);
  await b.click(q('.rk-head')); await sleep(300);
  const t = await b.ev(`document.querySelector('.rk-body').textContent`);
  assert(/和你关注的问题相关/.test(t), '详情没解释为什么相关');
  assert(await b.ev(`document.querySelectorAll('.rk-body .rk-row').length === 7`), '评分拆解不是 5 + 2 项');
  await shot('04-详情-为什么推荐给你');
});

await check('R5', '五条新资讯的差异卡：每个数字都能打开自己的官方原句，并标出数字', async () => {
  await fresh('#/');
  for (const [id, first] of Object.entries(CARDS)) {
    await go('#/e/' + id);
    await b.waitFor(q('.insight'));
    const n = await b.ev(`document.querySelectorAll('.insight .im-check').length`);
    assert(n === 3, id + ' 指标数 ' + n);
    const quotes = [];
    for (let i = 0; i < 3; i++) {
      await b.click(`document.querySelectorAll('.insight .im-check')[${i}]`);
      await b.waitFor(q('.sheet .mx'));
      const title = await b.ev(`document.querySelector('.sheet .sheet-title').textContent`);
      if (i === 0) assert(title.startsWith(first), id + ' 标题：' + title);
      assert(await b.ev(`!!document.querySelector('.sheet .mx-mark')`), id + ' 没有标出数字');
      assert(await b.ev(`document.querySelector('.sheet .mx-st').textContent.includes('已核对')`), id + ' 状态不是已核对');
      quotes.push(await b.ev(`document.querySelector('.sheet .mx .ev-quote').textContent`));
      await b.key('Escape'); await sleep(200);
    }
    assert(new Set(quotes).size === 3, id + ' 三个数字打开了相同的摘录');
    assert(await b.noOverflow(), id + ' 溢出');
  }
  await go('#/e/profit-2608');
  await b.click(`document.querySelectorAll('.insight .im-check')[1]`); await b.waitFor(q('.sheet .mx'));
  assert(await b.ev(`document.querySelector('.sheet').textContent.includes('官方披露')`), '官方解释没有标「官方披露」');
  await shot('05-新资讯-逐项核对');
  await b.key('Escape');
});

await check('R6', '美联储 2026 年 9 月：没有差异卡，原句对照标出强化语气', async () => {
  await go('#/e/fomc-2609');
  assert(!(await b.ev(`!!document.querySelector('.insight')`)), '不应有差异卡');
  assert(await b.ev(`document.querySelector('.answer').textContent.includes('通胀仍然偏高')`), '答案不对');
  await b.click(`document.querySelector('#sec-tr .disc-btn')`); await sleep(400);
  assert(await b.ev(`document.querySelector('#sec-tr').textContent.includes('Inflation remains elevated')`), '原句对照缺失');
});

await check('R7', '工作台排序评分表：每条资讯一行，列出五个维度与两个分数', async () => {
  await fresh('#/studio', { schema: 5, demoMode: true, watches: [] });
  const rows = await b.ev(`document.querySelectorAll('.rank-table tbody tr').length`);
  assert(rows === 12, '行数 ' + rows); // 演示模式含示范公司 A
  assert(await b.ev(`document.querySelector('.rank-table').textContent.includes('热度*')`), '没标模拟热度');
  await b.ev(`document.querySelector('.rank-table').scrollIntoView({block:'start'}); scrollBy(0,-120)`); await sleep(300);
  await shot('06-工作台-评分表');
});

await b.viewport(1440, 900, false, 1);
await check('R8', '桌面：排序条与分数显示，头条护栏生效，无溢出', async () => {
  await fresh('#/');
  await b.ev(`document.querySelector('.sortbar').scrollIntoView({block:'start'}); scrollBy(0,-120)`); await sleep(1500);
  const c = await cards();
  assert(c.length === 11 && c[0][2] >= 70, '桌面卡片 ' + c.length);
  assert(await b.noOverflow(), '溢出');
  await shot('07-桌面-排序');
});

const problems = b.problems.filter((p) => !/favicon/.test(p));
results.push({ id: 'console', name: '控制台无脚本错误', result: problems.length ? 'FAIL' : 'PASS', error: problems.join(' | ') || undefined });
const ver = await b.send('Browser.getVersion');
const summary = { base: BASE, browser: ver.product, at: new Date().toISOString(), pass: results.filter((r) => r.result === 'PASS').length, fail: results.filter((r) => r.result === 'FAIL').length, results };
console.log(`\n${summary.pass} passed, ${summary.fail} failed · ${ver.product}`);
if (RES) writeFileSync(RES, JSON.stringify(summary, null, 2));
b.close();
process.exit(summary.fail ? 1 : 0);
