import { beforeEach, describe, expect, it } from 'vitest';
import { EVENTS, EVIDENCE_REFS, INSIGHTS, METRICS, eventById, metricById, refById } from '../src/data/content';
import type { DifferenceInsight, EvidenceRef, InsightMetric } from '../src/data/types';
import { encodeFragmentText, insightView, metricState, outLink, refState, safeUrl, validateEvidence, validateInsight } from '../src/logic/evidence';
import { __resetForTest, adoptSuggestedQuestion, applyDemoCorrection, getState, initialState, migrate, saveWatch, setReview, setSourceMissing, updateWatch } from '../src/logic/store';
import { viewInterpIds } from '../src/logic/view';
import { followEvent, watchStatus } from '../src/logic/watch';

/*
 * v0.6 逐项证据的规则测试。编号对应方案包 04「关键验收矩阵」。
 * 只测规则，不测排版。
 */

beforeEach(() => __resetForTest(initialState()));
const baba = eventById('baba-2506')!;
const cpi = eventById('cpi-2508')!;
const follow = (id: string) => { const r = followEvent(getState(), id); saveWatch(r.watch); return r; };

describe('静态校验：数据本身不自相矛盾', () => {
  it('全部引用、指标、差异卡通过校验', () => {
    expect(validateEvidence()).toEqual([]);
  });
  it('摘录里的标记文字都真在摘录里；英文摘录都带中文释义', () => {
    for (const r of EVIDENCE_REFS) {
      if (r.mark) expect(r.excerpt.includes(r.mark), r.id).toBe(true);
      if (/[A-Za-z]{6,}/.test(r.excerpt) && r.locator.kind === 'text') expect(r.translation, r.id).toBeTruthy();
    }
  });
  it('标为「定位成功」的外链都有浏览器与日期记录', () => {
    for (const r of EVIDENCE_REFS) if (r.link?.result === 'located') expect(r.link.testedBrowser && r.link.testedAt, r.id).toBeTruthy();
  });
});

describe('A02/A03 每个数字只对应自己的原文', () => {
  it('主卡三项：净利润、经营利润、经营现金流各自指向不同的原句', () => {
    const iv = insightView(getState(), baba);
    expect(iv.kind).toBe('card');
    if (iv.kind !== 'card') return;
    const first = iv.metrics.map((m) => refById(m.metric!.evidenceRefIds[0])!);
    expect(first.map((r) => r.metricKey)).toEqual(['net_income.yoy', 'income_from_operations.yoy', 'operating_cash_flow.yoy']);
    expect(new Set(first.map((r) => r.excerpt)).size).toBe(3);
    // 净利润不能打开现金流的摘录；也不能指向「归属于普通股股东的净利润」
    expect(first[0].excerpt).toMatch(/^Net income was/);
    expect(first[0].excerpt).not.toMatch(/attributable/);
    // 经营现金流不能指向自由现金流那句
    expect(first[2].excerpt).toMatch(/^Net cash provided by operating activities/);
    expect(first[2].excerpt).not.toMatch(/Free cash flow/);
    // 经营利润不能指向经调整 EBITA
    expect(first[1].excerpt).toMatch(/^Income from operations/);
  });
  it('图表五行按 metricId 取证据：报告口径收入与同口径收入是两条不同的引用', () => {
    const rows = baba.figure!.kind === 'bars' ? baba.figure!.rows : [];
    expect(rows).toHaveLength(5);
    expect(baba.figure!.factIds).toHaveLength(4); // 5 行 vs 4 条事实：不能按下标配对
    for (const r of rows) {
      const m = metricById(r.metricId!)!;
      expect(r.display, r.label).toBe(m.display); // 图表数字与指标表同源
    }
    const rev = metricById(rows[0].metricId!)!, lfl = metricById(rows[1].metricId!)!;
    expect(rev.factId).toBe(lfl.factId); // 同一条事实
    expect(refById(rev.evidenceRefIds[0])!.metricKey).toBe('revenue.reported.yoy');
    expect(refById(lfl.evidenceRefIds[0])!.metricKey).toBe('revenue.lfl.yoy');
    expect(refById(lfl.evidenceRefIds[0])!.excerpt).toMatch(/like-for-like/);
  });
  it('公司对自由现金流的解释不挂在经营现金流的数字证据上', () => {
    const ocf = metricById('M-BA-OCF')!;
    const valueRefs = ocf.evidenceRefIds.map((id) => refById(id)!);
    for (const r of valueRefs) expect(r.excerpt).not.toMatch(/decrease in free cash flow was mainly attributed/);
    const why = ocf.notes!.find((n) => n.refId === 'R-BA-FCF-WHY')!;
    expect(why.text).toMatch(/针对的是自由现金流/);
  });
  it('衍生计算写明公式、输入与舍入', () => {
    const d = metricById('M-BA-OCF')!.derivation!;
    expect(d.formula).toMatch(/20,672/);
    expect(Math.round((20672 / 33636 - 1) * 100)).toBe(-39);
  });
});

describe('A09 唯一必要来源缺失', () => {
  it('三项指标都不可用；解释停止；观察卡提示来源不可用', () => {
    follow('baba-2506');
    setSourceMissing('S-BABA', true);
    const iv = insightView(getState(), baba);
    if (iv.kind !== 'card') throw new Error('应仍是卡片（保留历史值并标明失效）');
    expect(iv.metrics.every((m) => m.status === 'unavailable' && !m.usable)).toBe(true);
    expect(iv.explain.live).toBe(false);
    const w = getState().watches[0];
    expect(watchStatus(getState(), w).tone).toBe('stop');
  });
  it('可替代来源：核心 CPI 的解读稿不可用时，数据表仍支持这个数字，但依赖解读稿的解释停止', () => {
    setSourceMissing('S-NBS-JD', true);
    const m = metricState(getState(), 'M-CPI-CORE', 'cpi-2508');
    expect(m.status).toBe('partial');
    expect(m.usable).toBe(true);
    const iv = insightView(getState(), cpi);
    if (iv.kind !== 'card') throw new Error('应为卡片');
    expect(iv.explain.live).toBe(false); // I-CPI-1 依赖翘尾事实，只有解读稿支持
  });
});

describe('A10/A11 解释待复核、撤回、恢复来源', () => {
  it('待复核 → 解释不显示，事实仍可核对', () => {
    setReview('I-BA-3', 'needs_review');
    const iv = insightView(getState(), baba);
    if (iv.kind !== 'card') throw new Error('应为卡片');
    expect(iv.explain.live).toBe(false);
    expect(iv.metrics.every((m) => m.usable)).toBe(true);
  });
  it('撤回 → 观察卡同步停止；恢复来源不会把撤回的解释重新发布', () => {
    follow('baba-2506');
    setReview('I-BA-3', 'withdrawn');
    setSourceMissing('S-BABA', true);
    setSourceMissing('S-BABA', false);
    const iv = insightView(getState(), baba);
    if (iv.kind !== 'card') throw new Error('应为卡片');
    expect(iv.explain.live).toBe(false);
    expect(iv.interps[0].eff.status).toBe('withdrawn');
    expect(watchStatus(getState(), getState().watches[0]).label).toBe('相关解释已撤回');
  });
  it('差异卡的解释进入依赖集合（撤回联动不漏）', () => {
    expect(viewInterpIds(getState(), baba)).toContain('I-BA-3');
  });
});

describe('A12 版本：当前版本没有卡时不回退旧卡', () => {
  const fake: DifferenceInsight = { id: 'DI-X', eventId: 'demo-a', version: 'v1', question: '（测试）', metricIds: ['M-BA-NI'], interpIds: [], boundary: '', openQuestion: '', nextCheck: '', factIds: [] };
  it('v1 卡在 v2 下不再展示', () => {
    const demo = eventById('demo-a')!;
    applyDemoCorrection('studio');
    const iv = insightView(getState(), demo, [fake]);
    expect(iv.kind).toBe('unavailable');
  });
});

describe('A13/A14 非法引用、版本不匹配、只有转述', () => {
  it('卡片声明了不存在或不属于本事件的依赖 → 校验失败，不静默过滤', () => {
    const bad: DifferenceInsight = { ...INSIGHTS[0], id: 'DI-BAD', metricIds: ['M-BA-NI', 'M-NOPE'], interpIds: ['I-NOPE'], factIds: ['F-CPI-1'] };
    const p = validateInsight(bad);
    expect(p.join('|')).toMatch(/M-NOPE/);
    expect(p.join('|')).toMatch(/I-NOPE/);
    expect(p.join('|')).toMatch(/F-CPI-1 不属于/);
    const iv = insightView(getState(), baba, [bad]);
    expect(iv.kind).toBe('unavailable');
  });
  it('引用不存在 / 引用属于别的事实', () => {
    expect(refState(getState(), 'R-NOPE').status).toBe('notFound');
    expect(refState(getState(), 'R-BA-OCF', 'F-BA-3').usable).toBe(false);
  });
  it('来源版本不匹配、未核对、只有转述 → 都不算已核验原文', () => {
    const base = refById('R-BA-NI')!;
    const mk = (x: Partial<EvidenceRef>): EvidenceRef[] => [...EVIDENCE_REFS, { ...base, id: 'R-T', ...x }];
    const m: InsightMetric = { ...metricById('M-BA-NI')!, id: 'M-T', evidenceRefIds: ['R-T'] };
    expect(validateEvidence(mk({ sourceVersion: '旧版本' }), [m], []).join()).toMatch(/版本不一致/);
    expect(validateEvidence(mk({ checkedAt: undefined }), [m], []).join()).toMatch(/没有核对日期/);
    expect(validateEvidence(mk({ mark: '不存在的文字' }), [m], []).join()).toMatch(/标记文字不在摘录里/);
    expect(validateEvidence(mk({ link: { method: 'textFragment', target: 'x', result: 'located' } }), [m], []).join()).toMatch(/没有浏览器验证记录/);
  });
});

describe('外链：只允许 http/https，定位文字正确编码', () => {
  it('拒绝可执行协议', () => {
    expect(safeUrl('javascript:alert(1)')).toBeNull();
    expect(safeUrl('data:text/html,hi')).toBeNull();
    expect(safeUrl('https://www.sec.gov/x')).toBe('https://www.sec.gov/x');
  });
  it('逗号、连字符按文字片段规则转义', () => {
    expect(encodeFragmentText('RMB42,382 like-for-like')).toBe('RMB42%2C382%20like%2Dfor%2Dlike');
  });
  it('只有验证过的链接才叫「打开原文定位」', () => {
    expect(outLink(refById('R-BA-OCF')!)!.label).toBe('打开原文定位');
    expect(outLink(refById('R-BA-FCF-WHY')!)!.label).toBe('打开原文');
    expect(outLink(refById('R-BA-OCF')!)!.href).toMatch(/#:~:text=Net%20cash%20provided/);
  });
});

describe('A08 关注这个问题：不重复建卡，不丢笔记，不覆盖自己写的问题', () => {
  it('连续关注两次只有一张卡', () => {
    const a = follow('baba-2506');
    expect(a.created).toBe(true);
    const b = follow('baba-2506');
    expect(b.created).toBe(false);
    expect(getState().watches).toHaveLength(1);
    const w = getState().watches[0];
    expect(w.openQuestion).toBe('后续经营现金流和相关投入如何变化？');
    expect(w.insightId).toBe('DI-BA-1');
    expect(w.evidenceRefIds).toContain('R-BA-OCF');
  });
  it('旧卡（没有差异卡字段）+ 私人笔记 → 合并依赖，笔记和保存版本不动', () => {
    saveWatch({ watchId: 'w-old', eventId: 'baba-2506', savedVersion: 'v1', savedAt: '2026-09-20T00:00:00Z', change: '', basis: '旧依据', openQuestion: baba.summary.unknown, nextCheck: '下一期季度公告中的经营现金流与资本开支', note: '我自己的笔记', paused: false, interpIds: ['I-BA-1'] });
    follow('baba-2506');
    const w = getState().watches[0];
    expect(getState().watches).toHaveLength(1);
    expect(w.note).toBe('我自己的笔记');
    expect(w.savedAt).toBe('2026-09-20T00:00:00Z');
    expect(w.interpIds).toEqual(expect.arrayContaining(['I-BA-1', 'I-BA-3']));
    expect(w.openQuestion).toBe('后续经营现金流和相关投入如何变化？'); // 自动写的问题可以换
  });
  it('用户改过问题 → 保留，本卡问题只作建议，由用户选择采用', () => {
    follow('baba-2506');
    const w0 = getState().watches[0];
    updateWatch({ ...w0, openQuestion: '我想知道淘宝闪购什么时候盈利', note: '笔记' });
    const r = follow('baba-2506');
    expect(r.keptOwnQuestion).toBe(true);
    let w = getState().watches[0];
    expect(w.openQuestion).toBe('我想知道淘宝闪购什么时候盈利');
    expect(w.suggestedQuestion).toBe('后续经营现金流和相关投入如何变化？');
    adoptSuggestedQuestion(w.watchId);
    w = getState().watches[0];
    expect(w.openQuestion).toBe('后续经营现金流和相关投入如何变化？');
    expect(w.suggestedQuestion).toBeUndefined();
    expect(w.note).toBe('笔记');
  });
});

describe('A17 旧版本地数据迁移', () => {
  it('v4 数据：观察卡与笔记保留，缺字段补齐，不崩溃', () => {
    const v4 = { schema: 4, demoMode: true, theme: 'dark', review: { 'I-BA-1': 'withdrawn' }, watches: [{ watchId: 'w1', eventId: 'baba-2506', savedVersion: 'v1', note: '旧笔记' }, { watchId: 'w2', eventId: 'gone-event' }, null] };
    const s = migrate(v4);
    expect(s.schema).toBe(5);
    expect(s.watches).toHaveLength(1);
    expect(s.watches[0].note).toBe('旧笔记');
    expect(s.watches[0].interpIds).toEqual([]);
    expect(s.review['I-BA-1']).toBe('withdrawn');
    expect(s.review['I-BA-3']).toBe('published'); // 新解释有默认状态
    expect(() => watchStatus(s, s.watches[0])).not.toThrow();
  });
  it('看不懂的数据退回初始状态', () => {
    expect(migrate('garbage').watches).toEqual([]);
    expect(migrate({ schema: 99, watches: [{}] }).watches).toEqual([]);
  });
});

describe('A15 没有自然差异的内容不强插差异卡', () => {
  it('有自然差异的样本才有卡；央行、美联储、教学、示范公司没有', () => {
    const withCard = EVENTS.filter((e) => insightView(getState(), e).kind !== 'none').map((e) => e.id);
    expect(withCard.sort()).toEqual(['baba-2506', 'cpi-2508', 'macro-2608', 'pmi-2608', 'price-2608', 'profit-2608', 'realestate-2608']);
    for (const id of ['pboc-2505', 'fomc-2509', 'fomc-2609', 'teach-cost', 'demo-a']) expect(withCard).not.toContain(id);
  });
  it('每张卡默认可见指标 2–3 项', () => {
    for (const i of INSIGHTS) expect(i.metricIds.length >= 2 && i.metricIds.length <= 3).toBe(true);
    expect(METRICS.length).toBeGreaterThan(0);
  });
});
