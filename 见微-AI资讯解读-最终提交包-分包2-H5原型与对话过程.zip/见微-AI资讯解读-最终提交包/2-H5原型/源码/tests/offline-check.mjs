// 用法：node tests/offline-check.mjs <单文件 file:// 地址> <结果.json>
// A05 离线：CDP 断网后打开单文件，检查主卡、本地摘录、网络请求
import { launch, sleep } from './cdp.mjs';
import { writeFileSync } from 'node:fs';
const URL0 = process.argv[2];
const b = await launch();
const reqs = [];
await b.send('Network.enable');
await b.send('Network.emulateNetworkConditions', { offline: true, latency: 0, downloadThroughput: -1, uploadThroughput: -1 });
b.send('Target.setDiscoverTargets', { discover: false }).catch(() => {});
await b.viewport(390, 844);
await b.send('Page.navigate', { url: URL0 + '#/e/baba-2506' });
await sleep(2500);
const card = await b.ev(`document.querySelectorAll('.insight .im').length`);
await b.click(`document.querySelectorAll('.insight .im-check')[2]`);
await sleep(500);
const quote = await b.ev(`document.querySelector('.sheet .mx .ev-quote')?.textContent.slice(0,60)`);
const label = await b.ev(`document.querySelector('.sheet .mx-open a')?.textContent`);
const offlineNote = await b.ev(`document.querySelector('.sheet .mx-open .warn')?.textContent`);
const fonts = await b.ev(`document.fonts.check('600 20px "Noto Serif SC"', '看懂差异核对')`);
const res = await b.ev(`performance.getEntriesByType('resource').map(e=>e.name).filter(n=>!n.startsWith('data:'))`);
const out = { offline: true, metrics: card, quote, outLinkLabel: label, offlineNote, serifLoaded: fonts, externalResources: res, problems: b.problems };
console.log(JSON.stringify(out, null, 1));
writeFileSync(process.argv[3], JSON.stringify(out, null, 2));
b.close(); process.exit(0);
