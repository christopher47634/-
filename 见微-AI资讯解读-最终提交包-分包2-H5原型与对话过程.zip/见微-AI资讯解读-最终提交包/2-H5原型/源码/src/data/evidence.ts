import type { DifferenceInsight, EvidenceRef, FigureRow, InsightMetric } from './types';
import { INSIGHTS_2026, METRICS_2026, REFS_2026 } from './news2026';

/*
 * 逐项证据（v0.6）
 * - 每条 EvidenceRef 对应原文里的一句或表格里的一格，只服务一个指标（metricKey）。
 *   同一句话里有两个数字（如报告口径收入与同口径收入），拆成两条引用，不靠数组下标配对。
 * - 摘录均为 2026-09-27 重新打开原文逐字核对的短句；英文摘录附中文释义，释义不当作原文。
 * - link.result 只写真实浏览器验证过的结果，见 04-过程记录 里的外链定位记录；
 *   没验证过的写 notTested。页面据此决定按钮写「打开原文定位」还是「打开原文」。
 * - 数字只在 METRICS 里存一份：主卡、图表行、口径对照都从这里读。
 */

const CHECKED = '2026-09-27';
const LINK_TESTED = '2026-09-28';
const SEC_VER = 'SEC EDGAR 存档版本 0001104659-25-085638';

// 外链定位验证记录（2026-09-28，本机 Chrome 有界面窗口，从单文件成品里真实点击外链，读回新窗口里目标句子在视口内；每条连测 3 轮，3 轮全中才记 located）
// 脚本 tests/outlink-verify.mjs，结果 research/outlink-verify.json；定位不稳定或未测的，页面只写「打开原文」并给检索关键词
const T_CHROME = 'Chrome 153.0.8010.53（Windows，有界面窗口）';
const located = (target: string) => ({ method: 'textFragment' as const, target, testedBrowser: T_CHROME, testedAt: LINK_TESTED, result: 'located' as const });
const untested = (target: string) => ({ method: 'textFragment' as const, target, result: 'notTested' as const });

const REFS_BASE: EvidenceRef[] = [
  // ---------- 阿里巴巴 2025 年 6 月季度（S-BABA）----------
  {
    id: 'R-BA-REV', factId: 'F-BA-1', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'revenue.reported.yoy',
    label: '收入（报告口径）同比', section: 'BUSINESS HIGHLIGHTS · In the quarter ended June 30, 2025',
    locator: { kind: 'text', exact: 'Revenue was RMB247,652 million (US$34,571 million), an increase of 2% year-over-year.' },
    excerpt: 'Revenue was RMB247,652 million (US$34,571 million), an increase of 2% year-over-year.',
    excerptKind: 'verbatim', mark: 'an increase of 2% year-over-year',
    translation: '收入为 2,476.52 亿元人民币（34.57 亿美元），同比增长 2%。',
    searchText: 'Revenue was RMB247,652 million', checkedAt: CHECKED, verification: 'verified',
    link: located('Revenue was RMB247,652 million'),
  },
  {
    id: 'R-BA-LFL', factId: 'F-BA-1', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'revenue.lfl.yoy',
    label: '收入（同口径）同比', section: 'BUSINESS HIGHLIGHTS · In the quarter ended June 30, 2025',
    locator: { kind: 'text', exact: 'Excluding revenue from the disposed businesses of Sun Art and Intime, revenue on a like-for-like basis would have grown by 10% year-over-year.' },
    excerpt: 'Excluding revenue from the disposed businesses of Sun Art and Intime, revenue on a like-for-like basis would have grown by 10% year-over-year.',
    excerptKind: 'verbatim', mark: 'would have grown by 10% year-over-year',
    translation: '剔除已处置的高鑫零售与银泰的收入后，同口径收入同比增长 10%。',
    searchText: 'revenue on a like-for-like basis', checkedAt: CHECKED, verification: 'verified',
    // 3 轮里有 1 轮没有定位（见 research/outlink-verify.json），不算定位成功：页面只写「打开原文」并给检索词
    link: { ...located('revenue on a like-for-like basis would have grown by 10%'), result: 'openedOnly' },
  },
  {
    id: 'R-BA-OP', factId: 'F-BA-2', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'income_from_operations.yoy',
    label: '经营利润同比', section: 'BUSINESS HIGHLIGHTS · In the quarter ended June 30, 2025',
    locator: { kind: 'text', exact: 'Income from operations was RMB34,988 million (US$4,884 million), a decrease of 3% year-over-year' },
    excerpt: 'Income from operations was RMB34,988 million (US$4,884 million), a decrease of 3% year-over-year, primarily due to the decrease in adjusted EBITA …',
    excerptKind: 'verbatim', mark: 'a decrease of 3% year-over-year',
    translation: '经营利润为 349.88 亿元人民币，同比下降 3%，主要由于经调整 EBITA 下降……',
    searchText: 'Income from operations was RMB34,988 million', checkedAt: CHECKED, verification: 'verified',
    link: located('Income from operations was RMB34,988 million'),
  },
  {
    id: 'R-BA-OP-T', factId: 'F-BA-2', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'income_from_operations.yoy',
    label: '经营利润同比（汇总表）', section: 'JUNE QUARTER SUMMARY FINANCIAL RESULTS',
    locator: { kind: 'table', table: 'JUNE QUARTER SUMMARY FINANCIAL RESULTS', row: 'Income from operations', column: 'YoY % Change', unit: '%' },
    excerpt: 'Income from operations　2024: 35,989　2025: 34,988　YoY % Change: (3)%',
    excerptKind: 'verbatim', mark: '(3)%',
    translation: '表中括号表示负数：(3)% 即同比 −3%。金额单位为人民币百万元。',
    searchText: 'JUNE QUARTER SUMMARY FINANCIAL RESULTS', checkedAt: CHECKED, verification: 'verified',
  },
  {
    id: 'R-BA-NI', factId: 'F-BA-3', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'net_income.yoy',
    label: '净利润同比', section: 'BUSINESS HIGHLIGHTS · In the quarter ended June 30, 2025',
    locator: { kind: 'text', exact: 'Net income was RMB42,382 million (US$5,916 million), an increase of 76% year-over-year' },
    excerpt: 'Net income was RMB42,382 million (US$5,916 million), an increase of 76% year-over-year …',
    excerptKind: 'verbatim', mark: 'an increase of 76% year-over-year',
    translation: '净利润为 423.82 亿元人民币，同比增长 76%……',
    searchText: 'Net income was RMB42,382 million', checkedAt: CHECKED, verification: 'verified',
    link: located('Net income was RMB42,382 million'),
  },
  {
    id: 'R-BA-NI-T', factId: 'F-BA-3', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'net_income.yoy',
    label: '净利润同比（汇总表）', section: 'JUNE QUARTER SUMMARY FINANCIAL RESULTS',
    locator: { kind: 'table', table: 'JUNE QUARTER SUMMARY FINANCIAL RESULTS', row: 'Net income', column: 'YoY % Change', unit: '%' },
    excerpt: 'Net income　2024: 24,022　2025: 42,382　YoY % Change: 76%',
    excerptKind: 'verbatim', mark: '76%',
    translation: '下一行是「Net income attributable to ordinary shareholders」（归属于普通股股东的净利润，同比 78%），是另一个指标，不要混用。',
    searchText: 'JUNE QUARTER SUMMARY FINANCIAL RESULTS', checkedAt: CHECKED, verification: 'verified',
  },
  {
    id: 'R-BA-NI-WHY', factId: 'F-BA-3', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'net_income.reason',
    label: '公司对净利润增长的解释', section: 'BUSINESS HIGHLIGHTS · In the quarter ended June 30, 2025',
    locator: { kind: 'text', exact: 'primarily due to mark-to-market changes from our equity investments and gain from the disposal of local consumer service business of Trendyol' },
    excerpt: '… primarily due to mark-to-market changes from our equity investments and gain from the disposal of local consumer service business of Trendyol, partly offset by the decrease in income from operations.',
    excerptKind: 'verbatim', mark: 'mark-to-market changes from our equity investments',
    translation: '……主要由于股权投资按市值计价的变动，以及处置 Trendyol 本地生活业务的收益，部分被经营利润下降抵消。',
    searchText: 'mark-to-market changes from our equity investments', checkedAt: CHECKED, verification: 'verified',
    link: untested('mark-to-market changes from our equity investments'),
  },
  {
    id: 'R-BA-OCF', factId: 'F-BA-4', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'operating_cash_flow.yoy',
    label: '经营现金流同比', section: 'BUSINESS HIGHLIGHTS · In the quarter ended June 30, 2025',
    locator: { kind: 'text', exact: 'Net cash provided by operating activities was RMB20,672 million (US$2,886 million), a decrease of 39% compared to RMB33,636 million in the same quarter of 2024.' },
    excerpt: 'Net cash provided by operating activities was RMB20,672 million (US$2,886 million), a decrease of 39% compared to RMB33,636 million in the same quarter of 2024.',
    excerptKind: 'verbatim', mark: 'a decrease of 39%',
    translation: '经营活动产生的现金流量净额为 206.72 亿元人民币，较 2024 年同季度的 336.36 亿元下降 39%。',
    searchText: 'Net cash provided by operating activities was RMB20,672 million', checkedAt: CHECKED, verification: 'verified',
    link: located('Net cash provided by operating activities was RMB20,672 million'),
  },
  {
    id: 'R-BA-OCF-T', factId: 'F-BA-4', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'operating_cash_flow.yoy',
    label: '经营现金流（调节表）', section: 'RECONCILIATIONS OF NON-GAAP MEASURES · net cash provided by operating activities to free cash flow',
    locator: { kind: 'table', table: 'Reconciliation of net cash provided by operating activities to free cash flow', row: 'Net cash provided by operating activities', column: 'Three months ended June 30, 2024 / 2025', unit: 'RMB million' },
    excerpt: 'Net cash provided by operating activities　2024: 33,636　2025: 20,672',
    excerptKind: 'verbatim', mark: '20,672',
    translation: '同一张表下面几行才是资本开支与自由现金流（Free cash flow），是另一个指标。',
    searchText: 'reconciliation of net cash provided by operating activities to free cash flow', checkedAt: CHECKED, verification: 'verified',
  },
  {
    id: 'R-BA-FCF-WHY', factId: 'F-BA-4', sourceId: 'S-BABA', sourceVersion: SEC_VER, metricKey: 'free_cash_flow.reason',
    label: '公司对自由现金流下降的解释', section: 'BUSINESS HIGHLIGHTS · In the quarter ended June 30, 2025',
    locator: { kind: 'text', exact: 'The decrease in free cash flow was mainly attributed to the increase in our cloud infrastructure expenditure' },
    excerpt: 'The decrease in free cash flow was mainly attributed to the increase in our cloud infrastructure expenditure and the investment in “Taobao Instant Commerce”.',
    excerptKind: 'verbatim', mark: 'The decrease in free cash flow',
    translation: '自由现金流下降主要由于云基础设施支出增加，以及对「淘宝闪购」的投入。（这句话解释的是自由现金流，不是经营现金流。）',
    searchText: 'The decrease in free cash flow was mainly attributed', checkedAt: CHECKED, verification: 'verified',
    link: untested('The decrease in free cash flow was mainly attributed'),
  },

  // ---------- 2025 年 8 月 CPI（S-NBS-CPI 数据发布 / S-NBS-JD 首席统计师解读）----------
  {
    id: 'R-CPI-YOY', factId: 'F-CPI-1', sourceId: 'S-NBS-CPI', sourceVersion: '网页版', metricKey: 'cpi.yoy',
    label: 'CPI 同比', section: '正文第 1 段',
    locator: { kind: 'text', exact: '2025年8月份，全国居民消费价格同比下降0.4%。' },
    excerpt: '2025年8月份，全国居民消费价格同比下降0.4%。',
    excerptKind: 'verbatim', mark: '同比下降0.4%',
    searchText: '全国居民消费价格同比下降', checkedAt: CHECKED, verification: 'verified',
    link: located('全国居民消费价格同比下降'),
  },
  {
    id: 'R-CPI-MOM', factId: 'F-CPI-2', sourceId: 'S-NBS-CPI', sourceVersion: '网页版', metricKey: 'cpi.mom',
    label: 'CPI 环比', section: '正文第 2 段',
    locator: { kind: 'text', exact: '8月份，全国居民消费价格环比持平。' },
    excerpt: '8月份，全国居民消费价格环比持平。',
    excerptKind: 'verbatim', mark: '环比持平',
    searchText: '全国居民消费价格环比持平', checkedAt: CHECKED, verification: 'verified',
    link: located('全国居民消费价格环比持平'),
  },
  {
    id: 'R-CPI-CORE-JD', factId: 'F-CPI-3', sourceId: 'S-NBS-JD', sourceVersion: '网页版', metricKey: 'core_cpi.yoy',
    label: '核心 CPI 同比（解读稿）', section: '解读稿导语段',
    locator: { kind: 'text', exact: '扣除食品和能源价格的核心CPI同比上涨0.9%，涨幅连续第4个月扩大。' },
    excerpt: '……扣除食品和能源价格的核心CPI同比上涨0.9%，涨幅连续第4个月扩大。',
    excerptKind: 'verbatim', mark: '同比上涨0.9%',
    searchText: '扣除食品和能源价格的核心', checkedAt: CHECKED, verification: 'verified',
    link: located('扣除食品和能源价格的核心'),
  },
  {
    id: 'R-CPI-CORE-T', factId: 'F-CPI-3', sourceId: 'S-NBS-CPI', sourceVersion: '网页版', metricKey: 'core_cpi.yoy',
    label: '核心 CPI 同比（数据表）', section: '2025年8月份居民消费价格主要数据（表）',
    locator: { kind: 'table', table: '2025年8月份居民消费价格主要数据', row: '其中：不包括食品和能源', column: '同比涨跌幅（%）', unit: '%' },
    excerpt: '其中：不包括食品和能源　环比 0.0　同比 0.9',
    excerptKind: 'verbatim', mark: '同比 0.9',
    translation: '数据发布稿的表格没有「核心 CPI」这个名称，对应的是「不包括食品和能源」一行。',
    searchText: '不包括食品和能源', checkedAt: CHECKED, verification: 'verified',
    link: untested('不包括食品和能源'),
  },
  {
    id: 'R-CPI-TAIL', factId: 'F-CPI-4', sourceId: 'S-NBS-JD', sourceVersion: '网页版', metricKey: 'cpi.carryover',
    label: '翘尾影响', section: '一、核心CPI继续回升',
    locator: { kind: 'text', exact: '上年价格变动对本月CPI同比的翘尾影响约为-0.9个百分点' },
    excerpt: '从翘尾看，上年价格变动对本月CPI同比的翘尾影响约为-0.9个百分点，下拉影响比上月扩大0.4个百分点。',
    excerptKind: 'verbatim', mark: '约为-0.9个百分点',
    searchText: '翘尾影响约为', checkedAt: CHECKED, verification: 'verified',
    link: untested('翘尾影响约为'),
  },
];

const METRICS_BASE: InsightMetric[] = [
  {
    id: 'M-BA-REV', eventId: 'baba-2506', factId: 'F-BA-1', evidenceRefIds: ['R-BA-REV'],
    label: '收入（报告口径）', display: '+2%', value: 2, period: '2025 年 4–6 月', unit: '%', basis: '同比',
    scope: '全部业务收入；上年基数里还包含后来卖掉的高鑫零售和银泰。',
  },
  {
    id: 'M-BA-LFL', eventId: 'baba-2506', factId: 'F-BA-1', evidenceRefIds: ['R-BA-LFL'],
    label: '收入（同口径）', display: '+10%', value: 10, period: '2025 年 4–6 月', unit: '%', basis: '同比，公司调整口径',
    scope: '两期都剔除已处置的高鑫零售与银泰后再比较；公告只给了增速。',
  },
  {
    id: 'M-BA-NI', eventId: 'baba-2506', factId: 'F-BA-3', evidenceRefIds: ['R-BA-NI', 'R-BA-NI-T', 'R-BA-NI-WHY'],
    label: '净利润', display: '+76%', value: 76, period: '2025 年 4–6 月', unit: '%', basis: '同比',
    scope: 'GAAP 净利润，含投资市值变动与处置收益；不是「归属于普通股股东的净利润」（同比 +78%）。',
    notes: [
      { kind: 'company', text: '公司解释：主要由于股权投资按市值计价的变动，以及处置 Trendyol 本地生活业务的收益。', refId: 'R-BA-NI-WHY' },
    ],
  },
  {
    id: 'M-BA-OP', eventId: 'baba-2506', factId: 'F-BA-2', evidenceRefIds: ['R-BA-OP', 'R-BA-OP-T'],
    label: '经营利润', display: '−3%', value: -3, period: '2025 年 4–6 月', unit: '%', basis: '同比',
    scope: '利润表里的 Income from operations（GAAP），不含投资市值变动；它不等于严格意义上的「主营利润」。',
    notes: [
      { kind: 'company', text: '公司解释：主要由于经调整 EBITA 下降（经调整 EBITA 为非 GAAP 指标，同比 −14%）。', refId: 'R-BA-OP' },
    ],
  },
  {
    id: 'M-BA-OCF', eventId: 'baba-2506', factId: 'F-BA-4', evidenceRefIds: ['R-BA-OCF', 'R-BA-OCF-T'],
    label: '经营现金流', display: '−39%', value: -39, period: '2025 年 4–6 月', unit: '%', basis: '同比',
    scope: '经营活动实际收付的现金净额；不是自由现金流（自由现金流还要减去资本开支等）。',
    derivation: { formula: '20,672 ÷ 33,636 − 1 ≈ −38.5%', inputRefIds: ['R-BA-OCF-T'], rounding: '公告原文写作「a decrease of 39%」；按调节表两期数值复算约 −38.5%，四舍五入为 −39%。' },
    notes: [
      { kind: 'company', text: '公告没有单独解释经营现金流为什么下降。公司给出的原因（云基础设施支出、「淘宝闪购」投入）针对的是自由现金流。', refId: 'R-BA-FCF-WHY' },
      { kind: 'editor', text: '云基础设施支出主要属于资本开支，会压低自由现金流；它能在多大程度上解释经营现金流的降幅，本期材料不能回答。' },
    ],
  },
  {
    id: 'M-CPI-YOY', eventId: 'cpi-2508', factId: 'F-CPI-1', evidenceRefIds: ['R-CPI-YOY'],
    label: 'CPI', display: '−0.4%', value: -0.4, period: '2025 年 8 月', unit: '%', basis: '同比（与 2024 年 8 月比）',
    scope: '全部商品与服务；受上年基数影响。',
    notes: [{ kind: 'company', text: '统计局解读：上年价格变动带来的翘尾影响约 −0.9 个百分点。', refId: 'R-CPI-TAIL' }],
  },
  {
    id: 'M-CPI-MOM', eventId: 'cpi-2508', factId: 'F-CPI-2', evidenceRefIds: ['R-CPI-MOM'],
    label: 'CPI', display: '0.0%', value: 0, period: '2025 年 8 月', unit: '%', basis: '环比（与 2025 年 7 月比）',
    scope: '全部商品与服务；只看最近一个月的变化，不受去年基数影响。',
  },
  {
    id: 'M-CPI-CORE', eventId: 'cpi-2508', factId: 'F-CPI-3', evidenceRefIds: ['R-CPI-CORE-JD', 'R-CPI-CORE-T'],
    label: '核心 CPI', display: '+0.9%', value: 0.9, period: '2025 年 8 月', unit: '%', basis: '同比，剔除食品和能源',
    scope: '扣除食品和能源价格；它不是「更真实的 CPI」，只回答另一个问题。',
  },
];

const INSIGHTS_BASE: DifferenceInsight[] = [
  {
    id: 'DI-BA-1', eventId: 'baba-2506', version: 'v1',
    question: '净利润增长，为什么现金流反而下降？',
    metricIds: ['M-BA-NI', 'M-BA-OP', 'M-BA-OCF'],
    interpIds: ['I-BA-3'],
    boundary: '这期材料还不足以判断：新增投入何时能转化为持续的经营回报。',
    openQuestion: '后续经营现金流和相关投入如何变化？',
    nextCheck: '下一期季度公告中的经营现金流与资本开支',
    factIds: ['F-BA-2', 'F-BA-3', 'F-BA-4'],
  },
  {
    id: 'DI-CPI-1', eventId: 'cpi-2508', version: 'v1',
    question: '物价在跌，核心物价却在涨？',
    metricIds: ['M-CPI-YOY', 'M-CPI-MOM', 'M-CPI-CORE'],
    interpIds: ['I-CPI-1'],
    boundary: '这次材料没有单独给出剔除翘尾后「新涨价因素」的完整数值，本页不自行推算。',
    openQuestion: '下个月翘尾影响变化后，核心 CPI 涨幅是否继续扩大？',
    nextCheck: '下一期 CPI 发布中的翘尾影响与核心 CPI',
    factIds: ['F-CPI-1', 'F-CPI-2', 'F-CPI-3', 'F-CPI-4'],
  },
];

export const EVIDENCE_REFS: EvidenceRef[] = [...REFS_BASE, ...REFS_2026];
export const METRICS: InsightMetric[] = [...METRICS_BASE, ...METRICS_2026];
export const INSIGHTS: DifferenceInsight[] = [...INSIGHTS_BASE, ...INSIGHTS_2026];

export const refById = (id: string) => EVIDENCE_REFS.find((r) => r.id === id);
export const metricById = (id: string) => METRICS.find((m) => m.id === id);

/** 图表行从指标表取数：同一个数字只存一份 */
export function metricRow(id: string, label?: string): FigureRow {
  const m = metricById(id);
  if (!m) throw new Error(`图表引用了不存在的指标：${id}`);
  return { label: label ?? m.label, value: m.value, display: m.display, metricId: m.id };
}
