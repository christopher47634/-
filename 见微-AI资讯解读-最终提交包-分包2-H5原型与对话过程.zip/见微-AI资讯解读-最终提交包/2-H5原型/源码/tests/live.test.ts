import { beforeEach, describe, expect, it } from 'vitest';
import { emStock, fromEm, fromSina, toSecucode } from '../src/logic/live';
import { liveAuthority, liveHeat, liveMagnitude, livePersonal, livePolicy, liveRecency, liveRelated, liveScope, liveScore, liveTopic, rankLive } from '../src/logic/liveRank';
import { __resetForTest, initialState } from '../src/logic/store';
import SNAP from '../src/data/liveSnapshot.json';

const em = (title: string, extra: Record<string, unknown> = {}) => fromEm({ code: '1', title, summary: `【${title}】正文`, showTime: '2026-09-28 19:00:00', ...extra });
const NOW = Date.parse('2026-09-28T19:10:00+08:00');

describe('实时快讯：解析', () => {
  beforeEach(() => __resetForTest());
  it('东方财富字段 → LiveItem；摘要去掉标题括号；只接沪深 A 股代码', () => {
    const it = em('贵州茅台：公告', { stockList: ['1.600519', '0.000333', '105.META', '116.00700'], pinglun_Num: 3, share: 2, titleColor: 1 });
    expect(it.summary).toBe('正文');
    expect(it.stocks).toEqual(['600519.SH', '000333.SZ']);
    expect(it.url).toBe('https://finance.eastmoney.com/a/1.html');
    expect(it.flagged).toBe(true);
    expect(emStock('105.META')).toBeNull();
  });
  it('新浪字段 → LiveItem（备用源）', () => {
    const it = fromSina({ id: 9, rich_text: '【标题】内容', create_time: '2026-09-28 19:40:20', ext: JSON.stringify({ stocks: [{ market: 'cn', symbol: 'sh600519' }, { market: 'us', symbol: 'snow' }], docurl: 'https://x' }), is_focus: 1 });
    expect(it).toMatchObject({ title: '标题', summary: '内容', stocks: ['600519.SH'], url: 'https://x', flagged: true, source: '新浪财经' });
  });
  it('代码补交易所后缀', () => {
    expect(toSecucode('600519')).toBe('600519.SH');
    expect(toSecucode('300750')).toBe('300750.SZ');
    expect(toSecucode('830799')).toBeNull();
  });
  it('离线快照可以直接解析', () => {
    const items = (SNAP as unknown as { news: Parameters<typeof fromEm>[0][] }).news.map(fromEm);
    expect(items.length).toBeGreaterThan(20);
    expect(items.every((i) => i.title && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(i.time))).toBe(true);
  });
});

describe('实时快讯：评分（与精选同一套权重）', () => {
  beforeEach(() => __resetForTest());
  it('关键词规则：范围、权威、政策、幅度', () => {
    expect(liveScope(em('美联储宣布加息25个基点'))[0]).toBe(5);
    expect(liveScope(em('国常会研究稳定房地产市场政策'))[0]).toBe(5);
    expect(liveAuthority(em('国家统计局：8月CPI同比上涨0.8%'))[0]).toBe(4);
    expect(liveAuthority(em('某公司：签订合同', { stockList: ['1.600000'] }))[0]).toBe(3);
    expect(livePolicy(em('央行宣布降准0.5个百分点'))[0]).toBe(5);
    expect(liveMagnitude(em('芯片出口同比增长35%，创历史新高'))[0]).toBe(5);
    expect(liveMagnitude(em('天气晴'))[0]).toBe(1);
  });
  it('快讯的来源权威最多 4 分：没有逐句核对，不和一手原文同分', () => {
    const sc = liveScore(initialState(), em('国家统计局：发布数据'), NOW);
    expect(sc.dims.find((d) => d.key === 'authority')!.score).toBeLessThanOrEqual(4);
  });
  it('时效按分钟：10 分钟前 5 分，2 天前 1 分', () => {
    expect(liveRecency(em('x'), NOW)[0]).toBe(5);
    expect(liveRecency(em('x'), NOW + 2 * 86400000)[0]).toBe(1);
  });
  it('热度来自真实信号，不是模拟值', () => {
    const [v, why] = liveHeat(em('x', { pinglun_Num: 5, share: 1, titleColor: 1 }));
    expect(v).toBe(40 + 20 + 4);
    expect(why).toContain('评论 5');
    expect(liveScore(initialState(), em('x'), NOW).simulatedHeat).toBe(false);
  });
  it('与我相关：关心的主题 +35，关注的公司 +45，看过的快讯降权', () => {
    const it = em('比亚迪：9月销量公布', { stockList: ['0.002594'] });
    const s0 = initialState();
    expect(livePersonal(s0, it)[0]).toBe(0);
    expect(livePersonal({ ...s0, topics: ['行业数据'] }, it)[0]).toBe(35);
    expect(livePersonal({ ...s0, finFollow: ['002594.SZ'] }, it)[0]).toBe(45);
    expect(livePersonal({ ...s0, finFollow: ['002594.SZ'], track: [{ name: 'live_open', key: it.id, at: '' }] }, it)[0]).toBe(30);
    expect(liveTopic(it)).toBe('行业数据');
  });
  it('排序：关注公司后它的快讯在「与我相关」里排第一', () => {
    const a = em('国常会研究稳定房地产市场政策', { code: 'a' });
    const b = { ...em('比亚迪：9月销量公布', { stockList: ['0.002594'] }), id: 'em-b' };
    const s = { ...initialState(), finFollow: ['002594.SZ'] };
    expect(rankLive(initialState(), [a, b], 'mix', NOW)[0].it.id).toBe(a.id);
    expect(rankLive(s, [a, b], 'attention', NOW)[0].it.id).toBe('em-b');
  });
  it('快讯能指向相关的精选解读', () => {
    expect(liveRelated(em('美联储主席鲍威尔讲话'))).toBe('fomc-2609');
    expect(liveRelated(em('8月CPI公布'))).toBe('price-2608');
    expect(liveRelated(em('无关'))).toBeUndefined();
  });
});
