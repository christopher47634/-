import { type CSSProperties, useLayoutEffect, useRef, useState } from 'react';
import type { Figure as F, FigureRow } from '../data/types';
import { useCountUp, useReveal } from '../logic/hooks';

/*
 * 数字本身就是内容：用一张小图把对比摆出来。
 * - 单一墨色；正值实心、负值斜线纹，数值标签带正负号——不靠颜色区分，也不用红绿（A 股红涨绿跌，会和「好坏」混淆）
 * - 进入视口时播放一次：柱子从零线长出、圆点沿杆滑到位置、斜线画出、区间从下往上升，数字从 0 滚到目标值
 * - 默认状态就是最终画面；减少动态效果或不支持 IntersectionObserver 时不播放
 */

const vars = (i: number): CSSProperties => ({ ['--i' as string]: i });

/** 行级引用：有 metricId 的行可以单独点开核对原文（键盘 Enter / 空格同样可用） */
export type RowPick = { onMetric?: (metricId: string) => void; focus?: string | null; off?: Set<string> };

export default function Figure({ fig, onSource, compact, onMetric, focus, off }: { fig: F; onSource?: () => void; compact?: boolean } & RowPick) {
  const rowsPickable = !!onMetric && (fig.kind === 'bars' || fig.kind === 'dots') && fig.rows.some((r) => r.metricId);
  const ref = useRef<HTMLElement>(null);
  const state = useReveal(ref);
  // 按实际像素宽度画图：宽屏上不再把 12px 的字放大成 24px
  const [w, setW] = useState(340);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => setW(Math.round(Math.min(640, Math.max(280, el.clientWidth - 32))));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <figure ref={ref} className={`fig${compact ? ' fig-compact' : ''}`} data-anim={state}>
      <figcaption className="fig-title">{fig.title}</figcaption>
      {fig.kind === 'bars' && <Bars fig={fig} run={state} W={w} pick={{ onMetric: rowsPickable ? onMetric : undefined, focus, off }} />}
      {fig.kind === 'dots' && <Dots fig={fig} run={state} W={w} pick={{ onMetric: rowsPickable ? onMetric : undefined, focus, off }} />}
      {fig.kind === 'slope' && <Slope fig={fig} W={w} />}
      {fig.kind === 'range' && <Range fig={fig} W={w} />}
      <div className="fig-foot">
        <span>{fig.note}</span>
        {rowsPickable ? <span className="fig-hint">点任一行，核对这一项的原文</span> : onSource && <button className="link" onClick={onSource}>看依据</button>}
      </div>
      {off && off.size > 0 && <p className="fig-off" role="status">图中标「来源不可用」的数字只作历史对照，不作为有效事实。</p>}
      <Table fig={fig} />
    </figure>
  );
}

type RS = 'idle' | 'armed' | 'in';
function Num({ text, run, i, ...p }: { text: string; run: RS; i: number } & React.SVGProps<SVGTextElement>) {
  const v = useCountUp(text, run, 180 + i * 70);
  return <text {...p} className="fig-value" style={vars(i)}>{v}</text>;
}

/** 可点的一行：整行热区 ≥ 44px，焦点环画在热区上 */
function RowHit({ r, y, h, W, pick }: { r: FigureRow; y: number; h: number; W: number; pick?: RowPick }) {
  if (!pick?.onMetric || !r.metricId) return null;
  const on = pick.focus === r.metricId;
  const dead = !!pick.off?.has(r.metricId);
  const go = () => pick.onMetric!(r.metricId!);
  return (
    <g
      className={`fig-row${on ? ' is-focus' : ''}`}
      role="button"
      tabIndex={0}
      aria-pressed={on}
      aria-label={`核对原文：${r.label} ${r.display}${dead ? '（来源不可用，仅作历史对照）' : ''}`}
      onClick={go}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } }}
    >
      <rect className="fig-hit" x={1} y={y + 1} width={W - 2} height={h - 2} rx={8} />
      {dead && <text x={W - 4} y={y + h - 5} textAnchor="end" className="fig-off-tag">来源不可用</text>}
    </g>
  );
}

function Hatch() {
  return (
    <defs>
      <pattern id="hatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <rect width="5" height="5" fill="var(--card)" />
        <line x1="0" y1="0" x2="0" y2="5" stroke="var(--ink-2)" strokeWidth="1.6" />
      </pattern>
    </defs>
  );
}

/** 12px 字号下的文字宽度估算：汉字和全角符号约 12px，其他字符约 7px */
const textW = (t: string) => [...t].reduce((a, c) => a + (/[⺀-￯—]/.test(c) ? 12 : 7), 0);

/** 行标签列宽：按最长标签估算，至少 base、最多图宽的 42% */
export function labelWidth(labels: string[], W: number, base: number) {
  return Math.round(Math.min(W * 0.42, Math.max(base, ...labels.map((l) => textW(l) + 10))));
}

/** 行标签：列宽放不下时折成两行（优先在「（」前断开），不压到右边的数值和柱子 */
function RowLabel({ text, y, width, i }: { text: string; y: number; width: number; i: number }) {
  if (textW(text) <= width - 8) return <text x={0} y={y} className="fig-label" dominantBaseline="middle" style={vars(i)}>{text}</text>;
  const k = text.indexOf('（') > 0 ? text.indexOf('（') : Math.ceil(text.length / 2);
  return (
    <text x={0} y={y} className="fig-label" style={vars(i)}>
      <tspan x={0} dy="-0.25em">{text.slice(0, k)}</tspan>
      <tspan x={0} dy="1.2em">{text.slice(k)}</tspan>
    </text>
  );
}

function Bars({ fig, run, W, pick }: { fig: Extract<F, { kind: 'bars' }>; run: RS; W: number; pick?: RowPick }) {
  const labelW = labelWidth(fig.rows.map((r) => r.label), W, 104), valW = 46, rowH = pick?.onMetric ? 44 : 30;
  const vals = fig.rows.map((r) => r.value);
  const lo = Math.min(0, ...vals), hi = Math.max(0, ...vals);
  const x = (v: number) => labelW + ((v - lo) / (hi - lo)) * (W - labelW - valW * 2) + valW;
  const H = fig.rows.length * rowH + 8;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="fig-svg" role="img" aria-label={fig.title}>
      <Hatch />
      <line x1={x(0)} x2={x(0)} y1={2} y2={H - 2} className="fig-zero" />
      {fig.rows.map((r, i) => {
        const y = 4 + i * rowH;
        const x0 = x(0), x1 = x(r.value);
        const left = Math.min(x0, x1), w = Math.max(Math.abs(x1 - x0), 2);
        const neg = r.value < 0;
        return (
          <g key={r.label} className={pick?.off?.has(r.metricId ?? '') ? 'is-off' : undefined}>
            <title>{`${r.label}：${r.display}`}</title>
            <RowLabel text={r.label} y={y + rowH / 2} width={labelW} i={i} />
            <rect x={left} y={y + (rowH - 14) / 2} width={w} height={14} rx={2} className={neg ? 'fig-bar neg' : 'fig-bar pos'} style={vars(i)} fill={neg ? 'url(#hatch)' : 'var(--ink-2)'} stroke="var(--ink-2)" strokeWidth={neg ? 1 : 0} />
            <Num text={r.display} run={run} i={i} x={neg ? left - 5 : left + w + 5} y={y + rowH / 2} textAnchor={neg ? 'end' : 'start'} dominantBaseline="middle" />
            <RowHit r={r} y={y} h={rowH} W={W} pick={pick} />
          </g>
        );
      })}
    </svg>
  );
}

function Dots({ fig, run, W, pick }: { fig: Extract<F, { kind: 'dots' }>; run: RS; W: number; pick?: RowPick }) {
  const labelW = labelWidth(fig.rows.map((r) => r.label), W, 96), rowH = pick?.onMetric ? 44 : 34, pad = 18;
  const x = (v: number) => labelW + pad + ((v - fig.min) / (fig.max - fig.min)) * (W - labelW - pad * 2);
  const H = fig.rows.length * rowH + 26;
  // 茎线从基准线出发；基准线必须落在坐标范围内，否则茎线会画出图外
  const base = Math.min(fig.max, Math.max(fig.min, fig.base ?? 0));
  const level = fig.base !== undefined; // 水平读数（如 PMI）：坐标写原值，不写涨跌幅
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="fig-svg" role="img" aria-label={fig.title}>
      <line x1={x(base)} x2={x(base)} y1={2} y2={H - 22} className="fig-zero" />
      <text x={x(base)} y={H - 6} textAnchor="middle" className="fig-axis">{level ? `${base}${fig.baseLabel ? ` ${fig.baseLabel}` : ''}` : '0'}</text>
      {base !== fig.min && <text x={x(fig.min)} y={H - 6} textAnchor="middle" className="fig-axis">{level ? fig.min : `${fig.min}%`}</text>}
      {base !== fig.max && <text x={x(fig.max)} y={H - 6} textAnchor="middle" className="fig-axis">{level ? fig.max : `+${fig.max}%`}</text>}
      {fig.rows.map((r, i) => {
        const y = 4 + i * rowH + rowH / 2;
        const neg = r.value < base;
        return (
          <g key={r.label} className={pick?.off?.has(r.metricId ?? '') ? 'is-off' : undefined}>
            <title>{`${r.label}：${r.display}`}</title>
            <RowLabel text={r.label} y={y} width={labelW} i={i} />
            <line x1={x(fig.min)} x2={x(fig.max)} y1={y} y2={y} className="fig-grid" />
            <line x1={x(base)} x2={x(r.value)} y1={y} y2={y} className={`fig-stem ${neg ? 'neg' : 'pos'}`} style={vars(i)} />
            <circle cx={x(r.value)} cy={y} r={5.5} className={neg ? 'fig-dot neg' : 'fig-dot'} style={{ ...vars(i), ['--dx' as string]: `${x(base) - x(r.value)}px` }} />
            <Num text={r.display} run={run} i={i} x={x(r.value)} y={y - 12} textAnchor="middle" />
            <RowHit r={r} y={y - rowH / 2} h={rowH} W={W} pick={pick} />
          </g>
        );
      })}
    </svg>
  );
}

function Slope({ fig, W }: { fig: Extract<F, { kind: 'slope' }>; W: number }) {
  const H = 64 * fig.rows.length + 22;
  const xa = Math.round(W * 0.44), xb = W - 44;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="fig-svg" role="img" aria-label={fig.title}>
      <text x={xa} y={12} textAnchor="middle" className="fig-axis">公布前</text>
      <text x={xb} y={12} textAnchor="middle" className="fig-axis">公布后</text>
      {fig.rows.map((r, i) => {
        const y = 26 + i * 64;
        const d = r.to - r.from;
        const y0 = y + 14, y1 = y + 14 + Math.max(-14, Math.min(14, -d * 40));
        return (
          <g key={r.label}>
            <title>{`${r.label}：${r.from}${r.unit} → ${r.to}${r.unit}`}</title>
            <text x={0} y={y + 18} className="fig-label" dominantBaseline="middle" style={vars(i)}>{r.label}</text>
            <line x1={xa} x2={xb} y1={y0} y2={y1} className="fig-stem fig-draw" pathLength={1} style={vars(i)} />
            <circle cx={xa} cy={y0} r={4.5} className="fig-dot hollow fig-pop" style={vars(i)} />
            <circle cx={xb} cy={y1} r={5.5} className="fig-dot fig-pop late" style={vars(i)} />
            <text x={xa - 10} y={y0} textAnchor="end" className="fig-value" dominantBaseline="middle" style={vars(i)}>{r.from}{r.unit}</text>
            <text x={xb + 12} y={y1} textAnchor="start" className="fig-value late" dominantBaseline="middle" style={vars(i)}>{r.to}{r.unit}</text>
          </g>
        );
      })}
    </svg>
  );
}

function Range({ fig, W }: { fig: Extract<F, { kind: 'range' }>; W: number }) {
  const lo = Math.min(...fig.steps.map((s) => s.lo)) - 0.25, hi = Math.max(...fig.steps.map((s) => s.hi)) + 0.25;
  const H = 150, top = 14, bottom = 118;
  const y = (v: number) => top + ((hi - v) / (hi - lo)) * (bottom - top);
  const colW = (W - 40) / fig.steps.length;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="fig-svg" role="img" aria-label={fig.title}>
      {[3.75, 4, 4.25, 4.5].filter((v) => v > lo && v < hi).map((v) => (
        <g key={v}>
          <line x1={34} x2={W} y1={y(v)} y2={y(v)} className="fig-grid" />
          <text x={0} y={y(v)} className="fig-axis" dominantBaseline="middle">{v.toFixed(2)}</text>
        </g>
      ))}
      {fig.steps.map((s, i) => {
        const cx = 40 + colW * i + colW / 2;
        return (
          <g key={s.label}>
            <title>{`${s.label}：${s.lo.toFixed(2)}%–${s.hi.toFixed(2)}%${s.derived ? '（推算）' : ''}`}</title>
            <rect x={cx - 22} y={y(s.hi)} width={44} height={y(s.lo) - y(s.hi)} rx={3} className={s.derived ? 'fig-band derived' : 'fig-band'} style={vars(i)} />
            <text x={cx} y={H - 16} textAnchor="middle" className="fig-label" style={vars(i)}>{s.label}</text>
            <text x={cx} y={H - 2} textAnchor="middle" className="fig-axis fig-fade" style={vars(i)}>{s.lo.toFixed(2)}–{s.hi.toFixed(2)}%</text>
          </g>
        );
      })}
    </svg>
  );
}

function Table({ fig }: { fig: F }) {
  return (
    <table className="sr-only">
      <caption>{fig.title}</caption>
      <tbody>
        {fig.kind === 'bars' || fig.kind === 'dots'
          ? fig.rows.map((r) => <tr key={r.label}><th>{r.label}</th><td>{r.display}</td></tr>)
          : fig.kind === 'slope'
            ? fig.rows.map((r) => <tr key={r.label}><th>{r.label}</th><td>{r.from}{r.unit} → {r.to}{r.unit}</td></tr>)
            : fig.steps.map((s) => <tr key={s.label}><th>{s.label}</th><td>{s.lo}%–{s.hi}%{s.derived ? '（推算）' : ''}</td></tr>)}
      </tbody>
    </table>
  );
}
