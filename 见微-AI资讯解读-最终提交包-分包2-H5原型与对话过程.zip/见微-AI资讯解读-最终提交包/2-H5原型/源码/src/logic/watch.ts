import { FACTS, INSIGHTS, eventById, interpById, metricById } from '../data/content';
import type { WatchItem } from '../data/types';
import { currentVersion, factState, interpEffective } from './gate';
import type { State } from './store';
import { eventView, viewInterpIds } from './view';
import { insightDeps, insightView, metricState } from './evidence';

const vnum = (v: string) => Number(v.replace(/\D/g, '')) || 0;

/** 一键关注：按当前有效版本生成默认观察卡（审阅 B：不能拿 v2 版本号配 v1 数字） */
export function makeWatch(s: State, eventId: string): WatchItem {
  const ev = eventById(eventId)!;
  const { summary, version } = eventView(s, ev);
  const iv = insightView(s, ev);
  const card = iv.kind === 'card' ? iv : null;
  const deps = card ? insightDeps(card.insight) : null;
  return {
    watchId: `w-${eventId}-${Date.now().toString(36)}`,
    eventId,
    savedVersion: version,
    savedAt: new Date().toISOString(),
    ackVersion: version,
    change: ev.newFacts,
    basis: card ? metricBasis(card.insight.metricIds) : summary.fact.text,
    openQuestion: card ? card.insight.openQuestion : summary.unknown,
    nextCheck: card ? card.insight.nextCheck : ev.watchSuggestions[0] ?? '尚未确定',
    note: '',
    paused: false,
    // 保存全部依赖，不预先过滤：之后任何一条状态变化都要能提示
    interpIds: viewInterpIds(s, ev),
    ...(card && deps ? { insightId: card.insight.id, insightVersion: card.version, factIds: deps.factIds, evidenceRefIds: deps.evidenceRefIds } : {}),
  };
}

/** 保存时的数字快照：「净利润 +76%、经营利润 −3%、经营现金流 −39%（2025 年 4–6 月）」 */
function metricBasis(ids: string[]) {
  const ms = ids.map(metricById).filter(Boolean);
  if (!ms.length) return '';
  return `${ms.map((m) => `${m!.label}${m!.basis.startsWith('同比') ? '同比' : m!.basis.split('（')[0]} ${m!.display}`).join('，')}（${ms[0]!.period}）`;
}

/** 系统自动写过的问题：用户没改过时可以换成本卡问题 */
function autoQuestions(eventId: string) {
  const ev = eventById(eventId)!;
  return new Set([ev.summary.unknown, ...Object.values(ev.revisions ?? {}).map((r) => r.summary?.unknown), ...INSIGHTS.filter((i) => i.eventId === eventId).map((i) => i.openQuestion)].filter(Boolean) as string[]);
}

/**
 * 同一事件已经关注过：合并，不重复建卡。
 * - 保存时版本、保存时间、采纳记录、私人笔记、暂停状态都不动
 * - 依赖取并集，之后任何一条变化都能提示
 * - 问题：用户没改过 → 换成本卡问题；改过 → 保留原问题，把本卡问题放进 suggestedQuestion，由用户决定是否采用
 */
export function mergeWatch(s: State, w: WatchItem): WatchItem {
  const fresh = makeWatch(s, w.eventId);
  const edited = !!w.openQuestion.trim() && !autoQuestions(w.eventId).has(w.openQuestion);
  const next: WatchItem = {
    ...w,
    interpIds: [...new Set([...(w.interpIds ?? []), ...fresh.interpIds])],
    factIds: [...new Set([...(w.factIds ?? []), ...(fresh.factIds ?? [])])],
    evidenceRefIds: [...new Set([...(w.evidenceRefIds ?? []), ...(fresh.evidenceRefIds ?? [])])],
    insightId: fresh.insightId ?? w.insightId,
    insightVersion: fresh.insightVersion ?? w.insightVersion,
    nextCheck: w.nextCheck.trim() ? w.nextCheck : fresh.nextCheck,
  };
  if (!edited) {
    next.openQuestion = fresh.openQuestion;
    delete next.suggestedQuestion;
  } else if (fresh.openQuestion !== w.openQuestion) {
    next.suggestedQuestion = fresh.openQuestion;
  }
  return next;
}

export type FollowResult = { watch: WatchItem; created: boolean; keptOwnQuestion: boolean };

/** 「关注这个问题」与「关注后续」共用：有就合并，没有就新建 */
export function followEvent(s: State, eventId: string): FollowResult {
  const existing = s.watches.find((w) => w.eventId === eventId);
  if (!existing) return { watch: makeWatch(s, eventId), created: true, keptOwnQuestion: false };
  const watch = mergeWatch(s, existing);
  return { watch, created: false, keptOwnQuestion: !!watch.suggestedQuestion };
}

export type WatchTone = 'ok' | 'update' | 'review' | 'stop';

export interface WatchStatus {
  tone: WatchTone;
  label: string;
  /** 有未看过的新版本 */
  unseenVersion: boolean;
  /** 保存时依赖、现在不在线的解释 */
  affected: { id: string; status: string; reason: string }[];
  simulated: boolean;
  seenVersion: string;
  current: string;
}

/*
 * 观察卡状态（审阅 D）：
 * - 撤回 / 来源缺失 → stop
 * - 待复核 / 被替代 → review（不能再显示绿色「内容正常」）
 * - 有没看过的新版本 → update，看过并采纳后消失
 */
export function watchStatus(s: State, w: WatchItem): WatchStatus {
  const current = currentVersion(s, w.eventId);
  const seenVersion = w.ackVersion ?? w.savedVersion;
  const unseenVersion = vnum(current) > vnum(seenVersion);
  const affected = w.interpIds
    .map((id) => {
      const i = interpById(id);
      if (!i) return { id, status: 'missing', reason: '解释已不存在' };
      const eff = interpEffective(s, i);
      return { id, status: eff.status, reason: eff.reason };
    })
    .filter((x) => x.status !== 'published' && x.status !== 'hidden');

  // 差异卡依赖的数字：来源不可用、配置失效要提示；被更正按版本更新处理
  if (w.insightId) {
    const ins = INSIGHTS.find((i) => i.id === w.insightId);
    if (!ins) affected.push({ id: w.insightId, status: 'missing', reason: '差异卡已不存在' });
    else for (const id of ins.metricIds) {
      const m = metricState(s, id, w.eventId);
      if (m.status === 'unavailable' || m.status === 'invalid') affected.push({ id, status: 'blocked', reason: `「${m.metric?.label ?? id}」${m.reason}` });
      else if (m.status === 'weak') affected.push({ id, status: 'needs_review', reason: `「${m.metric?.label ?? id}」${m.reason}` });
    }
  }

  // 已采纳新版本后，被新版本正常替代的旧解释不再算「待复核」
  const relevant = affected.filter((a) => !(a.status === 'superseded' && !unseenVersion));

  let tone: WatchTone = 'ok';
  let label = '暂无变化';
  if (relevant.some((a) => a.status === 'needs_review' || a.status === 'superseded' || a.status === 'draft')) {
    tone = 'review';
    label = '相关解释待复核';
  }
  if (unseenVersion) {
    tone = 'update';
    label = `有新材料：来源已更正（${seenVersion} → ${current}）`;
  }
  if (relevant.some((a) => a.status === 'withdrawn' || a.status === 'blocked' || a.status === 'missing')) {
    tone = 'stop';
    label = relevant.some((a) => a.status === 'withdrawn') ? '相关解释已撤回' : '依赖的来源暂不可用';
  }
  return { tone, label, unseenVersion, affected: relevant, simulated: !!s.demoUpdate[w.eventId] && vnum(current) > vnum(w.savedVersion), seenVersion, current };
}

/** 更新详情：相对「看过的版本」新增了什么、更正了什么；新增事实也要检查来源 */
export function watchDiff(s: State, w: WatchItem) {
  const seen = vnum(w.ackVersion ?? w.savedVersion);
  const cur = vnum(currentVersion(s, w.eventId));
  const facts = FACTS.filter((f) => f.eventId === w.eventId);
  const added = facts
    .filter((f) => f.introducedIn && vnum(f.introducedIn) > seen && vnum(f.introducedIn) <= cur)
    .map((f) => ({ fact: f, state: factState(s, f) }));
  const corrected = facts.filter((f) => f.supersededIn && vnum(f.supersededIn) > seen && vnum(f.supersededIn) <= cur);
  return { added, corrected };
}
