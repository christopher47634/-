import { ArrowLeft, ArrowUpRight, Bookmark, BookmarkCheck, Search } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { CURATED, type CuratedCompany, FIN_METRIC_FULL, FIN_METRIC_LABEL, type FinMetric, finPageUrl } from '../data/earnings2026';
import {
  type Change, type Comparison, type FinInsight, type MetricCompare, type Quarter, METRICS, VERDICT,
  compare, crossCheck, cumFromApi, cumFromCurated, cumLabel, explain, fmtPct, fmtYi, headline, latest, qLabel, qShort, selfCheck, toQuarters,
} from '../logic/earnings';
import { type FinState, SNAP_COMPANIES, type StockHit, annPdf, loadAnn, loadFin, reportFor, suggest, toSecucode, useLive } from '../logic/live';
import { back } from '../logic/router';
import { toggleFinFollow, track, useStore } from '../logic/store';
import { ThemeToggle } from '../components/bits';

/*
 * 财报对比（v0.8）：公司这一期和上一期（环比）、和去年同期（同比）比，变好了还是变差了。
 * 两种数据来源，页面上分开标注：
 *   已逐句核对原文 —— 四家公司，数字逐行对过巨潮资讯网上的报告原文，可跳到 PDF 对应页
 *   接口数据       —— 任意 A 股公司，实时取自东方财富 F10；没有逐句核对，但给出原文 PDF 链接和自检结果
 */

const hm = (iso: string) => (iso ? new Date(iso).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '');

interface View {
  secucode: string;
  name: string;
  curated?: CuratedCompany;
  /** 本页的比较用的是原文数还是接口数 */
  basis: 'verified' | 'api';
  qs: Quarter[];
  cmp: Comparison;
  insights: FinInsight[];
  head: string;
  /** 画图用：接口的单季序列（没有就用原文的四个季度） */
  chartQs: Quarter[];
  /** 接口里有比原文更新的一期 */
  newer?: [number, number];
}

function buildView(secucode: string, fin: FinState | undefined, preferApi: boolean): View | null {
  const curated = CURATED.find((c) => c.secucode === secucode);
  const apiQs = fin?.rows.length ? toQuarters(cumFromApi(fin.rows)) : [];
  const apiLatest = latest(apiQs);
  const name = curated?.name ?? fin?.rows[0]?.SECURITY_NAME_ABBR ?? secucode;
  if (curated) {
    const qs = toQuarters(cumFromCurated(curated));
    const newer = apiLatest && (apiLatest[0] > 2026 || (apiLatest[0] === 2026 && apiLatest[1] > 2)) ? apiLatest : undefined;
    if (preferApi && newer) {
      const cmp = compare(apiQs, newer[0], newer[1])!;
      const insights = explain(cmp);
      return { secucode, name, curated, basis: 'api', qs: apiQs, cmp, insights, head: headline(cmp, insights), chartQs: apiQs, newer };
    }
    const cmp = compare(qs, 2026, 2)!;
    const insights = explain(cmp);
    return { secucode, name, curated, basis: 'verified', qs, cmp, insights, head: headline(cmp, insights), chartQs: apiQs.length ? apiQs : qs, newer };
  }
  if (!apiLatest) return null;
  const cmp = compare(apiQs, apiLatest[0], apiLatest[1]);
  if (!cmp) return null;
  const insights = explain(cmp);
  return { secucode, name, basis: 'api', qs: apiQs, cmp, insights, head: headline(cmp, insights), chartQs: apiQs };
}

// ---------- 小部件 ----------

function Delta({ c, label, hint }: { c: Change; label: string; hint?: string }) {
  return (
    <div className={`fin-d d-${c.dir}`}>
      <span className="fin-d-k">{label}</span>
      <b className="num">{fmtPct(c)}</b>
      {hint && <span className="fin-d-v">{hint}</span>}
    </div>
  );
}

function Verdict({ c }: { c: Change }) {
  return <span className={`fin-v v-${c.dir}`}>{c.dir === 'up' ? '↑ ' : c.dir === 'down' ? '↓ ' : ''}{VERDICT[c.dir]}</span>;
}

function BasisTag({ v }: { v: View }) {
  return v.basis === 'verified' ? <span className="tag tag-verified">已逐句核对原文</span> : <span className="tag tag-api">接口数据 · 未逐句核对</span>;
}

/** 近 8 个季度的单季柱状图：本期、上一期、去年同期三根标出来 */
function FinChart({ qs, cmp, metric, note }: { qs: Quarter[]; cmp: Comparison; metric: FinMetric; note?: string }) {
  const data = qs.filter((q) => q.v[metric] != null).slice(-8);
  if (data.length < 2) return null;
  const W = 320, H = 132, top = 18, base = 96;
  const max = Math.max(...data.map((q) => Math.abs(q.v[metric]!)));
  const bw = Math.min(26, (W - 16) / data.length - 8);
  const step = (W - 16) / data.length;
  const [py, pq] = cmp.q === 1 ? [cmp.year - 1, 4] : [cmp.year, cmp.q - 1];
  const role = (q: Quarter) => (q.year === cmp.year && q.q === cmp.q ? 'cur' : q.year === py && q.q === pq ? 'prev' : q.year === cmp.year - 1 && q.q === cmp.q ? 'same' : '');
  return (
    <figure className="fin-chart">
      <figcaption>{FIN_METRIC_LABEL[metric]} · 单季（亿元）</figcaption>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${FIN_METRIC_LABEL[metric]}近 ${data.length} 个季度单季值`}>
        <line x1="8" x2={W - 8} y1={base} y2={base} className="fin-axis" />
        {data.map((q, i) => {
          const v = q.v[metric]!;
          const h = (Math.abs(v) / max) * (base - top);
          const x = 8 + i * step + (step - bw) / 2;
          const r = role(q);
          return (
            <g key={`${q.year}-${q.q}`} className={`fin-bar${r ? ` is-${r}` : ''}`}>
              <rect x={x} y={v >= 0 ? base - h : base} width={bw} height={Math.max(1, h)} rx="2" />
              <text x={x + bw / 2} y={v >= 0 ? base - h - 4 : base + h + 10} className="fin-val">{(v / 1e8).toFixed(Math.abs(v) >= 1e10 ? 0 : 1)}</text>
              <text x={x + bw / 2} y={base + 13} className="fin-q">{qShort(q.year, q.q)}</text>
              {r && <text x={x + bw / 2} y={base + 26} className="fin-role">{r === 'cur' ? '本期' : r === 'prev' ? '上一期' : '去年同期'}</text>}
            </g>
          );
        })}
      </svg>
      {note && <p className={`fin-chart-note${note.includes('口径不同') ? ' is-warn' : ''}`}>{note}</p>}
    </figure>
  );
}

function MetricBlock({ m, v }: { m: MetricCompare; v: View }) {
  const seasonal = v.insights.some((i) => i.kind === 'seasonal') && m.metric === 'rev';
  return (
    <div className="fin-m" data-metric={m.metric}>
      <div className="fin-m-head">
        <h3>{FIN_METRIC_LABEL[m.metric]}</h3>
        <span className="num fin-m-val">{fmtYi(m.cur)}</span>
        <Verdict c={m.yoy} />
      </div>
      <div className="fin-m-grid">
        <Delta c={m.qoq} label="环比" hint={seasonal ? `上一期 ${fmtYi(m.prevQ)} · 受季节影响` : `上一期 ${fmtYi(m.prevQ)}`} />
        <Delta c={m.yoy} label="同比" hint={`去年同期 ${fmtYi(m.sameQ)}`} />
        <Delta c={m.cumYoy} label="累计同比" hint={`${cumLabel(v.cmp.q)} · ${v.basis === 'verified' ? '原文直接给出' : '接口累计数'}`} />
      </div>
    </div>
  );
}

// ---------- 原文核对 ----------

function SourceCheck({ c, cmp }: { c: CuratedCompany; cmp: Comparison }) {
  const h1 = c.reports.find((r) => r.kind === 'H1')!;
  const q1 = c.reports.find((r) => r.kind === 'Q1')!;
  return (
    <section className="fin-src" aria-labelledby="fin-src-h">
      <h2 id="fin-src-h">逐项核对原文</h2>
      <p className="small dim">A 股定期报告是累计数：二季度单季 = 半年报（1–6 月）− 一季报（1–3 月）。下面每个数都能打开巨潮资讯网上的报告原文，跳到对应页。</p>
      {METRICS.map((k) => {
        const lh = c.lines.find((l) => l.reportId === h1.id && l.metric === k)!;
        const lq = c.lines.find((l) => l.reportId === q1.id && l.metric === k)!;
        const m = cmp.metrics[k];
        return (
          <details key={k} className="fin-src-item" data-metric={k}>
            <summary>
              <span>{FIN_METRIC_LABEL[k]}</span>
              <span className="num dim">本期 {fmtYi(m.cur)} = {fmtYi(lh.cur)} − {fmtYi(lq.cur)}</span>
            </summary>
            <ol className="fin-src-lines">
              {[[h1, lh], [q1, lq]].map(([r, l]) => {
                const rr = r as typeof h1;
                const ll = l as typeof lh;
                return (
                  <li key={rr.id}>
                    <p className="fin-src-where">{rr.title} · 第 {ll.page} 页 · 主要会计数据 · 单位：{rr.unit}</p>
                    <blockquote className="fin-quote">{ll.quote}</blockquote>
                    <p className="small dim">本期 {fmtYi(ll.cur, 2)}，上年同期 {fmtYi(ll.prev, 2)}。{FIN_METRIC_FULL[k] !== FIN_METRIC_LABEL[k] && `原文项目名：${FIN_METRIC_FULL[k]}。`}</p>
                    <a className="btn btn-ghost btn-sm" href={finPageUrl(rr, ll.page)} target="_blank" rel="noopener noreferrer">打开原文第 {ll.page} 页 <ArrowUpRight size={14} aria-hidden="true" /></a>
                  </li>
                );
              })}
            </ol>
            <p className="small">去年同期单季 {fmtYi(m.sameQ)} = {fmtYi(lh.prev)} − {fmtYi(lq.prev)}（两份报告里「上年同期」一栏）。</p>
          </details>
        );
      })}
    </section>
  );
}

function ApiCheck({ v, fin }: { v: View; fin?: FinState }) {
  if (!fin?.rows.length) return null;
  const sc = selfCheck(fin.rows, toQuarters(cumFromApi(fin.rows)));
  const cc = v.curated ? crossCheck(v.curated, fin.rows) : [];
  const diff = cc.filter((x) => !x.same);
  return (
    <section className="fin-api" aria-labelledby="fin-api-h">
      <h2 id="fin-api-h">和实时接口对一对</h2>
      <p className="small">
        <span className={`live-dot ${fin.status === 'live' ? 'is-live' : 'is-snap'}`} aria-hidden="true" />{' '}
        {fin.status === 'live' ? `东方财富 F10 实时数据 · ${hm(fin.at)} 取得` : `离线快照 · 采集于 ${hm(fin.at)}${fin.error ? `（实时接口取不到：${fin.error}）` : ''}`}
      </p>
      <ul className="fin-api-list">
        <li>单季推算自检：用累计数相减算出的单季同比、环比，和接口直接给的单季字段比较，<b className="num">{sc.ok}</b> 项一致（差 ≤0.5 个百分点）{sc.bad.length ? `，${sc.bad.length} 项不一致：${sc.bad.join('；')}` : '，没有不一致'}。</li>
        {v.curated && (
          <li>
            原文与接口：{cc.length - diff.length}/{cc.length} 个累计数完全一致。
            {diff.length > 0 && <> 不一致的 {diff.length} 个都是{[...new Set(diff.map((d) => FIN_METRIC_LABEL[d.metric]))].join('、')}，例如 {diff[0].label}：原文 {fmtYi(diff[0].mine, 2)}，接口 {fmtYi(diff[0].api, 2)}。</>}
          </li>
        )}
        {v.curated?.caliberNote && diff.length > 0 && <li className="warn">{v.curated.caliberNote}</li>}
      </ul>
    </section>
  );
}

function ApiSources({ v }: { v: View }) {
  const ann = useLive((s) => s.ann[v.secucode]);
  const cur = ann && reportFor(ann.list, v.cmp.year, v.cmp.q);
  const [py, pq] = v.cmp.q === 1 ? [v.cmp.year - 1, 4] : [v.cmp.year, v.cmp.q - 1];
  const prev = ann && reportFor(ann.list, py, pq);
  const same = ann && reportFor(ann.list, v.cmp.year - 1, v.cmp.q);
  const items = [[cur, '本期报告'], [prev, '上一期报告'], [same, '去年同期报告']].filter(([a]) => a) as [NonNullable<typeof cur>, string][];
  return (
    <section className="fin-src" aria-labelledby="fin-src-h">
      <h2 id="fin-src-h">原文在哪里</h2>
      <p className="small warn">这家公司的数字来自数据接口，本页没有逐句核对原文。下面是对应的定期报告全文，可以自己核对「主要会计数据」表。</p>
      {items.length ? (
        <ul className="fin-ann">
          {items.map(([a, label]) => (
            <li key={a.art_code}>
              <span className="dim small">{label} · {a.notice_date.slice(0, 10)}</span>
              <a href={annPdf(a.art_code)} target="_blank" rel="noopener noreferrer">{a.title} <ArrowUpRight size={14} aria-hidden="true" /></a>
            </li>
          ))}
        </ul>
      ) : <p className="small dim">{ann?.status === 'missing' ? '公告列表暂时取不到。' : '正在取公告列表…'}</p>}
      <p className="small dim">PDF 链接是东方财富的公告镜像，原始出处是交易所与巨潮资讯网。</p>
    </section>
  );
}

// ---------- 页面 ----------

export function FinDetail({ code }: { code: string }) {
  const secucode = toSecucode(code) ?? code;
  const fin = useLive((s) => s.fin[secucode]);
  const follow = useStore((s) => s.finFollow.includes(secucode));
  const [preferApi, setPreferApi] = useState(false);
  useEffect(() => {
    void loadFin(secucode);
    void loadAnn(secucode);
    track('fin_open', secucode);
  }, [secucode]);
  const v = useMemo(() => buildView(secucode, fin, preferApi), [secucode, fin, preferApi]);

  const head = (
    <header className="topbar is-glass">
      <button className="icon-btn" onClick={() => back('#/fin')} aria-label="返回"><ArrowLeft size={21} strokeWidth={1.7} /></button>
      <span className="topbar-title">财报对比</span>
      <ThemeToggle />
    </header>
  );

  if (!v) {
    return (
      <div className="page page-fin">
        {head}
        <div className="empty-state">
          <h2>{fin?.status === 'missing' ? '暂时取不到这家公司的财报数据' : '正在取数据…'}</h2>
          <p className="small dim">{fin?.error ?? `代码：${secucode}`}</p>
          <a className="btn btn-ghost" href="#/fin">回到财报对比</a>
        </div>
      </div>
    );
  }
  const { cmp } = v;
  // 核对过的公司：柱状图要 8 个季度，只能用接口序列；接口收入口径和原文不同时写明
  const chartNote = v.basis === 'verified' && fin?.rows.length && v.curated && crossCheck(v.curated, fin.rows).some((x) => x.metric === 'rev' && !x.same)
    ? '柱状图用接口数据（营业总收入），和上方原文的「营业收入」口径不同，数值略有出入。'
    : v.basis === 'verified' && fin?.rows.length ? '柱状图用接口数据画出 8 个季度；上方数字以原文为准，两者已核对一致。' : undefined;
  return (
    <div className="page page-fin">
      {head}
      <article className="fin-doc">
        <div className="meta">
          <BasisTag v={v} />
          <span>{v.curated?.industry ?? 'A 股'}</span>
          <span className="num">{secucode}</span>
        </div>
        <h1 className="fin-title">{v.name}：{qLabel(cmp.year, cmp.q)}，比上一期、比去年同期</h1>
        {v.curated && v.basis === 'verified' && <p className="fin-question">读者问：{v.curated.question}</p>}
        <p className="fin-head">{v.head}</p>

        {v.newer && (
          <div className="fin-newer" role="note">
            {v.basis === 'verified'
              ? <>接口里已有更新的一期：{qLabel(v.newer[0], v.newer[1])}（尚未逐句核对）。<button className="btn btn-ghost btn-sm" onClick={() => setPreferApi(true)}>看最新一期（接口数据）</button></>
              : <>正在看接口数据的最新一期。<button className="btn btn-ghost btn-sm" onClick={() => setPreferApi(false)}>回到已核对的 2026 年二季度</button></>}
          </div>
        )}

        <div className="fin-actions">
          <button className={`btn btn-sm ${follow ? 'btn-done' : 'btn-ghost'}`} aria-pressed={follow} onClick={() => toggleFinFollow(secucode)}>
            {follow ? <BookmarkCheck size={15} aria-hidden="true" /> : <Bookmark size={15} aria-hidden="true" />}
            {follow ? '已关注这家公司' : '关注这家公司'}
          </button>
          <span className="small dim">关注后，提到它的快讯会在「与我相关」里靠前。</span>
        </div>

        <section className="fin-metrics" aria-label="三个指标的对比">
          {METRICS.map((k) => <MetricBlock key={k} m={cmp.metrics[k]} v={v} />)}
        </section>
        <p className="small dim fin-rule">「改善 / 变差」只看同比，±3% 以内算基本持平；环比受季节影响大，只作参考。单季数由累计数相减推算。</p>

        <div className="fin-charts">
          <FinChart qs={v.chartQs} cmp={cmp} metric="rev" note={chartNote} />
          <FinChart qs={v.chartQs} cmp={cmp} metric="np" />
        </div>

        <section className="fin-ins" aria-labelledby="fin-ins-h">
          <h2 id="fin-ins-h">看懂这处差异</h2>
          {v.insights.length ? v.insights.map((i) => (
            <div key={i.kind} className={`fin-ins-item k-${i.kind}`}>
              <h3>{i.title}</h3>
              <p>{i.text}</p>
              <p className="small dim">用到的数：{i.uses.join('、')}。这是按固定规则得出的提示，不是公司的解释。</p>
            </div>
          )) : <p className="small dim">收入、利润的同比环比方向一致，没有触发任何差异规则。</p>}
        </section>

        {v.curated && v.basis === 'verified' && (
          <>
            <section className="fin-reasons" aria-labelledby="fin-why-h">
              <h2 id="fin-why-h">公司自己怎么说</h2>
              {v.curated.reasons.map((r) => {
                const rep = v.curated!.reports.find((x) => x.id === r.reportId)!;
                return (
                  <figure key={r.quote} className="fin-reason">
                    <figcaption><span className="tag">公司披露</span> 解释的是：{r.explains}</figcaption>
                    <blockquote className="fin-quote">{r.quote}</blockquote>
                    <a className="small" href={finPageUrl(rep, r.page)} target="_blank" rel="noopener noreferrer">{rep.title} 第 {r.page} 页 <ArrowUpRight size={13} aria-hidden="true" /></a>
                  </figure>
                );
              })}
            </section>
            <section className="fin-unknown" aria-labelledby="fin-unk-h">
              <h2 id="fin-unk-h">还不知道的</h2>
              <ul>{v.curated.unknowns.map((u) => <li key={u}>{u}</li>)}</ul>
            </section>
            <SourceCheck c={v.curated} cmp={cmp} />
          </>
        )}
        {(v.basis === 'api') && <ApiSources v={v} />}
        <ApiCheck v={v} fin={fin} />

        <p className="fin-next"><b>下次看：</b>{cmp.q === 2 ? '三季报（法定披露截止 10 月 31 日）：看单季同比能否延续。' : '下一期定期报告：看单季同比能否延续。'}</p>
        <p className="small dim">本页只做同口径比较，不评价股价，不构成投资建议。</p>
      </article>
    </div>
  );
}

function CuratedCard({ c }: { c: CuratedCompany }) {
  const qs = toQuarters(cumFromCurated(c));
  const cmp = compare(qs, 2026, 2)!;
  const ins = explain(cmp);
  return (
    <li>
      <a className="fin-card" href={`#/fin/${c.secucode}`} data-secu={c.secucode}>
        <div className="meta"><span className="tag tag-verified">已逐句核对原文</span><span>{c.industry}</span><span className="num">2026Q2</span></div>
        <h3 className="fin-card-title">{c.name}：{c.question}</h3>
        <p className="fin-card-head">{headline(cmp, ins)}</p>
        <div className="fin-card-grid">
          {(['rev', 'np'] as const).map((k) => (
            <div key={k} className="fin-card-m">
              <span className="dim">{FIN_METRIC_LABEL[k]}</span>
              <span className="num">同比 <b>{fmtPct(cmp.metrics[k].yoy)}</b></span>
              <span className="num dim">环比 {fmtPct(cmp.metrics[k].qoq)}</span>
            </div>
          ))}
        </div>
      </a>
    </li>
  );
}

function ApiChip({ hit }: { hit: StockHit }) {
  const fin = useLive((s) => s.fin[hit.secucode]);
  const v = useMemo(() => buildView(hit.secucode, fin, false), [hit.secucode, fin]);
  return (
    <li>
      <a className="fin-chip" href={`#/fin/${hit.secucode}`}>
        <span className="fin-chip-name">{hit.name}</span>
        {v ? <span className="num small">收入同比 {fmtPct(v.cmp.metrics.rev.yoy)} · 利润同比 {fmtPct(v.cmp.metrics.np.yoy)}</span> : <span className="small dim">{hit.code}</span>}
      </a>
    </li>
  );
}

export function FinHome() {
  const [q, setQ] = useState('');
  const [hits, setHits] = useState<StockHit[] | null>(null);
  const others = SNAP_COMPANIES.filter((c) => !CURATED.some((x) => x.secucode === c.secucode));
  useEffect(() => {
    for (const c of others) void loadFin(c.secucode);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    const k = q.trim();
    if (!k) { setHits(null); return; }
    const t = window.setTimeout(async () => setHits(await suggest(k)), 300);
    return () => window.clearTimeout(t);
  }, [q]);
  return (
    <section className="fin-home" aria-label="财报对比">
      <p className="fin-lede">公司这一期和<b>上一期</b>比（环比）、和<b>去年同期</b>比（同比），是变好了还是变差了？单季数由累计数相减推算，「改善 / 变差」只看同比。</p>
      <form className="search fin-search" role="search" onSubmit={(e) => { e.preventDefault(); const s = toSecucode(q.trim()) ?? hits?.[0]?.secucode; if (s) window.location.hash = `#/fin/${s}`; }}>
        <Search size={17} strokeWidth={1.75} aria-hidden="true" />
        <label className="sr-only" htmlFor="fin-q">输入 A 股代码或简称</label>
        <input id="fin-q" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="输入 A 股代码或简称，如 600519、美的" autoComplete="off" enterKeyHint="search" />
      </form>
      {hits && (
        <ul className="fin-hits" aria-label="搜索结果">
          {hits.length ? hits.map((h) => <li key={h.secucode}><a href={`#/fin/${h.secucode}`}><b>{h.name}</b> <span className="num dim">{h.secucode}</span></a></li>) : <li className="small dim">没有找到沪深 A 股里的这家公司。</li>}
        </ul>
      )}

      <h2 className="fin-h">已逐句核对原文的 4 家</h2>
      <ul className="fin-cards">{CURATED.map((c) => <CuratedCard key={c.secucode} c={c} />)}</ul>

      <h2 className="fin-h">更多公司 <span className="tag tag-api">接口数据 · 未逐句核对</span></h2>
      <ul className="fin-chips">{others.map((h) => <ApiChip key={h.secucode} hit={h} />)}</ul>
      <p className="note">四家公司的数字逐行对过巨潮资讯网上的半年报和一季报原文。其他公司来自东方财富 F10 实时接口：页面给出原文 PDF 链接和自检结果，但没有逐句核对。</p>
    </section>
  );
}

/** 首页上的财报对比入口：四家公司各一行结论 */
export function FinTeaser() {
  return (
    <section className="fin-teaser" aria-label="财报对比">
      <div className="live-strip-head">
        <h2>财报对比</h2>
        <a href="#/fin" className="live-more">搜索任意 A 股 <ArrowUpRight size={14} aria-hidden="true" /></a>
      </div>
      <p className="small dim">这一期比上一期、比去年同期，变好了还是变差了？</p>
      <ul className="fin-teaser-list">
        {CURATED.map((c) => {
          const cmp = compare(toQuarters(cumFromCurated(c)), 2026, 2)!;
          const ins = explain(cmp);
          return (
            <li key={c.secucode}>
              <a href={`#/fin/${c.secucode}`}>
                <b>{c.name}</b>
                <span className="num">收入同比 {fmtPct(cmp.metrics.rev.yoy)} · 利润同比 {fmtPct(cmp.metrics.np.yoy)}</span>
                <span className="dim">{ins[0]?.title ?? '走势一致'}</span>
              </a>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
