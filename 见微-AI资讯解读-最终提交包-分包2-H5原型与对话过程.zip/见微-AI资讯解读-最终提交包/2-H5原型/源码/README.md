# 见微 · AI 资讯解读（源文件 · v0.8）

| 版本 | 新增内容 |
|---|---|
| v0.8 | 实时快讯与实时财报数据；财报对比（这期比上一期、比去年同期） |
| v0.7 | 资讯扩充；重要程度 × 用户关注度双评分排序 |
| v0.6 | 「看懂这处差异」主卡；逐项核对原文 |

## 运行

需要 Node.js 18 或以上。`dist/` 是已经构建好的版本，不用安装依赖：

```bash
node serve.mjs          # 打开 http://localhost:4173
```

改代码时：

```bash
npm ci
npm run dev             # http://localhost:5178
npm run build           # 类型检查 + 构建到 dist/

# 单文件（双击打开的 HTML）：字体子集需要 fontTools，建议用项目虚拟环境
python -m venv .venv
.venv/Scripts/python -m pip install "fonttools[woff]" pypdf   # macOS/Linux 为 .venv/bin/python
.venv/Scripts/python scripts/subset-font.py
npx tsc -b && npx vite build --config vite.single.config.ts   # 产物 dist-single/index.html
```

## 实时数据

运行时，浏览器用 JSONP 直连东方财富（快讯、F10 财报、公告、代码联想）和新浪财经（快讯备用源），需要联网。取不到时，退回 `src/data/liveSnapshot.json` 里的离线快照，页面会写明采集时间。

更新快照：

```bash
node scripts/snapshot-live.mjs
```

## 验证

```bash
npm test                                    # 规则测试 86 项（含财报对比 12 项、实时快讯 11 项、图表范围 1 项）
node tests/figure-bounds.mjs <地址>          # 图表越界与重叠：首页 + 每篇详情，手机与桌面两个宽度
python scripts/verify-fin.py                # 财报原文核对：32 处摘录逐页比对 PDF（PDF 放在 ../research/earnings-2026/，从巨潮资讯网下载）
node tests/live-e2e.mjs <地址> [结果.json]    # 实时与财报 10 项：先联网跑，再屏蔽接口验证快照兜底
node tests/fin-outlink.mjs <结果.json>        # 财报原文页码外链：有界面 Chrome
node tests/rank-e2e.mjs <地址>                # 排序 9 项
node tests/insight-e2e.mjs <地址> <截图目录>   # 差异卡 24 项（也可传 file:///…/index.html）
node tests/outlink-verify.mjs <单文件 file:// 地址> <结果.json> 3 [base|v07]   # 外链定位：有界面 Chrome，每条 3 轮
node tests/e2e-cdp.mjs <地址>                 # 手机端交互 19 项
node tests/adapt.mjs   <地址>                 # 适配：320–430px、横屏、平板、桌面、字号 130%
node tests/desktop.mjs <地址>                 # 桌面端 10 项
node tests/theme.mjs   <地址>                 # 深色模式与自定义光标 8 项
```

## 目录

| 位置 | 内容 |
|---|---|
| `src/data/` | 来源、事实与解释（`content.ts`、`news2026.ts`）；事件（`events.ts`）；逐项证据与差异卡（`evidence.ts`）；四家公司财报原文逐行摘录（`earnings2026.ts`）；实时接口离线快照（`liveSnapshot.json`） |
| `src/logic/` | 状态仓库（含 v4→v5 迁移）、发布门禁、版本视图、逐项证据状态、关注合并、受限追问；双评分排序（`rank.ts`）；财报对比计算与差异规则（`earnings.ts`）；实时接口与快照兜底（`live.ts`）；快讯评分（`liveRank.ts`） |
| `src/components/` | 图表、差异卡、逐项证据、排序部件（`RankBits.tsx`）、快讯部件（`LiveBits.tsx`）、首屏流体、光标、依据抽屉、追问 |
| `src/pages/` | 首页（手机 / 桌面）、详情、财报对比（`Fin.tsx`）、关注、更新、内容工作台 |
| `src/styles/` | 基础样式、动效、桌面、光标、深色、证据与排序（`evidence.css`）、快讯与财报（`live.css`） |
| `scripts/` | 字体裁剪、实时快照抓取、财报原文核对 |

## 数据说明

| 内容 | 核对情况 |
|---|---|
| 精选解读、四家公司财报对比 | 数字已逐句核对原文 |
| 实时快讯、其他公司财报 | 接口数据，页面已标注「未逐句核对」 |
| 教学案例、示范公司 | 虚构 |

审核流程为模拟。不构成投资建议。
