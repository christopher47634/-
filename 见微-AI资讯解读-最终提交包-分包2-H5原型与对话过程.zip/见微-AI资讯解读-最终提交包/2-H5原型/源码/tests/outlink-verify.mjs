// 外部原文定位的真实验证：在有界面的 Chrome 里打开单文件成品，像用户一样点「打开原文定位」，
// 读新窗口里目标句子是否在视口内。每条连测 N 轮，全部落点才记为 located。
//   node tests/outlink-verify.mjs <单文件 file:// 地址> <结果 json> [轮数]
import { writeFileSync } from 'node:fs';
import { launch, sleep } from './cdp.mjs';
//   第 4 个参数选用例集：base（v0.6 的 8 条）/ v07（v0.7 新增的 15 条统计局原文）
const [URL0, OUT, ROUNDS = '3', SET = 'base'] = process.argv.slice(2);
const b = await launch({ headed: true });
await b.viewport(1440, 900, false, 1);
const im = (i) => `document.querySelectorAll('.insight .im-check')[${i}]`;
const casesV07 = [
  ['R-PF-YTD', 'profit-2608', im(0), '全国规模以上工业企业实现利润总额'],
  ['R-PF-AUG', 'profit-2608', im(1), '规模以上工业企业利润同比增长4.2%'],
  ['R-PF-REV', 'profit-2608', im(2), '规模以上工业企业实现营业收入'],
  ['R-PR-PPI', 'price-2608', im(0), '全国工业生产者出厂价格同比上涨'],
  ['R-PR-CPI', 'price-2608', im(1), '全国居民消费价格同比上涨'],
  ['R-PR-CORE-JD', 'price-2608', im(2), '扣除食品和能源价格的核心'],
  ['R-MC-IND', 'macro-2608', im(0), '规模以上工业增加值同比实际增长'],
  ['R-MC-RET', 'macro-2608', im(1), '社会消费品零售总额39824亿元'],
  ['R-MC-FAI', 'macro-2608', im(2), '全国固定资产投资（不含农户）'],
  ['R-RE-SALES', 'realestate-2608', im(0), '新建商品房销售面积49880万平方米'],
  ['R-RE-2ND', 'realestate-2608', im(1), '二手房交易网签面积'],
  ['R-RE-INV', 'realestate-2608', im(2), '全国房地产开发投资47979亿元'],
  ['R-PM-M', 'pmi-2608', im(0), '制造业采购经理指数（PMI）为49.8%'],
  ['R-PM-NO', 'pmi-2608', im(1), '新订单指数为50.6%'],
  ['R-PM-SMALL', 'pmi-2608', im(2), '小型企业PMI为47.9%'],
];
const casesBase = [
  // [引用, 事件, 打开方式, 在原站要找的句子]
  ['R-BA-NI', 'baba-2506', `document.querySelectorAll('.insight .im-check')[0]`, 'Net income was RMB42,382'],
  ['R-BA-OP', 'baba-2506', `document.querySelectorAll('.insight .im-check')[1]`, 'Income from operations was RMB34,988'],
  ['R-BA-OCF', 'baba-2506', `document.querySelectorAll('.insight .im-check')[2]`, 'Net cash provided by operating activities was RMB20,672'],
  ['R-BA-REV', 'baba-2506', `document.querySelectorAll('.fig-row')[0]`, 'Revenue was RMB247,652'],
  ['R-BA-LFL', 'baba-2506', `document.querySelectorAll('.fig-row')[1]`, 'like-for-like basis would'],
  ['R-CPI-YOY', 'cpi-2508', `document.querySelectorAll('.insight .im-check')[0]`, '全国居民消费价格同比下降'],
  ['R-CPI-MOM', 'cpi-2508', `document.querySelectorAll('.insight .im-check')[1]`, '全国居民消费价格环比持平'],
  ['R-CPI-CORE-JD', 'cpi-2508', `document.querySelectorAll('.insight .im-check')[2]`, '扣除食品和能源价格的核心'],
];
const cases = SET === 'v07' ? casesV07 : casesBase;
const probe = (needle) => `(()=>{const n0=${JSON.stringify(needle)}.replace(/\\s+/g,'');const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;const map=[];let flat='';while((n=w.nextNode())){const t=n.textContent;for(let i=0;i<t.length;i++){if(!/\\s/.test(t[i])){flat+=t[i];map.push([n,i]);}}}const at=flat.indexOf(n0);if(at<0)return {found:false,scrollY:scrollY,title:document.title.slice(0,80),len:document.body.innerText.length};const [a,i0]=map[at],[z,i1]=map[at+n0.length-1];const r=document.createRange();r.setStart(a,i0);r.setEnd(z,i1+1);const bb=r.getBoundingClientRect();return {found:true,top:Math.round(bb.top),bottom:Math.round(bb.bottom),vh:innerHeight,scrollY:Math.round(scrollY)}})()`;
async function evalIn(wsUrl, expr) {
  const ws = new WebSocket(wsUrl);
  await new Promise((r) => ws.addEventListener('open', r));
  const res = await new Promise((r) => { ws.addEventListener('message', (m) => { const d = JSON.parse(m.data); if (d.id === 1) r(d.result?.result?.value); }); ws.send(JSON.stringify({ id: 1, method: 'Runtime.evaluate', params: { expression: expr, returnByValue: true } })); });
  ws.close();
  return res;
}
const list = async () => (await (await fetch(`http://127.0.0.1:${b.port}/json/list`)).json()).filter((t) => t.type === 'page');
const out = { browser: (await b.send('Browser.getVersion')).product, at: new Date().toISOString(), method: '有界面 Chrome；从单文件成品里真实点击外链（target=_blank, rel=noopener noreferrer），读取新窗口中目标句子的位置', results: [] };
for (const [ref, ev, opener, needle] of cases) {
  const rounds = [];
  for (let k = 0; k < +ROUNDS; k++) {
    await b.send('Page.navigate', { url: URL0 + '#/e/' + ev });
    await sleep(1800);
    await b.click(opener);
    await sleep(400);
    const before = new Set((await list()).map((t) => t.id));
    const href = await b.ev(`document.querySelector('.panel .mx-open a')?.href`);
    const label = await b.ev(`document.querySelector('.panel .mx-open a')?.textContent`);
    await b.click(`document.querySelector('.panel .mx-open a')`);
    let tab;
    for (let i = 0; i < 40 && !tab; i++) { await sleep(250); tab = (await list()).find((t) => !before.has(t.id)); }
    if (!tab) { rounds.push({ ok: false, why: '没有打开新窗口' }); continue; }
    await sleep(7000);
    const t2 = (await list()).find((t) => t.id === tab.id);
    const r = await evalIn(t2.webSocketDebuggerUrl, probe(needle));
    const ok = !!r?.found && r.scrollY > 0 && r.top >= 0 && r.bottom <= r.vh;
    rounds.push({ ok, ...r, url: t2.url.slice(0, 140) });
    await fetch(`http://127.0.0.1:${b.port}/json/close/${tab.id}`);
    await sleep(300);
    if (k === 0) out.results.push({ ref, href, label });
  }
  const row = out.results.find((x) => x.ref === ref);
  row.rounds = rounds;
  row.result = rounds.every((x) => x.ok) ? 'located' : rounds.some((x) => x.ok) ? 'unstable' : rounds.some((x) => x.found) ? 'openedOnly' : 'failed';
  console.log(ref, row.result, rounds.map((x) => (x.ok ? 'ok' : `no(${x.scrollY ?? x.why})`)).join(' '));
}
writeFileSync(OUT, JSON.stringify(out, null, 2));
b.close(); process.exit(0);
