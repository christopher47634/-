import { describe, expect, it } from 'vitest';
import { CURATED, curatedBySecu } from '../src/data/earnings2026';
import { type CumRow, change, compare, crossCheck, cumFromApi, cumFromCurated, explain, fmtPct, headline, latest, selfCheck, toQuarters } from '../src/logic/earnings';
import SNAP from '../src/data/liveSnapshot.json';

const snap = SNAP as unknown as { fin: Record<string, Parameters<typeof cumFromApi>[0]> };
const view = (secu: string) => {
  const c = curatedBySecu(secu)!;
  const cmp = compare(toQuarters(cumFromCurated(c)), 2026, 2)!;
  return { c, cmp, ins: explain(cmp) };
};

describe('财报对比：口径与计算', () => {
  it('单季 = 本期累计 − 上期累计；一季度就是一季报本身', () => {
    const rows: CumRow[] = [
      { year: 2026, q: 1, rev: 100, np: 10, kf: 9 },
      { year: 2026, q: 2, rev: 250, np: 22, kf: 20 },
      { year: 2026, q: 3, rev: 390, np: null, kf: 30 },
    ];
    const qs = toQuarters(rows);
    expect(qs.map((q) => q.v.rev)).toEqual([100, 150, 140]);
    expect(qs[2].v.np).toBeNull(); // 缺数据就是 null，不硬凑
    expect(qs[0].derived).toBe(false);
    expect(qs[1].derived).toBe(true);
  });
  it('缺上一期累计时，单季为 null', () => {
    const qs = toQuarters([{ year: 2026, q: 2, rev: 250, np: 22, kf: 20 }]);
    expect(qs[0].v.rev).toBeNull();
  });
  it('同比 / 环比：±3% 以内持平；去年亏损不算百分比', () => {
    expect(change(102, 100).dir).toBe('flat');
    expect(change(110, 100)).toMatchObject({ dir: 'up' });
    expect(change(5, -3)).toMatchObject({ pct: null, note: '扭亏为盈', dir: 'up' });
    expect(change(-1, -3)).toMatchObject({ note: '亏损收窄', dir: 'up' });
    expect(change(-5, 3)).toMatchObject({ note: '由盈转亏', dir: 'down' });
    expect(fmtPct(change(90, 100))).toBe('−10.0%');
  });
  it('原文摘录里的数和结构化数一致（单位换算正确）', () => {
    for (const c of CURATED) {
      expect(c.lines).toHaveLength(6);
      for (const l of c.lines) {
        const unit = c.reports.find((r) => r.id === l.reportId)!.unit;
        const nums = [...l.quote.matchAll(/\d{1,3}(?:,\d{3})+(?:\.\d+)?/g)].map((m) => Number(m[0].replace(/,/g, '')) * (unit === '千元' ? 1000 : 1));
        expect(nums.slice(0, 2)).toEqual([l.cur, l.prev]);
      }
    }
  });
  it('四家公司的二季度单季数（与人工核算一致）', () => {
    const mt = view('600519.SH').cmp.metrics;
    expect(mt.rev.cur! / 1e8).toBeCloseTo(367.94, 1);
    expect(mt.rev.qoq.pct!).toBeCloseTo(-31.7, 1);
    expect(mt.rev.yoy.pct!).toBeCloseTo(-5.1, 1);
    expect(mt.rev.cumYoy.pct!).toBeCloseTo(1.47, 1); // 原文直接给出 1.47
    const byd = view('002594.SZ').cmp.metrics;
    expect(byd.np.yoy.pct!).toBeCloseTo(29.7, 1);
    expect(byd.kf.yoy.pct!).toBeCloseTo(51.5, 1);
    expect(view('688981.SH').cmp.metrics.np.yoy.pct!).toBeCloseTo(228.9, 1);
  });
});

describe('财报对比：看懂这处差异', () => {
  it('茅台：环比 −31.7% 是季节性，去年同季环比也是 −23.3%；同比由增转降', () => {
    const { ins, cmp } = view('600519.SH');
    expect(ins.map((i) => i.kind)).toEqual(['seasonal', 'turn']);
    expect(ins[0].text).toContain('−23.3%');
    expect(headline(cmp, ins)).toContain('季节性');
  });
  it('比亚迪：收入降、利润升排第一；去年同季非经常性收益多', () => {
    const { ins } = view('002594.SZ');
    expect(ins[0].kind).toBe('divergence');
    expect(ins[0].title).toBe('收入降、利润升');
    expect(ins.find((i) => i.kind === 'nonRecurring')!.text).toContain('9.27 亿');
  });
  it('宁德时代：增收不同步增利；环比 +14% 不算季节性误导', () => {
    const { ins } = view('300750.SZ');
    expect(ins.map((i) => i.kind)).toEqual(['divergence']);
    expect(ins[0].title).toBe('增收不同步增利');
  });
  it('中芯国际：低基数排第一', () => {
    const { ins } = view('688981.SH');
    expect(ins[0].kind).toBe('lowBase');
    expect(ins.map((i) => i.kind)).toContain('nonRecurring');
  });
});

describe('财报对比：和接口数据对照（离线快照）', () => {
  it('自己推算的单季同比 / 环比与接口单季字段逐项一致', () => {
    for (const [secu, rows] of Object.entries(snap.fin)) {
      const r = selfCheck(rows, toQuarters(cumFromApi(rows)));
      expect(r.bad, secu).toEqual([]);
      expect(r.ok, secu).toBeGreaterThan(10);
    }
  });
  it('原文累计数与接口一致；茅台收入是营业总收入 vs 营业收入的口径差', () => {
    for (const c of CURATED) {
      const cc = crossCheck(c, snap.fin[c.secucode]);
      expect(cc.length).toBe(12);
      const diff = cc.filter((x) => !x.same);
      if (c.code === '600519') {
        expect(diff.map((d) => d.metric)).toEqual(['rev', 'rev', 'rev', 'rev']);
        expect(diff.every((d) => d.api > d.mine)).toBe(true);
        expect(c.caliberNote).toContain('营业总收入');
      } else expect(diff, c.name).toEqual([]);
    }
  });
  it('每家公司都能算出最新一期的对比', () => {
    for (const rows of Object.values(snap.fin)) {
      const qs = toQuarters(cumFromApi(rows));
      const l = latest(qs)!;
      expect(compare(qs, l[0], l[1])).not.toBeNull();
    }
  });
});
