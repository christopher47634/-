import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' 让构建产物可以放在任意子目录下用静态服务打开
export default defineConfig({
  base: './',
  plugins: [react()],
  server: { port: 5178, strictPort: true, host: true },
  test: { environment: 'node', include: ['tests/**/*.test.ts'] },
});
