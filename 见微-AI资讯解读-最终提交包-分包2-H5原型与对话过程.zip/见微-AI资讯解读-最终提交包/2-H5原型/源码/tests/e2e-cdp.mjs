// 端到端交互验收（v0.2）：本机 Chrome headless + CDP 真实点击，零依赖。
//   node tests/e2e-cdp.mjs [http://localhost:4173] [截图目录]
// 覆盖 2026-09-24 审阅清单 A–E 的浏览器复现路径。
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { byText, launch, q, sleep } from './cdp.mjs';

const BASE = process.argv[2] || 'http://localhost:5178';
const OUT = process.argv[3] || join(process.cwd(), '..', '04-过程记录', '开发与验证截图-v0.2');
mkdirSync(OUT, { recursive: true });
const b = await launch();
const shot = (n, full) => b.shot(join(OUT, n + '.png'), full);
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
async function check(name, fn) {
  try { await fn(); results.push(['PASS', name]); console.log('PASS', name); }
  catch (e) { results.push(['FAIL', name, e.message]); console.log('FAIL', name, '—', e.message); }
}
const store = () => b.ev(`JSON.parse(localStorage.getItem('jianwei.demo.v5')||'{}')`);
const openDisc = async (id) => { if (!(await b.ev(`${q('#' + id)}.classList.contains('is-open')`))) await b.click(`${q('#' + id + ' .disc-btn')}`); };
const studioRow = (id) => `[...document.querySelectorAll('.studio-list > li')].find(li=>li.querySelector('.mono').textContent==='${id}')`;

await b.viewport(390, 844);
await b.send('Page.navigate', { url: (BASE.endsWith('.html') ? BASE : BASE + '/') + '#/' });
await sleep(1200);
await b.ev('localStorage.clear()');
await b.send('Page.reload');
await sleep(1400);

await check('首页：答案先行，首条解读在首屏内，演示样本默认隐藏，无水平溢出', async () => {
  await b.waitFor(`document.querySelector('.lead-title')`);
  const top = await b.ev(`document.querySelector('.lead-title').getBoundingClientRect().top`);
  assert(top < 330, '首条标题位置过低：' + top);
  assert(await b.ev(`document.querySelector('.lead-answer').textContent.length > 20`), '缺少一句话答案');
  assert(await b.ev(`document.querySelectorAll('.lead, .row').length === 11`), '普通模式应为 11 条（v0.7 扩充后）');
  assert(!(await b.ev(`!!document.querySelector('a[href="#/e/demo-a"]')`)), '普通模式出现了演示样本');
  assert(!(await b.ev(`!!document.querySelector('canvas')`)), '不应再有流体背景');
  assert(await b.noOverflow(), '水平溢出');
  await shot('01-首页');
});

await check('搜索按需展开、主题筛选', async () => {
  await b.click(q('.search-toggle'));
  await b.waitFor(q('#q'));
  await b.click(q('#q'));
  await b.type('现金流');
  assert(await b.ev(`document.querySelectorAll('.lead, .row').length === 1`), '搜索结果不对');
  await b.click(`document.querySelector('.search .icon-btn')`);
  await b.click(byText('.topic', '行业数据'));
  assert(await b.ev(`document.querySelector('.lead-title').textContent.includes('核心物价')`), '筛选不对');
  await b.click(byText('.topic', '全部'));
});

await check('简读：一句答案 + 图 + 要点 + 不能下结论；其余默认折叠', async () => {
  // v0.7 起首页按评分排序，头条不再固定是阿里巴巴；直接进入这条样本
  await b.go('#/e/baba-2506');
  await b.waitFor(q('.gist'));
  assert(await b.ev(`(!!document.querySelector('.answer') || !!document.querySelector('.insight-explain')) && !!document.querySelector('.fig') && (!!document.querySelector('.gist-unknown') || !!document.querySelector('.insight-bound'))`), '简读结构不全');
  assert(await b.ev(`document.querySelectorAll('.gist-points li').length >= 2 && document.querySelectorAll('.gist-points li').length <= 3`), '要点应为 2–3 条');
  assert(await b.ev(`document.querySelectorAll('.disc.is-open').length === 0`), '简读下不应默认展开');
  assert(!(await b.ev(`/I-BA|F-BA/.test(document.body.innerText)`)), '普通模式露出了技术编号');
  await shot('02-详情-简读', true);
});

await check('细读：展开所有分节，而不是往末尾追加', async () => {
  await b.click(byText('.depth button', '细读'));
  assert(await b.ev(`document.querySelectorAll('.disc.is-open').length >= 5`), '细读未展开');
  await b.click(byText('.depth button', '简读'));
  assert(await b.ev(`document.querySelectorAll('.disc.is-open').length === 0`), '切回简读未收起');
});

await check('原文依据抽屉：打开原文在前；Esc 关闭并把焦点还给引用', async () => {
  await b.click(`document.querySelector('.gist-points .cite')`);
  await b.waitFor(`document.querySelector('[role=dialog]')`);
  const t = await b.ev(`document.querySelector('[role=dialog]').textContent`);
  assert(t.includes('打开原文') && t.includes('在原文哪里') && t.includes('不能支持') && t.includes('有原文支持'), '抽屉内容不全');
  assert(await b.ev(`document.querySelector('[role=dialog]').contains(document.activeElement)`), '焦点不在抽屉内');
  await shot('03-原文依据');
  await b.key('Escape');
  assert(await b.ev(`!document.querySelector('[role=dialog]')`), '未关闭');
  assert(await b.ev(`document.activeElement?.classList.contains('cite')`), '焦点未回到引用');
});

await check('历史复盘：当时的疑问 → 后来的材料 → 判断', async () => {
  await openDisc('sec-retro');
  assert(await b.ev(`document.querySelectorAll('.retro-later li').length === 3`), '后续材料条数不对');
  assert(await b.ev(`document.querySelector('.retro').textContent.includes('2025-11-25') && document.querySelector('.retro-verdicts').textContent.includes('支持')`), '复盘内容不全');
  await b.ev(`document.querySelector('#sec-retro').scrollIntoView({block:'start'})`); await sleep(300);
  await shot('04-历史复盘');
});

await check('口径对照在折叠区内可用', async () => {
  await openDisc('sec-cmp');
  await b.click(byText('.cmp-tabs button', '净利润'));
  assert(await b.ev(`document.querySelector('.cmp-tabs button.on').textContent.includes('净利润') && document.querySelectorAll('.cmp-others .diff').length > 0`), '对照不对');
});

await check('审阅 C：追问不再误拒术语问题；普通界面不推荐荐股问题', async () => {
  await b.click(byText('.actionbar button', '追问'));
  await b.waitFor(`document.querySelector('[role=dialog] .chip')`);
  assert(!(await b.ev(`document.querySelector('[role=dialog]').textContent.includes('买哪只')`)), '仍在推荐荐股问题');
  await b.click(q('#ask')); await b.type('投资收益是什么意思'); await b.key('Enter');
  await b.waitFor(`[...document.querySelectorAll('.turn-a')].some(e=>e.textContent.includes('编辑部撰写'))`);
  assert(!(await b.ev(`!!document.querySelector('.turn-boundary')`)), '术语问题被误拒');
  await b.click(q('#ask')); await b.type('现在该买哪只股票'); await b.key('Enter');
  await b.waitFor(q('.turn-boundary'));
  await b.click(q('#ask')); await b.type('明年利润会怎样'); await b.key('Enter');
  await b.waitFor(q('.turn-uncovered'));
  await b.click(byText('.chip', '自由现金流为什么变成负的'));
  await b.waitFor(`[...document.querySelectorAll('.turn-a')].some(e=>e.textContent.includes('淘宝闪购'))`);
  await shot('05-追问');
  await b.key('Escape');
});

await check('一键关注：一次点击完成，轻提示，不进表单', async () => {
  await b.click(byText('.actionbar button', '关注后续'));
  await b.waitFor(q('.toast'));
  assert(await b.ev(`location.hash === '#/e/baba-2506'`), '不应跳转到表单');
  assert(await b.ev(`document.querySelector('.actionbar .btn-done')?.textContent.includes('已关注')`), '按钮未变为已关注');
  await shot('06-一键关注');
  const s = await store();
  assert(s.watches.length === 1 && s.watches[0].interpIds.includes('I-BA-1'), '关注未保存依赖');
});

await check('教学案例（审阅 E）：前提是市场报价，切换采购/售价只改推论', async () => {
  await b.go('#/e/teach-cost');
  await b.waitFor(q('.gist'));
  assert(await b.ev(`document.querySelector('.gist-fact').textContent.includes('市场报价')`), '摘要前提不是市场报价');
  await openDisc('sec-path');
  const before = await b.ev(`[...document.querySelectorAll('.pnode-title')].map(e=>e.textContent)`);
  assert(before[0].includes('市场报价'), '首节点不一致');
  await b.click(byText('.switch', '产品售价也下降'));
  const after = await b.ev(`[...document.querySelectorAll('.pnode-title')].map(e=>e.textContent)`);
  assert(after[0] === before[0] && after[2] === '需比较售价与成本下降幅度', '推论未按条件变化：' + after[2]);
  await b.ev(`document.querySelector('#sec-path').scrollIntoView({block:'start'})`); await sleep(500);
  await shot('07-条件切换');
  await b.click(byText('.switch', '采购价已跟随'));
  assert(await b.ev(`document.querySelectorAll('.pnode-title')[1].textContent.includes('未必下降')`), '采购条件未生效');
});

await check('关注列表：刷新后仍在；状态为暂无变化', async () => {
  await b.go('#/watch');
  await b.send('Page.reload'); await sleep(1200);
  await b.waitFor(`document.querySelectorAll('.watch').length === 1`);
  assert(await b.ev(`document.querySelector('.watch-state').classList.contains('state-ok')`), '初始状态不对');
});

await check('演示模式：从页脚打开；示范公司 A 出现', async () => {
  await b.click(`document.querySelector('.demo-switch')`);
  await b.go('#/');
  await b.waitFor(`!!document.querySelector('a[href="#/e/demo-a"]')`);
});

await check('演示更新 → 查看变化 → 采纳新版后不再重复提示', async () => {
  await b.go('#/e/demo-a');
  await b.click(byText('.actionbar button', '关注后续'));
  await b.go('#/watch');
  await b.click(byText('.demo-box button', '加载演示更新'));
  await b.waitFor(`[...document.querySelectorAll('.watch')].some(w=>w.querySelector('.state-update') && w.querySelector('.tag-demo'))`);
  await shot('08-关注-演示更新', true);
  await b.click(`[...document.querySelectorAll('.watch')].find(w=>w.querySelector('.state-update')).querySelector('.btn-primary')`);
  await b.waitFor(`location.hash.startsWith('#/update/')`);
  const t = await b.ev(`document.querySelector('.reading').textContent`);
  assert(t.includes('10.2 亿元') && t.includes('已被更正') && t.includes('演示更新'), '更新页内容不全');
  await shot('09-更新详情', true);
  await b.click(byText('.upd-actions button', '采纳'));
  await b.waitFor(q('.acked'));
  await b.go('#/watch');
  assert(!(await b.ev(`[...document.querySelectorAll('.watch')].some(w=>w.querySelector('.state-update'))`)), '采纳后仍提示同一次更新');
  const s = await store();
  assert(s.watches.find((w) => w.eventId === 'demo-a').savedVersion === 'v1', '保存时版本被改写');
});

await check('审阅 B：v2 下新建的关注用更正后的依据', async () => {
  await b.go('#/watch');
  await b.click(`[...document.querySelectorAll('.watch')].find(w=>w.querySelector('a[href="#/e/demo-a"]')).querySelector('.watch-actions button:last-child')`);
  await b.go('#/e/demo-a');
  await b.click(byText('.actionbar button', '关注后续'));
  const w = (await store()).watches.find((x) => x.eventId === 'demo-a');
  assert(w.savedVersion === 'v2' && w.basis.includes('10.2') && !w.basis.includes('12.0') && w.interpIds.includes('I-DA-2'), JSON.stringify(w).slice(0, 200));
});

await check('审阅 A：撤回 v2 解释 → 摘要、细读、追问、关注同步停止', async () => {
  await b.go('#/studio');
  await b.click(`${studioRow('I-DA-2')}.querySelector('.btn-danger')`);
  await b.go('#/e/demo-a');
  await b.waitFor(`document.querySelector('.gist-points .stopped')`);
  assert(await b.ev(`document.querySelector('.gist-points .stopped').textContent.includes('已撤回')`), '摘要未停止');
  assert(!(await b.ev(`document.querySelector('.gist').textContent.includes('失去了数字前提')`)), '摘要仍显示已撤回解释的正文');
  await b.click(byText('.depth button', '细读'));
  assert(await b.ev(`document.querySelector('.interps').textContent.includes('已撤回')`), '细读未显示已撤回');
  await b.click(byText('.depth button', '简读'));
  await shot('10-撤回后-摘要');
  await b.click(byText('.actionbar button', '追问'));
  await b.click(byText('.chip', '更正后收入是多少'));
  await b.waitFor(q('.turn .stopped'));
  await b.key('Escape');
  await b.go('#/watch');
  await b.waitFor(`[...document.querySelectorAll('.watch .state-stop')].length >= 1`);
});

await check('撤回真实解释 I-BA-1：阿里巴巴摘要与路径同步停止', async () => {
  await b.go('#/studio');
  await b.click(`${studioRow('I-BA-1')}.querySelector('.btn-danger')`);
  await b.go('#/e/baba-2506');
  await b.waitFor(`document.querySelector('.gist-points .stopped')`);
  await openDisc('sec-path');
  assert(await b.ev(`[...document.querySelectorAll('.pnode')].some(p=>p.classList.contains('is-stopped'))`), '路径未停止');
});

await check('来源缺失（虚构来源）：阻断依赖解释，保留可核实事实；工作台边界测试分类正确', async () => {
  await b.go('#/studio');
  await b.click(byText('.btn', '恢复演示初始状态'));
  assert(await b.ev(`[...document.querySelectorAll('.track li')].find(li=>li.textContent.includes('投资收益是什么意思')).textContent.includes('术语解释')`), '边界测试分类不对');
  assert(await b.ev(`[...document.querySelectorAll('.track li')].find(li=>li.textContent.includes('现在该买哪只股票')).textContent.includes('边界反馈')`), '荐股分类不对');
  await b.click(`[...document.querySelectorAll('.src-list li')].find(li=>li.textContent.includes('S-DEMO-CALL')).querySelector('.switch')`);
  await shot('11-内容工作台', true);
  await b.go('#/e/demo-a');
  await b.waitFor(`document.querySelector('.gist-points .stopped')`);
  assert(await b.ev(`document.querySelector('.gist-points .stopped').textContent.includes('来源暂不可用')`), '未提示来源缺失');
  assert(await b.ev(`document.querySelector('.gist-fact').textContent.includes('12.0 亿元')`), '可核实事实被误删');
});

await check('清除本地数据', async () => {
  await b.go('#/watch');
  await b.click(byText('.danger-zone button', '清除本地数据'));
  await b.click(byText('.confirm button', '确认清除'));
  await b.waitFor(`document.querySelectorAll('.watch').length === 0`);
  assert(await b.ev(`localStorage.getItem('jianwei.demo.v5') === null && localStorage.getItem('jianwei.demo.v4') === null`), '未清除');
});

await check('减少动态效果与控制台', async () => {
  await b.send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-reduced-motion', value: 'reduce' }] });
  await b.send('Page.reload'); await sleep(1200);
  await b.go('#/e/fomc-2509');
  await shot('12-FOMC-简读', true);
  const real = b.problems.filter((p) => !/favicon/.test(p));
  assert(real.length === 0, real.join(' | '));
});

const pass = results.filter((r) => r[0] === 'PASS').length;
console.log(`\n${pass}/${results.length} 项通过；截图：${OUT}`);
writeFileSync(join(OUT, 'e2e-结果.json'), JSON.stringify({ base: BASE, at: new Date().toISOString(), results, problems: b.problems }, null, 2));
b.close();
process.exit(pass === results.length ? 0 : 1);
