import { factById, interpById } from '../data/content';
import type { EventItem, PathNode, Point, Summary } from '../data/types';
import { type Effective, currentVersion, factState, interpEffective, isLive } from './gate';
import { insightView } from './evidence';
import type { State } from './store';

/*
 * 按当前版本取事件的要点与路径。
 * 所有页面（详情、观察卡、更新页）都从这里取，不再各自写 v2 特例——
 * 这是 2026-09-24 审阅 A/B 两个问题的根因：摘要和观察卡各有一条绕过状态检查的分支。
 */
export function eventView(s: State, ev: EventItem): { summary: Summary; path: PathNode[]; version: string } {
  const version = currentVersion(s, ev.id);
  const rev = ev.revisions?.[version];
  return { summary: rev?.summary ?? ev.summary, path: rev?.path ?? ev.path, version };
}

/** 一条要点当前能不能展示：依赖解释要在线，依赖事实要有效 */
export function pointState(s: State, p: Point): { live: boolean; eff?: Effective; reason?: string } {
  if (p.interpId) {
    const i = interpById(p.interpId);
    if (!i) return { live: false, reason: '解释不存在' };
    const eff = interpEffective(s, i);
    return isLive(eff) ? { live: true, eff } : { live: false, eff, reason: eff.reason };
  }
  if (p.factId) {
    const f = factById(p.factId);
    const st = f ? factState(s, f) : 'missing';
    if (st === 'active') return { live: true };
    return { live: false, reason: st === 'corrected' ? '这条事实已被更正。' : st === 'missing' ? '依赖的来源暂不可用。' : '这条事实不属于当前版本。' };
  }
  return { live: true };
}

/** 当前版本下，事件依赖的所有解释 id（要点 + 路径 + 差异卡），去重 */
export function viewInterpIds(s: State, ev: EventItem): string[] {
  const { summary, path } = eventView(s, ev);
  const iv = insightView(s, ev);
  const ids = [...summary.points.map((p) => p.interpId), ...path.map((n) => n.interpId), ...(iv.kind === 'card' ? iv.insight.interpIds : [])].filter(Boolean) as string[];
  return [...new Set(ids)];
}
