import { useEffect, useState } from 'react';

/* hash 路由：静态产物放到任意目录都能直接演示 */

export type Route =
  | { name: 'home'; tab: HomeTab }
  | { name: 'fin'; code: string }
  | { name: 'detail'; id: string }
  | { name: 'watchEdit'; eventId: string; watchId?: string }
  | { name: 'update'; watchId: string }
  | { name: 'studio' };

export type HomeTab = 'feed' | 'live' | 'fin' | 'watch';

export function parse(hash: string): Route {
  const p = hash.replace(/^#\/?/, '').split('/').filter(Boolean).map(decodeURIComponent);
  if (p[0] === 'e' && p[1]) return { name: 'detail', id: p[1] };
  if (p[0] === 'watch' && p[1] === 'new' && p[2]) return { name: 'watchEdit', eventId: p[2] };
  if (p[0] === 'watch' && p[1] === 'edit' && p[2] && p[3]) return { name: 'watchEdit', eventId: p[2], watchId: p[3] };
  if (p[0] === 'update' && p[1]) return { name: 'update', watchId: p[1] };
  if (p[0] === 'watch') return { name: 'home', tab: 'watch' };
  if (p[0] === 'live') return { name: 'home', tab: 'live' };
  if (p[0] === 'fin' && p[1]) return { name: 'fin', code: p[1] };
  if (p[0] === 'fin') return { name: 'home', tab: 'fin' };
  if (p[0] === 'studio') return { name: 'studio' };
  return { name: 'home', tab: 'feed' };
}

const scrollMemo = new Map<string, number>();

export function useRoute(): Route {
  const [hash, setHash] = useState(() => window.location.hash);
  useEffect(() => {
    let prev = window.location.hash;
    const on = () => {
      scrollMemo.set(prev, window.scrollY);
      prev = window.location.hash;
      setHash(prev);
      // 返回时恢复原来的阅读位置，前进到新页面时回到顶部
      const y = scrollMemo.get(prev) ?? 0;
      requestAnimationFrame(() => window.scrollTo({ top: y, behavior: 'instant' as ScrollBehavior }));
    };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return parse(hash);
}

export const go = (h: string) => {
  window.location.hash = h;
};

export const back = (fallback = '#/') => {
  if (window.history.length > 1) window.history.back();
  else go(fallback);
};
