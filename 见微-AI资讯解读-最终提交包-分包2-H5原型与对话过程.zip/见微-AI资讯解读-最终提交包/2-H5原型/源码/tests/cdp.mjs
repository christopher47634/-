// CDP 小工具：本机 Chrome headless + 真实输入事件，零依赖。e2e 与适配截图共用。
import { spawn } from 'node:child_process';
import { existsSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function launch(opts = {}) {
  const chrome = [
    'C:/Program Files/Google/Chrome/Application/chrome.exe',
    'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/usr/bin/google-chrome',
  ].find(existsSync);
  if (!chrome) throw new Error('找不到 Chrome/Edge');
  const port = 9333 + Math.floor(Math.random() * 400);
  const proc = spawn(chrome, [...(opts.headed ? ['--window-size=1280,900'] : ['--headless=new']), `--remote-debugging-port=${port}`, `--user-data-dir=${join(tmpdir(), 'jianwei-cdp-' + port)}`, '--no-first-run', '--no-default-browser-check', '--hide-scrollbars', 'about:blank'], { stdio: 'ignore' });
  let targets = [];
  for (let i = 0; i < 60 && !targets.length; i++) {
    try { targets = (await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).filter((t) => t.type === 'page'); } catch {}
    if (!targets.length) await sleep(200);
  }
  const ws = new WebSocket(targets[0].webSocketDebuggerUrl);
  await new Promise((r) => ws.addEventListener('open', r));
  let id = 0;
  const pending = new Map();
  const problems = [];
  ws.addEventListener('message', (m) => {
    const d = JSON.parse(m.data);
    if (d.id && pending.has(d.id)) { pending.get(d.id)(d); pending.delete(d.id); }
    if (d.method === 'Runtime.exceptionThrown') problems.push('exception: ' + d.params.exceptionDetails.exception?.description?.split('\n')[0]);
    if (d.method === 'Runtime.consoleAPICalled' && d.params.type === 'error') problems.push('console.error: ' + d.params.args.map((a) => a.value ?? a.description).join(' '));
    if (d.method === 'Log.entryAdded' && d.params.entry.level === 'error') problems.push('log: ' + d.params.entry.text + ' ' + (d.params.entry.url || ''));
  });
  const send = (method, params = {}) => new Promise((res, rej) => {
    const i = ++id; pending.set(i, (d) => (d.error ? rej(new Error(method + ': ' + d.error.message)) : res(d.result)));
    ws.send(JSON.stringify({ id: i, method, params }));
  });
  const ev = async (expr) => {
    const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) throw new Error('eval: ' + expr.slice(0, 90) + ' → ' + r.exceptionDetails.exception?.description);
    return r.result.value;
  };
  await send('Page.enable'); await send('Runtime.enable'); await send('Log.enable');

  const vp = { w: 390, h: 844, mobile: true, dpr: 2 };
  const api = {
    send, ev, problems, vp, port,
    // 桌面用 1x：headless 下 WebGL 持续绘制时，2x 截图会卡住
    async viewport(w, h, mobile = w < 768, dpr = mobile ? 2 : 1) { Object.assign(vp, { w, h, mobile, dpr }); await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: dpr, mobile }); },
    async go(hash) { await ev(`location.hash = ${JSON.stringify(hash)}`); await sleep(450); },
    async waitFor(expr, ms = 4000) {
      const t = Date.now();
      while (Date.now() - t < ms) { if (await ev(`!!(${expr})`)) return true; await sleep(80); }
      throw new Error('等待超时：' + expr);
    },
    async click(expr) {
      await ev(`(${expr}).scrollIntoView({block:'center', inline:'center'})`);
      await sleep(220);
      const r = await ev(`(()=>{const b=(${expr}).getBoundingClientRect();return {x:b.left+b.width/2,y:b.top+b.height/2}})()`);
      for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type, x: r.x, y: r.y, button: 'left', clickCount: 1 });
      await sleep(320);
    },
    async key(k) {
      await send('Input.dispatchKeyEvent', { type: 'keyDown', key: k, code: k, windowsVirtualKeyCode: { Escape: 27, Enter: 13, Tab: 9 }[k], ...(k === 'Enter' ? { text: String.fromCharCode(13) } : {}) });
      await send('Input.dispatchKeyEvent', { type: 'keyUp', key: k, code: k });
      await sleep(220);
    },
    async type(t) { await send('Input.insertText', { text: t }); await sleep(120); },
    async shot(file, full = false) {
      if (full) {
        const h = Math.min(await ev('document.documentElement.scrollHeight'), 5200);
        // 超长页面在软件渲染下截 2x 很慢，改 1x
        await send('Emulation.setDeviceMetricsOverride', { width: vp.w, height: h, deviceScaleFactor: h > 2500 ? 1 : vp.dpr, mobile: vp.mobile });
        await sleep(450);
      }
      const { data } = await send('Page.captureScreenshot', { format: 'png' });
      writeFileSync(file, Buffer.from(data, 'base64'));
      if (full) { await api.viewport(vp.w, vp.h, vp.mobile, vp.dpr); await sleep(150); }
    },
    // 用 clientWidth 而不是 innerWidth：移动端内容溢出时布局视口会跟着变宽，innerWidth 会一起变大，查不出问题
    noOverflow: () => ev('document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1 && innerWidth <= visualViewport.width + 1'),
    close() { ws.close(); proc.kill(); },
  };
  return api;
}

export const q = (sel) => `document.querySelector(${JSON.stringify(sel)})`;
export const byText = (sel, text) => `[...document.querySelectorAll(${JSON.stringify(sel)})].find(e=>e.textContent.includes(${JSON.stringify(text)}))`;
