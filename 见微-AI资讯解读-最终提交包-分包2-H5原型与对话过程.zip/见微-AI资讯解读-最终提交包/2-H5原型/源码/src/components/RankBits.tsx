import { ChevronDown, SlidersHorizontal } from 'lucide-react';
import { useId, useState } from 'react';
import { TOPICS } from '../data/content';
import type { EventItem } from '../data/types';
import { ATTN, type Dim, LEAD_MIN, MIX, RANK_DATE, type Score, SORT_LABEL, type SortMode, W, rankReason, score } from '../logic/rank';
import { setSort, toggleTopic, useStore } from '../logic/store';

/*
 * 排序相关的小部件：两个分数、排序切换、排序说明、单条资讯的评分拆解。
 * 分数只决定展示顺序，页面上始终写明「不代表投资价值」；大众热度是模拟值，始终标注。
 */

/** 卡片上的两个分数：重要程度 + 关注度，各带一条细刻度 */
export function ScoreChips({ sc, rank }: { sc: Score; rank?: number }) {
  return (
    <span className="sc" aria-label={`第 ${rank ?? ''} 位，重要程度 ${sc.importance} 分，关注度 ${sc.attention} 分`}>
      {rank !== undefined && <span className="sc-rank num">{String(rank).padStart(2, '0')}</span>}
      <span className="sc-item"><span className="sc-k">重要</span><span className="sc-bar" aria-hidden="true"><i style={{ width: `${sc.importance}%` }} /></span><b className="num">{sc.importance}</b></span>
      <span className="sc-item sc-attn"><span className="sc-k">关注</span><span className="sc-bar" aria-hidden="true"><i style={{ width: `${sc.attention}%` }} /></span><b className="num">{sc.attention}</b></span>
    </span>
  );
}

/** 排序切换 + 可展开的排序说明（含「我关心的主题」） */
export function SortBar() {
  const mode = useStore((s) => s.sort);
  const topics = useStore((s) => s.topics);
  const [open, setOpen] = useState(false);
  const rid = useId();
  return (
    <div className="sortbar">
      <div className="sort-row">
        <div className="sort-seg" role="group" aria-label="排序方式">
          {(Object.keys(SORT_LABEL) as SortMode[]).map((m) => (
            <button key={m} aria-pressed={mode === m} className={mode === m ? 'on' : ''} onClick={() => setSort(m)}>{SORT_LABEL[m]}</button>
          ))}
        </div>
        <button className="sort-why" aria-expanded={open} aria-controls={rid} onClick={() => setOpen((v) => !v)}>
          <SlidersHorizontal size={16} strokeWidth={1.75} aria-hidden="true" /> 排序说明
        </button>
      </div>
      {open && (
        <div className="sort-explain" id={rid}>
          <p><b>重要程度</b>（0–100）：影响范围 {W.scope} · 来源权威 {W.authority} · 变化幅度 {W.magnitude} · 政策关联 {W.policy} · 时效 {W.recency}。和谁在看无关。</p>
          <p><b>用户关注度</b>（0–100）：大众热度 × {ATTN.heat}（<span className="warn">演示用模拟值</span>）+ 与我相关 × {ATTN.personal}（只用本机的关注、阅读和下面选的主题；不收集持仓与资产）。</p>
          <p><b>综合</b> = 重要程度 × {MIX.importance} + 关注度 × {MIX.attention}。<b>头条护栏：</b>重要程度低于 {LEAD_MIN} 的不上头条，热度再高也不行。</p>
          <div className="sort-topics" role="group" aria-label="我关心的主题">
            <span className="small dim">我关心的主题</span>
            {TOPICS.filter((t) => t !== '全部').map((t) => (
              <button key={t} className={`chip-sm${topics.includes(t) ? ' on' : ''}`} aria-pressed={topics.includes(t)} onClick={() => toggleTopic(t)}>{t}</button>
            ))}
          </div>
          <p className="small dim">分数只决定展示顺序，不代表投资价值。资讯池更新于 {RANK_DATE}，时效分按这一天计算。</p>
        </div>
      )}
    </div>
  );
}

export function DimRow({ d, unit }: { d: Dim; unit: 'five' | 'hundred' }) {
  return (
    <li className="rk-row">
      <span className="rk-label">{d.label}</span>
      <span className="rk-bar" aria-hidden="true"><i style={{ width: `${(d.score / d.max) * 100}%` }} /></span>
      <span className="rk-val num">{unit === 'five' ? `${d.score}/5` : d.score} → {Math.round(d.points)}</span>
      <span className="rk-why">{d.why}</span>
    </li>
  );
}

/** 详情页：为什么这条排在这里 */
export function RankBreakdown({ ev }: { ev: EventItem }) {
  const s = useStore((x) => x);
  const sc = score(s, ev);
  const [open, setOpen] = useState(false);
  const rid = useId();
  return (
    <section className="rk">
      <button className="rk-head" aria-expanded={open} aria-controls={rid} onClick={() => setOpen((v) => !v)}>
        <span className="rk-title">为什么推荐给你</span>
        <ScoreChips sc={sc} />
        <ChevronDown size={18} strokeWidth={1.75} aria-hidden="true" />
      </button>
      {open && (
        <div id={rid} className="rk-body">
          <p className="small">{rankReason(sc)}。</p>
          <h4>重要程度 {sc.importance}</h4>
          <ul className="rk-list">{sc.dims.map((d) => <DimRow key={d.key} d={d} unit="five" />)}</ul>
          <h4>用户关注度 {sc.attention}</h4>
          <ul className="rk-list">{sc.attnDims.map((d) => <DimRow key={d.key} d={d} unit="hundred" />)}</ul>
          <p className="small dim">综合 {sc.total} = 重要程度 × {MIX.importance} + 关注度 × {MIX.attention}。大众热度为演示模拟值；分数只决定展示顺序，不代表投资价值。</p>
        </div>
      )}
    </section>
  );
}
