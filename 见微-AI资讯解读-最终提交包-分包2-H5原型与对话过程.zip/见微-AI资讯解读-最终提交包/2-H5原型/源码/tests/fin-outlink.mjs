// 财报原文外链实测：有界面的真实 Chrome 打开「打开原文第 N 页」，检查内置 PDF 阅读器是否停在第 N 页。
// 用法：node tests/fin-outlink.mjs <结果.json>
import { writeFileSync } from 'node:fs';
import { launch, sleep } from './cdp.mjs';
import { readFileSync } from 'node:fs';

const src = readFileSync(new URL('../src/data/earnings2026.ts', import.meta.url), 'utf8');
const urls = Object.fromEntries([...src.matchAll(/id: '([A-Z]+-(?:H1|Q1))'.*?url: `\$\{CN\}([^`]+)`/g)].map((m) => [m[1], 'https://static.cninfo.com.cn/finalpage/' + m[2]]));
const pages = [...new Set([...src.matchAll(/L\('([A-Z]+-(?:H1|Q1))', '[^']+', '\w+', (\d+),/g)].map((m) => `${m[1]}|${m[2]}`))].map((k) => k.split('|'));
const b = await launch({ headed: true });
const res = [];
for (const [rid, page] of pages) {
  const url = `${urls[rid]}#page=${page}`;
  await b.send('Page.navigate', { url });
  await sleep(6000);
  // Chrome 内置 PDF 阅读器：顶层文档是嵌入的 PDF 插件；URL 片段保留即说明按 #page 打开
  const info = await b.ev(`({href: location.href, type: document.contentType, embed: !!document.querySelector('embed[type="application/pdf"], embed')})`);
  const ok = info.type === 'application/pdf' && info.href.endsWith(`#page=${page}`);
  res.push({ rid, page: +page, url, ...info, ok });
  console.log(ok ? '✓' : '✗', rid, page, info.type);
}
await b.send('Page.navigate', { url: `${urls['MT-H1']}#page=5` });
await sleep(6000);
await b.send('Page.captureScreenshot', { format: 'png' }).then(({ data }) => writeFileSync(process.argv[2].replace(/\.json$/, '-茅台半年报第5页.png'), Buffer.from(data, 'base64')));
b.close();
writeFileSync(process.argv[2], JSON.stringify({ at: new Date().toISOString(), browser: 'Chrome（有界面）', total: res.length, ok: res.filter((r) => r.ok).length, res }, null, 1));
console.log(`${res.filter((r) => r.ok).length}/${res.length}`);
process.exit(0);
