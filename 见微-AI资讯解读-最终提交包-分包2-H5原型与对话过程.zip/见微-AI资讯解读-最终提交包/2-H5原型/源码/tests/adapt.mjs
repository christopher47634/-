// 适配检查：多种视口下的溢出、点击目标、字号和截图。
//   node tests/adapt.mjs [http://localhost:4173] [截图目录]
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { launch, sleep } from './cdp.mjs';

const BASE = process.argv[2] || 'http://localhost:5178';
const OUT = process.argv[3] || join(process.cwd(), '..', '04-过程记录', '适配截图');
mkdirSync(OUT, { recursive: true });

const b = await launch();
const VIEWS = [
  ['320-小屏', 320, 640], ['360-安卓', 360, 780], ['375-iPhone-SE', 375, 667], ['390-iPhone', 390, 844],
  ['430-大屏', 430, 932], ['横屏-844x390', 844, 390], ['平板-768', 768, 1024], ['桌面-1440', 1440, 900],
];
const ROUTES = [['首页', '#/'], ['详情', '#/e/baba-2506'], ['详情-CPI', '#/e/cpi-2508'], ['关注', '#/watch']];
const report = [];

await b.viewport(390, 844);
await b.send('Page.navigate', { url: (BASE.endsWith('.html') ? BASE : BASE + '/') + '#/' });
await sleep(1200);
await b.ev('localStorage.clear()');
await b.send('Page.reload');
await sleep(1200);

for (const [name, w, h] of VIEWS) {
  await b.viewport(w, h);
  for (const [rname, hash] of ROUTES) {
    await b.go(hash);
    if (hash.startsWith('#/e/')) { await b.ev(`[...document.querySelectorAll('.disc:not(.is-open) .disc-btn')].forEach(x=>x.click())`); }
    await sleep(300);
    const m = await b.ev(`(()=>{
      const vw = document.documentElement.clientWidth;
      const over = [...document.querySelectorAll('body *')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.right>vw+1)&&!e.closest('.topics,.cmp-tabs')&&getComputedStyle(e).position!=='fixed'}).slice(0,5).map(e=>e.className||e.tagName);
      const small = [...document.querySelectorAll('button,a,input,select,textarea,[role=switch]')].filter(e=>{const r=e.getBoundingClientRect();if(!r.width||e.closest('.sr-only'))return false;if(e.matches('.cite'))return false;const t=e.matches('input[type=checkbox]')?e.parentElement.getBoundingClientRect():r;return t.height<36}).slice(0,5).map(e=>(e.className||e.tagName)+':'+Math.round(e.getBoundingClientRect().height));
      const tinyInputs = [...document.querySelectorAll('input:not([type=checkbox]),textarea,select')].filter(e=>parseFloat(getComputedStyle(e).fontSize)<16).map(e=>e.id||e.className);
      const minFont = Math.min(...[...document.querySelectorAll('p,li,span,a,button,dd,dt')].filter(e=>e.offsetParent&&e.textContent.trim()&&!e.closest('.sr-only,svg')).map(e=>parseFloat(getComputedStyle(e).fontSize)));
      return { overflow: document.documentElement.scrollWidth > vw + 1 || innerWidth > visualViewport.width + 1, over, small, tinyInputs, minFont, height: document.documentElement.scrollHeight };
    })()`);
    report.push({ view: name, route: rname, ...m });
    if (rname !== '关注') await b.shot(join(OUT, `${name}-${rname}.png`));
  }
}
// 放大字号：模拟系统字体调大 130%
await b.viewport(390, 844);
await b.ev(`document.documentElement.style.fontSize='130%'; document.body.style.zoom='1.3'`);
await b.go('#/e/baba-2506');
report.push({ view: '字号130%', route: '详情', overflow: !(await b.noOverflow()) });
await b.shot(join(OUT, '字号130%-详情.png'));

writeFileSync(join(OUT, '适配结果.json'), JSON.stringify({ base: BASE, at: new Date().toISOString(), report, problems: b.problems }, null, 2));
for (const r of report) console.log(r.overflow ? 'OVERFLOW' : 'ok      ', r.view.padEnd(14), r.route.padEnd(8), r.over?.length ? 'over=' + r.over.join('|') : '', r.small?.length ? 'small=' + r.small.join('|') : '', r.tinyInputs?.length ? 'tinyInput=' + r.tinyInputs.join('|') : '', r.minFont ? 'minFont=' + r.minFont : '');
console.log('problems:', b.problems);
b.close();
