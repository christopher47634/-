import { useRoute } from './logic/router';
import { useStore } from './logic/store';
import { useWide } from './logic/hooks';
import { useEffect, useState } from 'react';
import Cursor from './components/Cursor';
import { useDark } from './components/bits';
import Detail from './pages/Detail';
import { FinDetail } from './pages/Fin';
import Home from './pages/Home';
import Studio from './pages/Studio';
import Update from './pages/Update';
import WatchEdit from './pages/WatchEdit';

/* 宽屏时右侧显示评审导览：方案第 13 节的五分钟演示路线 */
const TOUR: [string, string][] = [
  ['#/e/baba-2506', '打开阿里巴巴：先看答案和图，点「原文」核对'],
  ['#/e/baba-2506', '展开「后来发生了什么」：当时的疑问被后续公告支持了吗'],
  ['#/fin/600519.SH', '财报对比：茅台环比 −31.7% 为什么多半是季节性，逐项对回原文页码'],
  ['#/live', '实时快讯：看更新时间与评分拆解（断网时退回离线快照）'],
  ['#/e/teach-cost', '教学案例：展开影响路径，切换条件'],
  ['#/e/demo-a', '关注示范公司 A（一键）'],
  ['#/watch', '加载演示更新，查看变化并采纳新版'],
  ['#/studio', '在工作台撤回一条解释，回到阅读页验证'],
];

export default function App() {
  const r = useRoute();
  const demo = useStore((s) => s.demoMode);
  const key = JSON.stringify(r);
  const wide = useWide();
  const [tour, setTour] = useState(false);
  const dark = useDark();
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    document.querySelector('meta[name=theme-color]')?.setAttribute('content', dark ? '#070b17' : '#f6f4ef');
  }, [dark]);
  return (
    <>
      <Cursor />
      <div className={`shell${wide ? ' is-wide' : ''} route-${r.name}`}>
        <main className="column" key={key}>
          {r.name === 'home' && <Home tab={r.tab} />}
          {r.name === 'detail' && <Detail id={r.id} />}
          {r.name === 'watchEdit' && <WatchEdit eventId={r.eventId} watchId={r.watchId} />}
          {r.name === 'update' && <Update watchId={r.watchId} />}
          {r.name === 'studio' && <Studio />}
          {r.name === 'fin' && <FinDetail code={r.code} />}
        </main>
      </div>
      {demo && wide && (
        <div className={`tour${tour ? ' is-open' : ''}`}>
          {tour && (
            <div className="tour-card glass" role="dialog" aria-label="五分钟演示路线">
              <h2>五分钟演示路线</h2>
              <ol>{TOUR.map(([h, t], i) => <li key={t}><a href={h} onClick={() => setTour(false)}><span className="num">{i + 1}</span>{t}</a></li>)}</ol>
            </div>
          )}
          <button className="tour-btn glass" onClick={() => setTour((v) => !v)} aria-expanded={tour}>{tour ? '收起路线' : '演示路线'}</button>
        </div>
      )}
    </>
  );
}
