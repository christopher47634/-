import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/noto-serif-sc/600.css';
import './styles/app.css';
import './styles/motion.css';
import './styles/desktop.css';
import './styles/cursor.css';
import './styles/dark.css';
import './styles/evidence.css';
import './styles/live.css';
import App from './App';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
