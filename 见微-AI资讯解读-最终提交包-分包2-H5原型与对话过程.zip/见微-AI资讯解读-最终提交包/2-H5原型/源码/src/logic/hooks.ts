import { type RefObject, useEffect, useState } from 'react';

/** 桌面宽屏：≥1100px 切换到双栏与叙事首屏 */
export const WIDE = '(min-width: 1100px)';

export function useMedia(q: string) {
  const [m, setM] = useState(() => typeof window !== 'undefined' && window.matchMedia(q).matches);
  useEffect(() => {
    const mq = window.matchMedia(q);
    const on = () => setM(mq.matches);
    on();
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, [q]);
  return m;
}

export const useWide = () => useMedia(WIDE);
export const useReducedMotion = () => useMedia('(prefers-reduced-motion: reduce)');

/**
 * 进入视口后触发一次。默认状态就是「已显示」：
 * 只有在支持 IntersectionObserver、且元素确实还没进入视口时，才先「待命」再播放——
 * 脚本失败或减少动态效果时，内容照常可见。
 */
export function useReveal<T extends Element>(ref: RefObject<T | null>, margin = '0px 0px -12% 0px') {
  const reduce = useReducedMotion();
  const [state, setState] = useState<'idle' | 'armed' | 'in'>('idle');
  useEffect(() => {
    const el = ref.current;
    if (!el || reduce || typeof IntersectionObserver === 'undefined') return;
    const r = el.getBoundingClientRect();
    const visible = r.top < window.innerHeight * 0.88 && r.bottom > 0;
    setState('armed');
    const io = new IntersectionObserver(
      (es) => {
        if (es.some((e) => e.isIntersecting)) {
          // 两帧后再切换，保证「待命」样式先生效，过渡才能播出来
          requestAnimationFrame(() => requestAnimationFrame(() => setState('in')));
          io.disconnect();
        }
      },
      { rootMargin: margin },
    );
    if (visible) requestAnimationFrame(() => requestAnimationFrame(() => setState('in')));
    else io.observe(el);
    return () => io.disconnect();
  }, [ref, reduce, margin]);
  return state;
}

/** 数字从 0 滚到目标值；保留原来的正负号、小数位和单位。只有在「待命 → 进入」时才滚动，其余情况直接显示最终值 */
export function useCountUp(display: string, state: 'idle' | 'armed' | 'in', delay = 0, duration = 900) {
  const m = display.match(/^([^\d]*)(\d+(?:\.\d+)?)(.*)$/);
  const zero = m ? display.replace(/\d+(?:\.\d+)?/, (x) => (0).toFixed(x.split('.')[1]?.length ?? 0)) : display;
  const [out, setOut] = useState(display);
  useEffect(() => {
    if (!m || state === 'idle') { setOut(display); return; }
    if (state === 'armed') { setOut(zero); return; }
    const [, pre, num, post] = m;
    const target = parseFloat(num);
    const dec = num.split('.')[1]?.length ?? 0;
    let raf = 0;
    const t0 = performance.now() + delay;
    const tick = (now: number) => {
      const p = Math.min(1, Math.max(0, (now - t0) / duration));
      const e = 1 - Math.pow(2, -10 * p);
      setOut(p >= 1 ? display : `${pre}${(target * e).toFixed(dec)}${post}`);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state, display]);
  return out;
}
