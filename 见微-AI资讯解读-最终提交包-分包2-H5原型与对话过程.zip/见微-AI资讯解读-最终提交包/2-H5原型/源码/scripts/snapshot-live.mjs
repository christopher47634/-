// 抓一份「离线快照」：实时接口拿不到时（断网、被拦截、在线预览环境的安全策略），页面用它兜底。
// 用法：node scripts/snapshot-live.mjs
// 产物：src/data/liveSnapshot.json（接口原始字段的精简版，和实时返回走同一套解析代码）
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const OUT = fileURLToPath(new URL('../src/data/liveSnapshot.json', import.meta.url));
// 财报对比默认展示与可离线搜索的公司：前四家有逐句核对的原文，其余只有接口数据
const CODES = ['600519.SH', '002594.SZ', '300750.SZ', '688981.SH', '601138.SH', '000333.SZ', '603259.SH', '600900.SH', '002415.SZ', '601899.SH'];
const NEWS_KEEP = ['code', 'title', 'summary', 'showTime', 'stockList', 'pinglun_Num', 'share', 'titleColor'];
const FIN_KEEP = ['SECUCODE', 'SECURITY_CODE', 'SECURITY_NAME_ABBR', 'REPORT_DATE', 'REPORT_TYPE', 'REPORT_DATE_NAME', 'NOTICE_DATE', 'CURRENCY', 'TOTALOPERATEREVE', 'PARENTNETPROFIT', 'KCFJCXSYJLR', 'TOTALOPERATEREVETZ', 'PARENTNETPROFITTZ', 'KCFJCXSYJLRTZ', 'XSMLL', 'DJD_TOI_YOY', 'DJD_DPNP_YOY', 'DJD_DEDUCTDPNP_YOY', 'DJD_TOI_QOQ', 'DJD_DPNP_QOQ', 'DJD_DEDUCTDPNP_QOQ'];

const pick = (o, keys) => Object.fromEntries(keys.filter((k) => k in o).map((k) => [k, o[k]]));
const getJson = async (u) => {
  const r = await fetch(u, { headers: { 'User-Agent': 'Mozilla/5.0 (jianwei demo snapshot; contact@example.com)' } });
  if (!r.ok) throw new Error(`${r.status} ${u}`);
  return r.json();
};

const news = await getJson('https://np-weblist.eastmoney.com/comm/web/getFastNewsList?client=web&biz=web_724&fastColumn=102&sortEnd=&pageSize=60&req_trace=snapshot');
const fin = {};
const ann = {};
for (const c of CODES) {
  const j = await getJson(`https://datacenter.eastmoney.com/securities/api/data/get?type=RPT_F10_FINANCE_MAINFINADATA&sty=APP_F10_MAINFINADATA&quoteColumns=&filter=(SECUCODE%3D%22${c}%22)&p=1&ps=12&sr=-1&st=REPORT_DATE&source=HSF10&client=PC`);
  fin[c] = j.result.data.map((r) => pick(r, FIN_KEEP));
  const a = await getJson(`https://np-anotice-stock.eastmoney.com/api/security/ann?sr=-1&page_size=50&page_index=1&ann_type=A&client_source=web&stock_list=${c.slice(0, 6)}&f_node=1&s_node=1`);
  ann[c] = a.data.list.map((x) => ({ art_code: x.art_code, title: x.title, notice_date: x.notice_date, column: x.columns?.[0]?.column_name ?? '' }));
}
const snap = {
  capturedAt: new Date().toISOString(),
  news: news.data.fastNewsList.map((n) => pick(n, NEWS_KEEP)),
  fin,
  ann,
};
writeFileSync(OUT, JSON.stringify(snap, null, 1));
console.log(`快照已写入 ${OUT}：快讯 ${snap.news.length} 条，公司 ${Object.keys(fin).length} 家，时间 ${snap.capturedAt}`);
